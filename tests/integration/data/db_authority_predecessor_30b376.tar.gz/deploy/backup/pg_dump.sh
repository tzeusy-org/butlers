#!/bin/sh
# deploy/backup/pg_dump.sh
#
# Filesystem pg_dump backup for Butlers.
#
# Writes a timestamped .sql.gz dump to BACKUP_DIR (default: /backups).
# Prunes files older than BACKUP_RETAIN_DAYS (default: 14) days.
# Intended to run as a cron job inside the backup-cron sidecar container
# (see docker-compose.yml) but is also safe to invoke directly.
#
# Environment variables (all optional — defaults shown):
#   POSTGRES_HOST          postgres hostname (default: localhost)
#   POSTGRES_PORT          postgres port (default: 5432)
#   POSTGRES_USER          postgres user (default: butlers)
#   POSTGRES_PASSWORD      postgres password
#   POSTGRES_DB            database name (default: butlers)
#   BACKUP_DIR             directory to write dumps to (default: /backups)
#   BACKUP_RETAIN_DAYS     number of days to keep backups (default: 14)
#
# Output filename format: butlers_YYYY-MM-DDTHH-MM-SS.sql.gz
#
# Every run -- successful or not -- also rewrites BACKUP_DIR/last_run.json, a
# one-line JSON receipt for the MOST RECENT RUN (bu-xrqyu):
#
#   {"result":"failed","reason":"pg_dump_failed","exit_code":1,
#    "finished_at":"2026-08-23T02:00:11Z","artifact":null}
#
# It exists because a failed run publishes no artifact and deletes nothing, so
# the backup directory alone cannot tell "last night's run failed" from "last
# night's run was not due yet": both look like yesterday's good dump sitting
# there. GET /api/system/backups reads this file to answer the first question,
# which artifact freshness was never positioned to answer.
#
# ---------------------------------------------------------------------------
# WHAT THIS BACKUP DOES *NOT* CONTAIN  (bu-e1410 — read before restoring)
# ---------------------------------------------------------------------------
# The dump runs as $POSTGRES_USER: the shared migration/runtime login that
# scripts/init-db.sql deliberately holds at NOSUPERUSER NOCREATEROLE
# NOREPLICATION NOCREATEDB so it cannot cross the isolated-executor boundary.
# That boundary also fences a small set of trusted-bootstrap objects away from
# this login. pg_dump takes LOCK TABLE over every relation in scope before it
# writes a byte, so a single unreadable relation aborts the whole dump and —
# because a failed run is cleaned up rather than published — leaves no file at
# all. Those objects are therefore excluded by name below.
#
# The exclusion set is NOT a convenience: it is the trusted-bootstrap control
# plane, and it is excluded on purpose, for two reasons.
#
#   1. It is not recovered from a dump. scripts/init-db.sql, run by a cluster
#      superuser, is the only supported way to reconstruct these schemas,
#      roles, owners, RLS policies, and definer functions
#      (docs/operations/backup-restore.md, "Bootstrap prerequisite").
#   2. Restoring a dumped copy would be actively harmful. Every excluded object
#      is owned by a fenced role the restoring login is not a member of, so the
#      dump's `ALTER ... OWNER TO` statements would fail and leave the object
#      owned by whoever ran the restore — silently dissolving the fence that
#      init-db.sql exists to build.
#
# What that costs, stated plainly:
#   - restore_drill_executor.*                 restore-drill result ledger:
#         the LEDGER is not backed up; the drill HISTORY is. record_result()
#         writes its public.audit_log projection in the same transaction as the
#         ledger insert, so every outcome also lands in this dump as a
#         restore_drill/restore_drill_result audit row. What is lost in a
#         disaster is the ledger's authority (audit_log is writable by ordinary
#         runtime roles), not the answer to "has a drill ever passed". Measured
#         both ways in tests/scripts/test_restore_drill_evidence_backup.py.
#   - public.dnd_generation_mutations          DND generation mutation audit.
#   - public.user_context                      context-bus signals. Every row
#         carries a hard expires_at (core_042: "no indefinite signals"), so
#         this is expiring, self-regenerating situational state.
#   - public.runtime_attention_outbox
#     public.runtime_attention_delivery_lease
#     public.runtime_attention_producer_control
#         runtime-attention delivery state and its producer control row.
#   - public.runtime_attention_condition_episodes
#         the condition-side emission marker (core_251). It travels with the
#         outbox it points at: a restore that loses both can page a
#         still-active fleet or QA condition once more, never silently drop it.
#   - public.expected_signals                 rebuildable liveness-qualified
#         cadence state. Source observations and connector heartbeats remain in
#         the dump; the next detector run recreates this projection.
#   - public.task_continuity                  per-task carry-forward ledger
#         (core_229). FORCE ROW LEVEL SECURITY fences even the table owner --
#         the identity this script dumps as -- to each producer's own rows.
#         The carry-forward text itself is not regenerated by anything, so a
#         restore genuinely loses the most recent one. That loss is the
#         designed degraded state, not a bug: the next run of an opted-in task
#         reads no live row and says so plainly ("the last run recorded no
#         carry-forward") instead of fabricating continuity it does not have.
#   - public.runtime_probe_control_receipts    replay-guard receipts for
#         runtime-probe control capabilities (core_212). FORCE ROW LEVEL
#         SECURITY fences even the table owner -- the identity this script
#         dumps as -- down to butler_switchboard_rw, on purpose (bu-jcym4).
#         Nothing here outlives its 5-second retention skew, so nothing here
#         is worth restoring: the next capability use regenerates the receipt
#         a live replay window would need.
#   - public.qa_publication_operations         QA publication operation ledger
#         (core_266). FORCE ROW LEVEL SECURITY fences even the table owner --
#         the identity this script dumps as -- to the QA role for writes. Unlike
#         the receipts above this is durable state: a row held in
#         egress_started/ambiguous blocks a fresh attempt/branch/PR until a
#         reconciliation is recorded, and a restore from this dump has no such
#         row. The restore-time fence that closes that gap is owned by
#         bu-mc01y5.7; until it lands, publication stays disabled (slice 1).
#   - *_admin schemas                          bootstrap configuration rows
#         (role names) plus the fixed installer/finalizer functions.
#
# No ordinary application data is excluded. The three cost-claim tables are the
# narrow exception to pg_dump's data path: their schema, ownership, FORCE RLS,
# policies, triggers, and definer function remain in the ordinary dump, while
# their rows travel through an explicit hex-wrapped JSON staging block. The ordinary dump
# still runs with row_security=off, so every other unexcluded fenced relation
# remains a loud failure. The staging query is admitted only after a catalogue
# check in the same exported snapshot proves the exact three-table set still
# has one permissive, non-restrictive PUBLIC SELECT policy with USING (true).
#
# On restore, the staged rows pass through cost_claim_restore_row() under the
# table owner's existing membership precondition. That fixed SECURITY DEFINER
# function accepts only these three relations, suppresses only the audit events
# that restoring historical rows would otherwise duplicate, and has no PUBLIC
# execute grant. tests/scripts/test_pg_dump_backup.py and
# tests/scripts/test_pg_restore_definer_ownership.py prove row parity and the
# restored FORCE RLS, owner, and definer posture against real PostgreSQL.

# NOTE: no `set -o pipefail` here. It is not POSIX, so the shebang above was a
# lie on any host whose /bin/sh is dash — the script died on line 1 of its own
# safety setup. The dump's exit status is captured explicitly below instead,
# which is both portable and stricter than pipefail (it reports the code).
set -eu

POSTGRES_HOST="${POSTGRES_HOST:-localhost}"
POSTGRES_PORT="${POSTGRES_PORT:-5432}"
POSTGRES_USER="${POSTGRES_USER:-butlers}"
POSTGRES_DB="${POSTGRES_DB:-butlers}"
BACKUP_DIR="${BACKUP_DIR:-/backups}"
BACKUP_RETAIN_DAYS="${BACKUP_RETAIN_DAYS:-14}"

# Trusted-bootstrap exclusion set. Whitespace-separated; parsed by
# tests/scripts/test_pg_dump_backup.py, so keep the assignments on one line each.
BACKUP_EXCLUDE_SCHEMAS="restore_drill_executor restore_drill_executor_admin dnd_generation_admin runtime_attention_admin"
# public.audit_log is deliberately NOT here: it carries the restore-drill
# evidence projection, and excluding it is the one edit that would silently
# empty that path. Four tests across two files fail if it is added.
BACKUP_EXCLUDE_TABLES="public.dnd_generation_mutations public.user_context public.runtime_attention_outbox public.runtime_attention_delivery_lease public.runtime_attention_producer_control public.runtime_attention_condition_episodes public.expected_signals public.runtime_probe_control_receipts public.fleet_cases public.fleet_case_links public.task_continuity public.qa_publication_operations"
# Durable FORCE RLS application data carried by the scoped staging block.
# Parsed and policy-verified by tests/scripts/test_pg_dump_backup.py.
BACKUP_SCOPED_DATA_TABLES="public.cost_claims public.cost_claim_resolutions public.cost_claim_events"

# A gzip stream smaller than this cannot hold a real dump (gzip's own
# header+footer is ~20 bytes). Matches _BACKUP_MIN_SIZE_BYTES in
# src/butlers/core/backup_facts.py, which renders the same verdict on read.
BACKUP_MIN_SIZE_BYTES=256

mkdir -p "${BACKUP_DIR}"

TIMESTAMP="$(date -u +%Y-%m-%dT%H-%M-%S)"
OUTFILE="${BACKUP_DIR}/butlers_${TIMESTAMP}.sql.gz"
TMPFILE="${OUTFILE}.tmp"
STATUSFILE="${OUTFILE}.status"

# Outcome of THIS run, recorded where the dashboard can read it (bu-xrqyu).
# A failed run publishes no artifact, so the directory keeps holding yesterday's
# good dump and artifact freshness alone reads as healthy for another 36 hours.
# This sentinel is the run's own signal, independent of any artifact's age.
RUN_SENTINEL="${BACKUP_DIR}/last_run.json"

# Set immediately before each deliberate `exit 1` below; the EXIT trap reads it
# back. An abort nobody enumerated (any `set -e` failure) leaves it empty and is
# recorded as "unexpected_error" -- never as a success.
FAILURE_REASON=""
SNAPSHOT_DIR=""
SNAPSHOT_HOLDER_PID=""

# Fixed reason vocabulary, mirrored by _BACKUP_RUN_REASONS in
# src/butlers/core/backup_facts.py: ok, pg_dump_failed, artifact_undersize,
# artifact_corrupt, unexpected_error. Keep the two lists in step.
write_run_sentinel() {
  sentinel_exit="$1"
  sentinel_reason="$2"
  sentinel_artifact="$3"
  sentinel_tmp="${RUN_SENTINEL}.tmp"

  if [ "${sentinel_exit}" -eq 0 ]; then
    sentinel_result="success"
    sentinel_artifact_json="\"${sentinel_artifact}\""
  else
    sentinel_result="failed"
    sentinel_artifact_json="null"
  fi

  # Written to a temp file and mv'd into place so a dashboard poll never reads
  # a half-written sentinel. Every field comes from the fixed vocabulary above,
  # an exit status, or a timestamp -- never from command output, so nothing
  # here can carry a DSN, password, or dump fragment into a file the dashboard
  # renders. A sentinel that cannot be written must not change the run's exit
  # status: this runs from the EXIT trap, and failing a good backup because its
  # receipt was unwritable would be its own bug.
  if printf '{"result":"%s","reason":"%s","exit_code":%s,"finished_at":"%s","artifact":%s}\n' \
      "${sentinel_result}" \
      "${sentinel_reason}" \
      "${sentinel_exit}" \
      "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
      "${sentinel_artifact_json}" > "${sentinel_tmp}" 2>/dev/null \
     && mv -f "${sentinel_tmp}" "${RUN_SENTINEL}" 2>/dev/null; then
    return 0
  fi
  rm -f "${sentinel_tmp}" 2>/dev/null || true
  echo "[backup] WARNING: could not record run outcome at ${RUN_SENTINEL}" >&2
  return 0
}

# Remove the temp file on exit so a failed dump never leaves a partial file
# in the backup directory (the directory scanner ignores .tmp files, but this
# keeps the directory clean even if something kills the process mid-run).
#
# A failed run publishes NO file, so its only traces are this log line and the
# run sentinel. Say so unmistakably rather than letting the run end on
# pg_dump's stderr and an exit code nobody reads (bu-e1410), and record the
# outcome from the trap rather than from each failure branch (bu-xrqyu): the
# trap fires on every exit path, including the ones nobody enumerated, so no
# route out of this script can skip the signal it is supposed to leave.
cleanup() {
  status=$?
  if [ -n "${SNAPSHOT_HOLDER_PID}" ]; then
    printf 'ROLLBACK;\n\\q\n' >&9 2>/dev/null || true
    exec 9>&- 2>/dev/null || true
    wait "${SNAPSHOT_HOLDER_PID}" 2>/dev/null || true
  fi
  if [ -n "${SNAPSHOT_DIR}" ]; then
    rm -rf "${SNAPSHOT_DIR}"
  fi
  rm -f "${TMPFILE}" "${STATUSFILE}"
  if [ "${status}" -eq 0 ]; then
    write_run_sentinel 0 ok "${OUTFILE##*/}"
  else
    write_run_sentinel "${status}" "${FAILURE_REASON:-unexpected_error}" ""
    if [ ! -f "${OUTFILE}" ]; then
      echo "[backup] FAILED: no backup artifact was produced (exit ${status});" \
           "${BACKUP_DIR} still holds only previous runs, if any" >&2
    fi
  fi
}
trap cleanup EXIT

echo "[backup] start: ${TIMESTAMP}, host=${POSTGRES_HOST}:${POSTGRES_PORT}, db=${POSTGRES_DB}"

# Build the exclusion arguments from the declared sets above.
set --
for schema in ${BACKUP_EXCLUDE_SCHEMAS}; do
  set -- "$@" "--exclude-schema=${schema}"
done
for table in ${BACKUP_EXCLUDE_TABLES}; do
  set -- "$@" "--exclude-table=${table}"
done
for table in ${BACKUP_SCOPED_DATA_TABLES}; do
  set -- "$@" "--exclude-table-data=${table}"
done

# pg_dump and the scoped ledger query must see one database instant. Keep a
# read-only repeatable-read transaction open, export its snapshot, and bind
# both producers and the exact RLS-policy proof to it. The FIFO writer stays
# open until both are finished, so psql waits for the final COMMIT without a
# sleep-based transaction lifetime.
SNAPSHOT_DIR="$(mktemp -d)"
SNAPSHOT_CONTROL="${SNAPSHOT_DIR}/control"
SNAPSHOT_ID_FILE="${SNAPSHOT_DIR}/id"
SNAPSHOT_POLICY_COUNT_FILE="${SNAPSHOT_DIR}/policy-count"
SNAPSHOT_LOG="${SNAPSHOT_DIR}/holder.log"
mkfifo "${SNAPSHOT_CONTROL}"
PGPASSWORD="${POSTGRES_PASSWORD:-}" psql \
  --host="${POSTGRES_HOST}" \
  --port="${POSTGRES_PORT}" \
  --username="${POSTGRES_USER}" \
  --dbname="${POSTGRES_DB}" \
  --no-password \
  --no-align \
  --tuples-only \
  --set=ON_ERROR_STOP=1 \
  < "${SNAPSHOT_CONTROL}" > "${SNAPSHOT_LOG}" 2>&1 &
SNAPSHOT_HOLDER_PID=$!
exec 9>"${SNAPSHOT_CONTROL}"
printf 'BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;\n' >&9
printf '\\o %s\nSELECT pg_export_snapshot();\n\\o\n' "${SNAPSHOT_ID_FILE}" >&9
# A FOR ALL policy also applies to SELECT. Count every SELECT-applying policy,
# then require the one admitted policy to be the exact explicit PUBLIC SELECT
# policy below; otherwise a restrictive FOR ALL policy could silently filter
# the scoped export.
printf '\\o %s\nSELECT count(*)
      FROM pg_class AS c
      JOIN pg_namespace AS n ON n.oid = c.relnamespace
     WHERE n.nspname || '\''.'\'' || c.relname IN (
               '\''public.cost_claims'\'',
               '\''public.cost_claim_resolutions'\'',
               '\''public.cost_claim_events'\''
           )
       AND c.relrowsecurity
       AND c.relforcerowsecurity
       AND (
           SELECT count(*) = 1
             FROM pg_policy AS p
            WHERE p.polrelid = c.oid
              AND p.polcmd IN ('\''r'\'', '\''*'\'')
       )
       AND EXISTS (
           SELECT 1
             FROM pg_policy AS p
            WHERE p.polrelid = c.oid
              AND p.polcmd = '\''r'\''
              AND p.polpermissive
              AND p.polroles = ARRAY[0::oid]
              AND pg_get_expr(p.polqual, p.polrelid) = '\''true'\''
       );
\\o\n' "${SNAPSHOT_POLICY_COUNT_FILE}" >&9

SNAPSHOT_WAIT=0
while { [ ! -s "${SNAPSHOT_ID_FILE}" ] || [ ! -s "${SNAPSHOT_POLICY_COUNT_FILE}" ]; } \
  && kill -0 "${SNAPSHOT_HOLDER_PID}" 2>/dev/null; do
  SNAPSHOT_WAIT=$((SNAPSHOT_WAIT + 1))
  if [ "${SNAPSHOT_WAIT}" -ge 100 ]; then
    break
  fi
  sleep 0.05
done
if [ ! -s "${SNAPSHOT_ID_FILE}" ] || [ ! -s "${SNAPSHOT_POLICY_COUNT_FILE}" ]; then
  FAILURE_REASON="pg_dump_failed"
  echo "[backup] FAILED: could not establish a shared backup snapshot and policy proof; not publishing" >&2
  exit 1
fi
BACKUP_SNAPSHOT="$(tr -d '\r\n' < "${SNAPSHOT_ID_FILE}")"
case "${BACKUP_SNAPSHOT}" in
  ''|*[!0-9A-Fa-f-]*)
    FAILURE_REASON="pg_dump_failed"
    echo "[backup] FAILED: shared backup snapshot was invalid; not publishing" >&2
    exit 1
    ;;
esac
COST_CLAIM_BACKUP_POLICY_COUNT="$(tr -d '\r\n' < "${SNAPSHOT_POLICY_COUNT_FILE}")"
if [ "${COST_CLAIM_BACKUP_POLICY_COUNT}" != "3" ]; then
  FAILURE_REASON="pg_dump_failed"
  echo "[backup] FAILED: cost-claim backup policy is not the exact full-row contract; not publishing" >&2
  exit 1
fi

# pg_dump writes to stdout; we pipe through gzip into a .tmp file so the
# directory scanner in get_backup_facts() never sees a partial dump.  gzip's
# own exit status says nothing about pg_dump's, and the left-hand side of a
# pipeline runs in a subshell, so the dump records its failure in a status file
# the parent shell can read back.  The cleanup trap removes both temp files
# before the mv would make a bad dump permanent.
: > "${STATUSFILE}"
{
  PGPASSWORD="${POSTGRES_PASSWORD:-}" pg_dump \
    --host="${POSTGRES_HOST}" \
    --port="${POSTGRES_PORT}" \
    --username="${POSTGRES_USER}" \
    --dbname="${POSTGRES_DB}" \
    --format=plain \
    --snapshot="${BACKUP_SNAPSHOT}" \
    --no-password \
    "$@" \
  || { echo "$?" > "${STATUSFILE}"; exit 0; }

  # The ordinary dump has already emitted schema, ownership, policies, and all
  # non-fenced application data. Append the three explicitly scoped ledgers as
  # hex-wrapped JSON COPY rows, then replay them through the fixed importer.
  # Hex keeps COPY's tab/newline/backslash framing independent of user data.
  printf '\n-- Butlers scoped cost-claim ledger data\n'
  printf 'CREATE TEMP TABLE butlers_cost_claim_restore_rows (ordinal integer, relation_name text, payload_hex text);\n'
  printf 'COPY butlers_cost_claim_restore_rows (ordinal, relation_name, payload_hex) FROM stdin;\n'
  PGPASSWORD="${POSTGRES_PASSWORD:-}" psql \
    --host="${POSTGRES_HOST}" \
    --port="${POSTGRES_PORT}" \
    --username="${POSTGRES_USER}" \
    --dbname="${POSTGRES_DB}" \
    --no-password \
    --quiet \
    --no-align \
    --tuples-only \
    --set=ON_ERROR_STOP=1 \
    -c "BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
        SET TRANSACTION SNAPSHOT '${BACKUP_SNAPSHOT}';
        COPY (
          SELECT 1, 'cost_claims',
                 encode(convert_to(to_jsonb(t)::text, 'UTF8'), 'hex')
            FROM public.cost_claims AS t
          UNION ALL
          SELECT 2, 'cost_claim_resolutions',
                 encode(convert_to(to_jsonb(t)::text, 'UTF8'), 'hex')
            FROM public.cost_claim_resolutions AS t
          UNION ALL
          SELECT 3, 'cost_claim_events',
                 encode(convert_to(to_jsonb(t)::text, 'UTF8'), 'hex')
            FROM public.cost_claim_events AS t
          ORDER BY 1, 2, 3
        ) TO STDOUT;
        COMMIT" \
  || { echo "$?" > "${STATUSFILE}"; exit 0; }
  printf '\\.\n'
  PGPASSWORD="${POSTGRES_PASSWORD:-}" psql \
    --host="${POSTGRES_HOST}" \
    --port="${POSTGRES_PORT}" \
    --username="${POSTGRES_USER}" \
    --dbname="${POSTGRES_DB}" \
    --no-password \
    --no-align \
    --tuples-only \
    --set=ON_ERROR_STOP=1 \
    -c "SELECT format(
                   'SELECT coalesce(pg_has_role(current_user, to_regrole(%L), ''MEMBER''), false) AS butlers_cost_claim_restore_authorized \\gset
\\if :butlers_cost_claim_restore_authorized
\\set ON_ERROR_STOP on
GRANT SELECT ON butlers_cost_claim_restore_rows TO %I;
SET ROLE %I;',
                   pg_get_userbyid(relowner),
                   pg_get_userbyid(relowner),
                   pg_get_userbyid(relowner)
               )
          FROM pg_class
         WHERE oid = 'public.cost_claims'::regclass" \
  || { echo "$?" > "${STATUSFILE}"; exit 0; }
  printf "SELECT public.cost_claim_restore_row(\n  relation_name,\n  convert_from(decode(payload_hex, 'hex'), 'UTF8')::jsonb\n)\nFROM butlers_cost_claim_restore_rows\nORDER BY ordinal, payload_hex;\n"
  printf 'RESET ROLE;\n\\else\n\\echo cost-claim ledger replay skipped: restore owner membership unavailable\n\\endif\nDROP TABLE butlers_cost_claim_restore_rows;\n'
} | gzip > "${TMPFILE}"

printf 'COMMIT;\n\\q\n' >&9
exec 9>&-
if ! wait "${SNAPSHOT_HOLDER_PID}"; then
  FAILURE_REASON="pg_dump_failed"
  SNAPSHOT_HOLDER_PID=""
  echo "[backup] FAILED: shared backup snapshot did not close cleanly; not publishing" >&2
  exit 1
fi
SNAPSHOT_HOLDER_PID=""
rm -rf "${SNAPSHOT_DIR}"
SNAPSHOT_DIR=""

DUMP_STATUS="$(cat "${STATUSFILE}")"
if [ -n "${DUMP_STATUS}" ]; then
  FAILURE_REASON="pg_dump_failed"
  echo "[backup] FAILED: pg_dump exited ${DUMP_STATUS}; not publishing" >&2
  exit 1
fi

# Verify before publishing rather than trusting exit codes alone: a dump that
# is too small to be real, or whose gzip CRC does not check out, must never be
# mv'd into place and then counted as a good backup by the dashboard.
# `wc -c` pads its output with blanks on some implementations; strip them
# so the numeric comparison below cannot trip over leading whitespace.
TMPSIZE="$(wc -c < "${TMPFILE}" | tr -d " ")"
if [ "${TMPSIZE}" -lt "${BACKUP_MIN_SIZE_BYTES}" ]; then
  FAILURE_REASON="artifact_undersize"
  echo "[backup] FAILED: dump is ${TMPSIZE} bytes, below the" \
       "${BACKUP_MIN_SIZE_BYTES}-byte floor; not publishing" >&2
  exit 1
fi
if ! gzip -dc "${TMPFILE}" > /dev/null 2>&1; then
  FAILURE_REASON="artifact_corrupt"
  echo "[backup] FAILED: dump did not decompress cleanly; not publishing" >&2
  exit 1
fi

mv "${TMPFILE}" "${OUTFILE}"
echo "[backup] written: ${OUTFILE} ($(du -h "${OUTFILE}" | cut -f1))"

# Prune files older than BACKUP_RETAIN_DAYS days.
# -exec echo before -delete so the filename is logged before removal.
find "${BACKUP_DIR}" -maxdepth 1 -name "butlers_*.sql.gz" \
  -mtime "+${BACKUP_RETAIN_DAYS}" \
  -exec echo "[backup] pruned: {}" \; -delete

echo "[backup] done"
