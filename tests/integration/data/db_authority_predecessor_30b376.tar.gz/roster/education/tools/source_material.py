"""Education source-material registry backed by the butler state store.

The registry intentionally stores metadata only.  Source contents are neither
retrieved nor parsed, and deleting a record does not inspect or rewrite mind
map node metadata that may still refer to its source ID.
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import UTC, datetime
from typing import Any

import asyncpg

from butlers.core.state import state_delete, state_get, state_list, state_set

SOURCE_KEY_PREFIX = "education/source/"
_SOURCE_TYPES = frozenset({"article", "book", "documentation", "paper"})

# Where a ``source_refs`` entry's location came from: read out of the source
# itself, or produced from the model's knowledge of it.  Defined here, next to
# the registry the distinction is about, so the planner and the teaching session
# cannot drift apart on the vocabulary (REQ-education-source-grounding-002).
PROVENANCE_VALUES = frozenset({"referenced", "model-recalled"})


def _normalise_required(value: Any, field: str) -> str:
    """Return a non-empty string field or raise a caller-actionable error."""
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} is required and must be a non-empty string")
    return value.strip()


def _normalise_authors(authors: list[str] | tuple[str, ...] | str | None) -> list[str]:
    """Normalise the author(s) input into a JSON-friendly list of strings."""
    if authors is None:
        return []
    if isinstance(authors, str):
        authors = [authors]
    if not isinstance(authors, (list, tuple)):
        raise ValueError("authors must be a string or a list of strings")
    if any(not isinstance(author, str) or not author.strip() for author in authors):
        raise ValueError("authors must contain only non-empty strings")
    return [author.strip() for author in authors]


def _source_key(source_id: str) -> str:
    """Return the state-store key for a source ID."""
    source_id = _normalise_required(source_id, "source_id")
    return f"{SOURCE_KEY_PREFIX}{source_id}"


async def source_material_register(
    pool: asyncpg.Pool,
    title: str,
    type: str,
    authors: list[str] | tuple[str, ...] | str | None = None,
    toc: Any | None = None,
    url: str | None = None,
) -> dict[str, Any]:
    """Register source metadata and return it with its generated source ID.

    ``type`` is restricted to the source vocabulary used by the capability
    spec.  ``toc`` and ``url`` are optional metadata and are passed through
    unchanged when supplied.  No network operation is performed.
    """
    source_title = _normalise_required(title, "title")
    source_type = _normalise_required(type, "type").lower()
    if source_type not in _SOURCE_TYPES:
        allowed = ", ".join(sorted(_SOURCE_TYPES))
        raise ValueError(f"type must be one of: {allowed}")

    source_id = str(uuid.uuid4())
    registered_at = datetime.now(UTC).isoformat()
    record: dict[str, Any] = {
        "title": source_title,
        "authors": _normalise_authors(authors),
        "type": source_type,
        "registered_at": registered_at,
    }
    if toc is not None:
        record["toc"] = toc
    if url is not None:
        record["url"] = url

    await state_set(pool, _source_key(source_id), record)
    return {"source_id": source_id, **record}


async def source_material_list(pool: asyncpg.Pool) -> list[dict[str, Any]]:
    """Return every currently registered source, ordered by state-store key."""
    entries = await state_list(pool, prefix=SOURCE_KEY_PREFIX, keys_only=False)
    sources: list[dict[str, Any]] = []
    for entry in entries:
        key = entry.get("key")
        value = entry.get("value")
        if not isinstance(key, str) or not key.startswith(SOURCE_KEY_PREFIX):
            continue
        source_id = key[len(SOURCE_KEY_PREFIX) :]
        if not source_id or not isinstance(value, dict):
            continue
        sources.append({"source_id": source_id, **value})
    return sources


async def source_material_get_many(
    pool: asyncpg.Pool, source_ids: list[str]
) -> list[dict[str, Any]]:
    """Resolve specific source IDs against the registry.

    An ID with no matching record (removed, or never registered) is simply
    absent from the result rather than an error — this is the registry-miss
    case a dangling ``source_refs`` entry must be told apart from a registry
    failure, which the caller reports separately by letting the pool error
    propagate. Result order does not follow ``source_ids``.
    """
    if not source_ids:
        return []
    values = await asyncio.gather(*(state_get(pool, _source_key(sid)) for sid in source_ids))
    return [
        {"source_id": source_id, **value}
        for source_id, value in zip(source_ids, values, strict=True)
        if isinstance(value, dict)
    ]


async def source_material_remove(pool: asyncpg.Pool, source_id: str) -> dict[str, str]:
    """Remove a source metadata record without touching any node references.

    State deletion is intentionally idempotent.  A node that still carries the
    removed ID retains its dangling ``source_refs`` entry for the dashboard to
    render as an unregistered source.
    """
    await state_delete(pool, _source_key(source_id))
    return {"source_id": source_id, "status": "removed"}
