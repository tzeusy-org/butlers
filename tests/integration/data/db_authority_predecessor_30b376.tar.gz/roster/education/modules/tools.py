"""Education MCP tool registrations.

All ``@mcp.tool()`` closures live here, extracted from the monolithic
``EducationModule.register_tools`` method.  Called once during butler
startup via ``register_tools(mcp, module, config)``.
"""

from __future__ import annotations

from datetime import date
from typing import Any

from butlers.modules.base import tool_registrar


def register_tools(mcp: Any, module: Any, config: Any) -> None:  # noqa: C901
    """Register all education MCP tools on *mcp*, using *module* for pool access."""

    # Import sub-modules (deferred to avoid import-time side effects)
    from butlers.core.scheduler import schedule_create as _sched_create
    from butlers.core.scheduler import schedule_delete as _sched_delete
    from butlers.tools.education import analytics as _analytics
    from butlers.tools.education import curriculum as _curriculum
    from butlers.tools.education import diagnostic as _diagnostic
    from butlers.tools.education import mastery as _mastery
    from butlers.tools.education import mind_map_edges as _edges
    from butlers.tools.education import mind_map_nodes as _nodes
    from butlers.tools.education import mind_map_queries as _queries
    from butlers.tools.education import mind_maps as _maps
    from butlers.tools.education import pedagogy as _pedagogy
    from butlers.tools.education import source_material as _source_material
    from butlers.tools.education import spaced_repetition as _sr
    from butlers.tools.education import teaching_flows as _flows

    _tool = tool_registrar(mcp, config)

    # --- Scheduler callback factories ---
    # Education tools use callback injection for scheduler integration.
    # The callbacks adapt the core scheduler API (pool + positional args)
    # into the keyword-only interface expected by education tool functions.

    def _make_schedule_create():
        async def _bound(**kwargs: Any) -> str:
            pool = module._get_pool()
            name = kwargs.pop("name")
            cron = kwargs.pop("cron")
            prompt = kwargs.pop("prompt", None)
            task_id = await _sched_create(pool, name, cron, prompt, **kwargs)
            return str(task_id)

        return _bound

    def _make_schedule_delete():
        async def _bound(name: str) -> None:
            pool = module._get_pool()
            row = await pool.fetchrow("SELECT id FROM scheduled_tasks WHERE name = $1", name)
            if row is not None:
                await _sched_delete(pool, row["id"])

        return _bound

    bound_schedule_create = _make_schedule_create()
    bound_schedule_delete = _make_schedule_delete()

    # =================================================================
    # Mind Map tools
    # =================================================================

    @_tool("mind_maps")
    async def mind_map_create(title: str) -> str:
        """Create a new mind map with status='active'."""
        return await _maps.mind_map_create(module._get_pool(), title)

    @_tool("mind_maps")
    async def mind_map_get(
        mind_map_id: str,
    ) -> dict[str, Any] | None:
        """Retrieve a mind map by ID, including its nodes and edges."""
        return await _maps.mind_map_get(module._get_pool(), mind_map_id)

    @_tool("mind_maps")
    async def mind_map_list(
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List mind maps, optionally filtered by status."""
        return await _maps.mind_map_list(module._get_pool(), status=status)

    @_tool("mind_maps")
    async def mind_map_update_status(mind_map_id: str, status: str) -> None:
        """Update the status of a mind map."""
        await _maps.mind_map_update_status(module._get_pool(), mind_map_id, status)

    # =================================================================
    # Mind Map Node tools
    # =================================================================

    @_tool("mind_maps")
    async def mind_map_node_create(
        mind_map_id: str,
        label: str,
        description: str | None = None,
        depth: int | None = None,
        effort_minutes: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, str]:
        """Create a new node in a mind map and auto-create a shared entity for it.

        Returns a dict with ``node_id`` and ``entity_id``.
        """
        return await _nodes.mind_map_node_create(
            module._get_pool(),
            mind_map_id,
            label,
            description=description,
            depth=depth,
            effort_minutes=effort_minutes,
            metadata=metadata,
        )

    @_tool("mind_maps")
    async def mind_map_node_get(
        node_id: str,
    ) -> dict[str, Any] | None:
        """Retrieve a single node by ID."""
        return await _nodes.mind_map_node_get(module._get_pool(), node_id)

    @_tool("mind_maps")
    async def mind_map_node_list(
        mind_map_id: str,
        mastery_status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List nodes in a mind map, optionally filtered by mastery_status."""
        return await _nodes.mind_map_node_list(
            module._get_pool(),
            mind_map_id,
            mastery_status=mastery_status,
        )

    @_tool("mind_maps")
    async def mind_map_node_update(
        node_id: str,
        mastery_score: float | None = None,
        mastery_status: str | None = None,
        ease_factor: float | None = None,
        repetitions: int | None = None,
        next_review_at: str | None = None,
        last_reviewed_at: str | None = None,
        effort_minutes: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Update writable fields on a node."""
        fields = {
            k: v
            for k, v in {
                "mastery_score": mastery_score,
                "mastery_status": mastery_status,
                "ease_factor": ease_factor,
                "repetitions": repetitions,
                "next_review_at": next_review_at,
                "last_reviewed_at": last_reviewed_at,
                "effort_minutes": effort_minutes,
                "metadata": metadata,
            }.items()
            if v is not None
        }
        await _nodes.mind_map_node_update(module._get_pool(), node_id, **fields)

    # =================================================================
    # Mind Map Edge tools
    # =================================================================

    @_tool("mind_maps")
    async def mind_map_edge_create(
        parent_node_id: str,
        child_node_id: str,
        edge_type: str = "prerequisite",
    ) -> None:
        """Create an edge from parent to child in the mind map DAG."""
        await _edges.mind_map_edge_create(
            module._get_pool(),
            parent_node_id,
            child_node_id,
            edge_type=edge_type,
        )

    @_tool("mind_maps")
    async def mind_map_edge_delete(parent_node_id: str, child_node_id: str) -> None:
        """Delete an edge between two nodes (idempotent)."""
        await _edges.mind_map_edge_delete(module._get_pool(), parent_node_id, child_node_id)

    # =================================================================
    # Mind Map Query tools
    # =================================================================

    @_tool("mind_maps")
    async def mind_map_frontier(
        mind_map_id: str,
    ) -> list[dict[str, Any]]:
        """Return frontier nodes (prerequisites mastered, node not yet mastered)."""
        return await _queries.mind_map_frontier(module._get_pool(), mind_map_id)

    @_tool("mind_maps")
    async def mind_map_subtree(
        node_id: str,
    ) -> list[dict[str, Any]]:
        """Return all descendants of a node (recursive CTE)."""
        return await _queries.mind_map_subtree(module._get_pool(), node_id)

    # =================================================================
    # Teaching Flow tools
    # =================================================================

    @_tool("teaching")
    async def teaching_flow_start(
        topic: str,
        goal: str | None = None,
    ) -> dict[str, Any]:
        """Start a new teaching flow for a topic."""
        return await _flows.teaching_flow_start(module._get_pool(), topic, goal=goal)

    @_tool("teaching")
    async def teaching_flow_get(
        mind_map_id: str,
    ) -> dict[str, Any] | None:
        """Read current flow state from the KV store."""
        return await _flows.teaching_flow_get(module._get_pool(), mind_map_id)

    @_tool("teaching")
    async def teaching_flow_advance(
        mind_map_id: str,
    ) -> dict[str, Any]:
        """Advance the teaching flow state machine to the next state."""
        return await _flows.teaching_flow_advance(module._get_pool(), mind_map_id)

    @_tool("teaching")
    async def teaching_flow_abandon(mind_map_id: str) -> None:
        """Abandon a teaching flow and clean up pending review schedules."""
        await _flows.teaching_flow_abandon(
            module._get_pool(),
            mind_map_id,
            schedule_delete=bound_schedule_delete,
        )

    @_tool("teaching")
    async def teaching_flow_list(
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List teaching flows with optional status filter."""
        return await _flows.teaching_flow_list(module._get_pool(), status=status)

    @_tool("teaching")
    async def teaching_cite_source(
        node_id: str,
        location: str,
        provenance: str,
        source_id: str | None = None,
        note: str | None = None,
    ) -> dict[str, Any]:
        """Record where a claim in this explanation came from, on the concept node.

        ``provenance`` is mandatory and is shown to the owner verbatim: pass
        ``"referenced"`` only if this session read the registered source itself,
        and ``"model-recalled"`` when the location comes from your own knowledge of
        the work — a registered ``source_id`` proves the source exists, not that
        anything read the page. ``"referenced"`` requires a registered
        ``source_id`` (see ``source_material_list``); cite an unregistered work
        with ``source_id=None``. ``location`` should be specific (chapter, page
        range, section) — omit the citation rather than inventing one.
        """
        return await _pedagogy.teaching_cite_source(
            module._get_pool(),
            node_id,
            location=location,
            provenance=provenance,
            source_id=source_id,
            note=note,
        )

    @_tool("teaching")
    async def teaching_reading_pathways(node_id: str) -> dict[str, Any]:
        """Return optional further-reading suggestions for a concept node.

        One pathway per ``source_refs`` entry whose source is still registered,
        with its title, location, and provenance. Suggest them as optional
        ("for deeper study, see…"), never as a prerequisite, and hedge a
        ``model-recalled`` location rather than asserting it. An empty
        ``pathways`` list means no registered source covers this concept —
        say nothing about further reading and continue teaching.
        """
        return await _pedagogy.teaching_reading_pathways(module._get_pool(), node_id)

    # =================================================================
    # Mastery tools
    # =================================================================

    @_tool("mastery")
    async def mastery_record_response(
        node_id: str,
        mind_map_id: str,
        question_text: str,
        user_answer: str | None,
        quality: int,
        response_type: str = "review",
        session_id: str | None = None,
        evaluator_notes: str | None = None,
    ) -> str:
        """Record a quiz response and update node mastery score and status."""
        return await _mastery.mastery_record_response(
            module._get_pool(),
            node_id,
            mind_map_id,
            question_text,
            user_answer,
            quality,
            response_type=response_type,
            session_id=session_id,
            evaluator_notes=evaluator_notes,
        )

    @_tool("mastery")
    async def mastery_get_node_history(
        node_id: str,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Return quiz response history for a node, most recent first."""
        return await _mastery.mastery_get_node_history(module._get_pool(), node_id, limit=limit)

    @_tool("mastery")
    async def mastery_get_map_summary(
        mind_map_id: str,
    ) -> dict[str, Any]:
        """Return aggregate mastery statistics for all nodes in a mind map."""
        return await _mastery.mastery_get_map_summary(module._get_pool(), mind_map_id)

    @_tool("mastery")
    async def mastery_detect_struggles(
        mind_map_id: str,
    ) -> list[dict[str, Any]]:
        """Identify nodes with declining or consistently low mastery."""
        return await _mastery.mastery_detect_struggles(module._get_pool(), mind_map_id)

    # =================================================================
    # Spaced Repetition tools
    # =================================================================

    @_tool("spaced_repetition")
    async def spaced_repetition_record_response(
        node_id: str,
        mind_map_id: str,
        quality: int,
    ) -> dict[str, Any]:
        """Record a spaced-repetition review response and schedule the next review."""
        return await _sr.spaced_repetition_record_response(
            module._get_pool(),
            node_id,
            mind_map_id,
            quality,
            schedule_create=bound_schedule_create,
            schedule_delete=bound_schedule_delete,
        )

    @_tool("spaced_repetition")
    async def spaced_repetition_pending_reviews(
        mind_map_id: str,
    ) -> list[dict[str, Any]]:
        """Return nodes due for spaced-repetition review (next_review_at <= now)."""
        return await _sr.spaced_repetition_pending_reviews(module._get_pool(), mind_map_id)

    @_tool("spaced_repetition")
    async def spaced_repetition_schedule_cleanup(
        mind_map_id: str,
    ) -> int:
        """Remove all pending review schedules for a terminal mind map."""
        return await _sr.spaced_repetition_schedule_cleanup(
            module._get_pool(),
            mind_map_id,
            schedule_delete=bound_schedule_delete,
        )

    # =================================================================
    # Diagnostic tools
    # =================================================================

    @_tool("diagnostics")
    async def diagnostic_start(
        mind_map_id: str,
    ) -> list[dict[str, Any]]:
        """Initialise a diagnostic assessment for a mind map."""
        return await _diagnostic.diagnostic_start(module._get_pool(), mind_map_id)

    @_tool("diagnostics")
    async def diagnostic_record_probe(
        mind_map_id: str,
        node_id: str,
        quality: int,
        inferred_mastery: float,
        question_text: str = "[diagnostic probe]",
        user_answer: str | None = None,
        evaluator_notes: str | None = None,
    ) -> dict[str, Any]:
        """Record a diagnostic probe result and seed node mastery."""
        return await _diagnostic.diagnostic_record_probe(
            module._get_pool(),
            mind_map_id,
            node_id,
            quality,
            inferred_mastery,
            question_text=question_text,
            user_answer=user_answer,
            evaluator_notes=evaluator_notes,
        )

    @_tool("diagnostics")
    async def diagnostic_complete(
        mind_map_id: str,
    ) -> dict[str, Any]:
        """Finalise the diagnostic and transition flow state to PLANNING."""
        return await _diagnostic.diagnostic_complete(module._get_pool(), mind_map_id)

    # =================================================================
    # Curriculum tools
    # =================================================================

    @_tool("curriculum")
    async def curriculum_generate(
        mind_map_id: str,
        goal: str | None = None,
        diagnostic_results: dict[str, Any] | None = None,
        source_refs: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Validate a concept graph, sort it, sequence it, and annotate pedagogy metadata.

        Assigns each node a ``concept_type`` (factual/procedural/conceptual/creative)
        inferred from its label and description; nodes that cannot be classified
        confidently are left without one.  ``source_refs`` optionally maps node labels
        to registered source material as
        ``{node_label: [{source_id, location, provenance?}]}``; refs naming an
        unregistered source or an unknown label are dropped rather than fabricated.
        """
        return await _curriculum.curriculum_generate(
            module._get_pool(),
            mind_map_id,
            goal=goal,
            diagnostic_results=diagnostic_results,
            source_refs=source_refs,
        )

    @_tool("curriculum")
    async def curriculum_replan(
        mind_map_id: str,
        reason: str | None = None,
    ) -> dict[str, Any]:
        """Re-compute learning sequence based on current mastery state."""
        return await _curriculum.curriculum_replan(module._get_pool(), mind_map_id, reason=reason)

    @_tool("curriculum")
    async def curriculum_next_node(
        mind_map_id: str,
    ) -> dict[str, Any] | None:
        """Return the frontier node with the lowest sequence number."""
        return await _curriculum.curriculum_next_node(module._get_pool(), mind_map_id)

    # =================================================================
    # Analytics tools
    # =================================================================

    @_tool("analytics")
    async def analytics_get_snapshot(
        mind_map_id: str,
        snapshot_date: str | None = None,
    ) -> dict[str, Any]:
        """Return the latest analytics snapshot in a consistent status envelope.

        Always returns a JSON-friendly dict with a ``status`` key so MCP callers
        can branch deterministically:

        - ``status="ok"`` plus the snapshot fields (``snapshot_date`` normalized
          to an ISO-8601 string) when a snapshot exists.
        - ``status="not_found"`` with next-step guidance when none exists.

        The lower-level analytics helper returns ``None`` for the missing case;
        callers need a terminal, self-describing result so they do not retry the
        same empty read in a loop.
        """
        parsed_date: date | None = None
        if snapshot_date is not None:
            parsed_date = date.fromisoformat(snapshot_date)
        snapshot = await _analytics.analytics_get_snapshot(
            module._get_pool(), mind_map_id, date=parsed_date
        )
        if snapshot is not None:
            # Normalize into a consistent, JSON-friendly envelope so MCP callers
            # can branch on ``status`` without guessing the payload shape. The
            # lower-level helper leaves ``snapshot_date`` as a ``datetime.date``;
            # coerce it to an ISO-8601 string here.
            snapshot_date_value = snapshot.get("snapshot_date")
            if isinstance(snapshot_date_value, date):
                snapshot["snapshot_date"] = snapshot_date_value.isoformat()
            return {"status": "ok", **snapshot}
        return {
            "status": "not_found",
            "mind_map_id": mind_map_id,
            "snapshot_date": parsed_date.isoformat() if parsed_date else None,
            "message": (
                "No analytics snapshot exists for this mind map/date. Do not retry the "
                "same analytics_get_snapshot call; use analytics_get_trend, "
                "mastery_get_map_summary, or state that analytics are not available yet."
            ),
        }

    @_tool("analytics")
    async def analytics_get_trend(
        mind_map_id: str,
        days: int = 30,
    ) -> list[dict[str, Any]]:
        """Return a time-series of snapshots within the last N days."""
        return await _analytics.analytics_get_trend(module._get_pool(), mind_map_id, days=days)

    @_tool("analytics")
    async def analytics_get_cross_topic() -> dict[str, Any]:
        """Return comparative analytics across all active mind maps."""
        return await _analytics.analytics_get_cross_topic(module._get_pool())

    # =================================================================
    # Source material tools
    # =================================================================

    @_tool("source_material")
    async def source_material_register(
        title: str,
        type: str,
        authors: list[str] | str | None = None,
        toc: Any | None = None,
        url: str | None = None,
    ) -> dict[str, Any]:
        """Register owner-provided source metadata without fetching its content."""
        return await _source_material.source_material_register(
            module._get_pool(),
            title=title,
            authors=authors,
            type=type,
            toc=toc,
            url=url,
        )

    @_tool("source_material")
    async def source_material_list() -> list[dict[str, Any]]:
        """List registered source metadata, including source IDs."""
        return await _source_material.source_material_list(module._get_pool())

    @_tool("source_material")
    async def source_material_remove(source_id: str) -> dict[str, str]:
        """Remove source metadata while preserving any dangling node references."""
        return await _source_material.source_material_remove(module._get_pool(), source_id)
