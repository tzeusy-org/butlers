"""Education module — wires education domain tools into the butler's MCP server.

Registers 36 MCP tools that delegate to the existing implementations in
``butlers.tools.education``. The tool closures strip ``pool`` and scheduler
callbacks from the MCP-visible signature and inject them from module state
at call time.
"""

from __future__ import annotations

import logging
from typing import Any

from pydantic import BaseModel

from butlers.modules.base import Module, ToolGroupMixin

logger = logging.getLogger(__name__)


class EducationModuleConfig(ToolGroupMixin, BaseModel):
    """Configuration for the Education module.

    Tool groups
    -----------
    mind_maps : mind_map_create, mind_map_get, mind_map_list,
                mind_map_update_status, mind_map_node_create, mind_map_node_get,
                mind_map_node_list, mind_map_node_update, mind_map_edge_create,
                mind_map_edge_delete, mind_map_frontier, mind_map_subtree
    teaching : teaching_flow_start, teaching_flow_get, teaching_flow_advance,
               teaching_flow_abandon, teaching_flow_list
    mastery : mastery_record_response, mastery_get_node_history,
              mastery_get_map_summary, mastery_detect_struggles
    spaced_repetition : spaced_repetition_record_response,
                        spaced_repetition_pending_reviews,
                        spaced_repetition_schedule_cleanup
    diagnostics : diagnostic_start, diagnostic_record_probe,
                  diagnostic_complete
    curriculum : curriculum_generate, curriculum_replan, curriculum_next_node
    analytics : analytics_get_snapshot, analytics_get_trend,
                analytics_get_cross_topic
    source_material : source_material_register, source_material_list,
                      source_material_remove
    """


class EducationModule(Module):
    """Education module providing 36 MCP tools for mind maps, teaching flows,
    mastery tracking, spaced repetition, diagnostics, curriculum, analytics,
    and source-material metadata.
    """

    def __init__(self) -> None:
        self._db: Any = None

    name = "education"

    @property
    def config_schema(self) -> type[BaseModel]:
        return EducationModuleConfig

    async def on_startup(
        self, config: Any, db: Any, credential_store: Any = None, blob_store: Any = None
    ) -> None:
        """Store the Database reference for later pool access."""
        self._db = db

    async def on_shutdown(self) -> None:
        """Clear state references."""
        self._db = None

    def _get_pool(self):
        """Return the asyncpg pool, raising if not initialised."""
        if self._db is None:
            raise RuntimeError("EducationModule not initialised -- no DB available")
        return self._db.pool

    async def register_tools(self, mcp: Any, config: Any, db: Any, butler_name: str) -> None:
        """Register all education MCP tools."""
        self._db = db

        from .tools import register_tools

        register_tools(mcp, self, config)
