"""Conditions and symptoms — track health conditions and log symptoms backed by SPO facts."""

from __future__ import annotations

import logging
import uuid
from datetime import UTC, datetime
from typing import Any

import asyncpg

from butlers.tools.health._helpers import (
    HEALTH_SENSITIVITY_CONFIDENTIAL,
    _get_owner_entity_id,
    _normalize_end_date,
    _row_to_dict,
)

logger = logging.getLogger(__name__)

VALID_CONDITION_STATUSES = {"active", "managed", "resolved"}

_embedding_engine: Any = None


def _get_embedding_engine() -> Any:
    """Lazy-load and return the shared EmbeddingEngine singleton."""
    global _embedding_engine
    if _embedding_engine is None:
        from butlers.modules.memory.tools import get_embedding_engine

        _embedding_engine = get_embedding_engine()
    return _embedding_engine


def _fact_to_condition(row: dict[str, Any]) -> dict[str, Any]:
    """Convert a facts row to the condition API shape."""
    row = _row_to_dict(row)
    meta = row.get("metadata", {})
    return {
        "id": row["id"],  # UUID — matches old DB row behaviour
        "name": meta.get("name", row.get("content", "")),
        "status": meta.get("status", "active"),
        "diagnosed_at": meta.get("diagnosed_at"),
        "notes": meta.get("notes"),
        "created_at": row.get("created_at"),
        "updated_at": row.get("updated_at") or row.get("created_at"),
    }


def _fact_to_symptom(row: dict[str, Any]) -> dict[str, Any]:
    """Convert a facts row to the symptom API shape."""
    row = _row_to_dict(row)
    meta = row.get("metadata", {})
    cond_id = meta.get("condition_id")
    cond_uuid = uuid.UUID(cond_id) if cond_id else None
    return {
        "id": row["id"],  # UUID — matches old DB row behaviour
        "name": row.get("content", ""),
        "severity": meta.get("severity"),
        "condition_id": cond_uuid,
        "notes": meta.get("notes"),
        "occurred_at": row.get("valid_at"),
        "created_at": row.get("created_at"),
    }


async def condition_add(
    pool: asyncpg.Pool,
    name: str,
    status: str = "active",
    diagnosed_at: datetime | None = None,
    notes: str | None = None,
) -> dict[str, Any]:
    """Add a health condition. Status must be one of: active, managed, resolved."""
    if status not in VALID_CONDITION_STATUSES:
        raise ValueError(
            f"Invalid condition status: {status!r}. "
            f"Must be one of: {', '.join(sorted(VALID_CONDITION_STATUSES))}"
        )

    from butlers.modules.memory.storage import store_fact

    embedding_engine = _get_embedding_engine()
    now = datetime.now(UTC)

    content = f"{name}: {status}"
    metadata: dict[str, Any] = {"name": name, "status": status}
    if diagnosed_at is not None:
        metadata["diagnosed_at"] = diagnosed_at.isoformat()
    if notes is not None:
        metadata["notes"] = notes

    # Use a name-keyed subject so multiple conditions coexist as independent
    # property facts. Supersession is keyed on (subject, predicate) ONLY when
    # entity_id is omitted — passing the owner entity_id would make store_fact
    # key supersession on (entity_id, scope, predicate) and IGNORE the subject,
    # so every condition for the owner would collide on (owner, health,
    # condition) and silently supersede the previous one. Therefore do NOT
    # anchor these per-item facts to the owner entity.
    subject = f"condition:{name}"

    fact_id = (
        await store_fact(
            pool,
            subject=subject,
            predicate="condition",
            content=content,
            embedding_engine=embedding_engine,
            permanence="permanent",
            scope="health",
            valid_at=None,  # property fact — supersedes previous for same name
            metadata=metadata,
            sensitivity=HEALTH_SENSITIVITY_CONFIDENTIAL,
        )
    )["id"]

    return {
        "id": fact_id,
        "name": name,
        "status": status,
        "diagnosed_at": diagnosed_at.isoformat() if diagnosed_at is not None else None,
        "notes": notes,
        "created_at": now,
        "updated_at": now,
    }


async def condition_list(
    pool: asyncpg.Pool,
    status: str | None = None,
) -> list[dict[str, Any]]:
    """List conditions, optionally filtered by status. Ordered by created_at descending."""
    conditions: list[str] = [
        "predicate = 'condition'",
        "validity = 'active'",
        "scope = 'health'",
    ]
    params: list[Any] = []
    idx = 1

    if status is not None:
        conditions.append(f"metadata->>'status' = ${idx}")
        params.append(status)
        idx += 1

    where = "WHERE " + " AND ".join(conditions)
    rows = await pool.fetch(
        f"SELECT id, predicate, content, valid_at, created_at, metadata"
        f" FROM facts {where} ORDER BY created_at DESC",
        *params,
    )
    return [_fact_to_condition(dict(r)) for r in rows]


async def condition_update(
    pool: asyncpg.Pool,
    condition_id: str,
    **fields: Any,
) -> dict[str, Any]:
    """Update a condition. Allowed fields: name, status, diagnosed_at, notes.

    If status is provided, it must be one of: active, managed, resolved.
    Implemented as a superseding store_fact (property fact semantics).
    """
    from butlers.modules.memory.storage import store_fact

    cond_uuid = uuid.UUID(condition_id) if isinstance(condition_id, str) else condition_id
    allowed = {"name", "status", "diagnosed_at", "notes"}
    updates = {k: v for k, v in fields.items() if k in allowed}

    if not updates:
        raise ValueError("No valid fields to update")

    # Validate status if provided
    if "status" in updates and updates["status"] not in VALID_CONDITION_STATUSES:
        raise ValueError(
            f"Invalid condition status: {updates['status']!r}. "
            f"Must be one of: {', '.join(sorted(VALID_CONDITION_STATUSES))}"
        )

    # Fetch existing condition fact by ID
    row = await pool.fetchrow(
        "SELECT id, subject, metadata FROM facts"
        " WHERE id = $1 AND predicate = 'condition' AND scope = 'health'",
        cond_uuid,
    )
    if row is None:
        raise ValueError(f"Condition {condition_id} not found")

    row = _row_to_dict(row)
    existing_meta = row.get("metadata", {})
    existing_subject = row["subject"] or f"condition:{existing_meta.get('name', condition_id)}"

    # Merge updates into existing metadata
    new_meta = dict(existing_meta)
    for k, v in updates.items():
        if k == "diagnosed_at" and isinstance(v, datetime):
            new_meta[k] = v.isoformat()
        else:
            new_meta[k] = v

    name = new_meta.get("name", "")
    status = new_meta.get("status", "active")
    content = f"{name}: {status}"

    embedding_engine = _get_embedding_engine()
    now = datetime.now(UTC)

    # Re-store with the same subject key to supersede the previous condition
    # fact. Do NOT pass entity_id: supersession must key on (subject, predicate)
    # so the edit only supersedes THIS condition's prior fact, not every other
    # condition anchored to the owner entity (see condition_add for details).
    new_fact_id = (
        await store_fact(
            pool,
            subject=existing_subject,
            predicate="condition",
            content=content,
            embedding_engine=embedding_engine,
            permanence="permanent",
            scope="health",
            valid_at=None,  # property fact — supersedes the previous
            metadata=new_meta,
            sensitivity=HEALTH_SENSITIVITY_CONFIDENTIAL,
        )
    )["id"]

    return {
        "id": new_fact_id,
        "name": new_meta.get("name"),
        "status": new_meta.get("status"),
        "diagnosed_at": new_meta.get("diagnosed_at"),
        "notes": new_meta.get("notes"),
        "created_at": now,
        "updated_at": now,
    }


async def condition_delete(
    pool: asyncpg.Pool,
    condition_id: str,
) -> bool:
    """Soft-delete a condition by retracting its fact.

    Delegates to ``forget_memory(pool, "fact", id)``, which sets the fact's
    ``validity`` to ``'retracted'`` — the canonical soft-delete path used across
    the memory subsystem.  The fact remains in the database for audit but is
    excluded from all ``validity = 'active'`` read surfaces (including the
    dashboard GET endpoints).  Raises ``ValueError`` if no active condition
    fact with this id exists.
    """
    from butlers.modules.memory.storage import forget_memory

    cond_uuid = uuid.UUID(condition_id) if isinstance(condition_id, str) else condition_id

    row = await pool.fetchrow(
        "SELECT id FROM facts"
        " WHERE id = $1 AND predicate = 'condition' AND scope = 'health'"
        " AND validity = 'active'",
        cond_uuid,
    )
    if row is None:
        raise ValueError(f"Condition {condition_id} not found")

    return await forget_memory(pool, "fact", cond_uuid)


async def _validate_condition_fact(pool: asyncpg.Pool, condition_id: str) -> None:
    """Raise ValueError if no condition fact with this id exists."""
    cond_uuid = uuid.UUID(condition_id) if isinstance(condition_id, str) else condition_id
    row = await pool.fetchrow(
        "SELECT id FROM facts WHERE id = $1 AND predicate = 'condition' AND scope = 'health'",
        cond_uuid,
    )
    if row is None:
        raise ValueError(f"Condition {condition_id} not found")


async def symptom_log(
    pool: asyncpg.Pool,
    name: str,
    severity: int,
    condition_id: str | None = None,
    notes: str | None = None,
    occurred_at: datetime | None = None,
) -> dict[str, Any]:
    """Log a symptom with severity (1-10), optionally linked to a condition."""
    if not (1 <= severity <= 10):
        raise ValueError(f"Severity must be between 1 and 10, got {severity}")

    if condition_id is not None:
        await _validate_condition_fact(pool, condition_id)

    from butlers.modules.memory.storage import store_fact

    owner_entity_id = await _get_owner_entity_id(pool)
    embedding_engine = _get_embedding_engine()
    now = datetime.now(UTC)
    valid_at = occurred_at if occurred_at is not None else now

    metadata: dict[str, Any] = {"severity": severity}
    if condition_id is not None:
        metadata["condition_id"] = str(condition_id)
    if notes is not None:
        metadata["notes"] = notes

    fact_id = (
        await store_fact(
            pool,
            subject="owner",
            predicate="symptom",
            content=name,
            embedding_engine=embedding_engine,
            permanence="permanent",
            scope="health",
            entity_id=owner_entity_id,
            valid_at=valid_at,
            metadata=metadata,
            sensitivity=HEALTH_SENSITIVITY_CONFIDENTIAL,
        )
    )["id"]

    cond_uuid = uuid.UUID(condition_id) if condition_id else None
    return {
        "id": fact_id,
        "name": name,
        "severity": severity,
        "condition_id": cond_uuid,
        "notes": notes,
        "occurred_at": valid_at,
        "created_at": now,
    }


async def symptom_update(
    pool: asyncpg.Pool,
    symptom_id: str,
    **fields: Any,
) -> dict[str, Any]:
    """Update a logged symptom. Allowed fields: name, severity, condition_id,
    notes, occurred_at.

    Symptoms are TEMPORAL facts (``valid_at`` is the occurrence time and
    supersession is skipped for temporal facts), so unlike conditions there is
    no superseding store_fact path keyed on (subject, predicate) — re-storing
    would create a *second* coexisting symptom rather than replacing the first.
    Instead this performs an in-place UPDATE of the existing symptom fact row so
    the edit preserves the same identity and the temporal log keeps exactly one
    entry per logged symptom.

    If ``severity`` is provided it must be between 1 and 10. If ``condition_id``
    is provided it must reference an existing condition fact.
    """
    sym_uuid = uuid.UUID(symptom_id) if isinstance(symptom_id, str) else symptom_id
    allowed = {"name", "severity", "condition_id", "notes", "occurred_at"}
    updates = {k: v for k, v in fields.items() if k in allowed}

    if not updates:
        raise ValueError("No valid fields to update")

    if "severity" in updates:
        sev = updates["severity"]
        if not (1 <= sev <= 10):
            raise ValueError(f"Severity must be between 1 and 10, got {sev}")

    if updates.get("condition_id") is not None:
        await _validate_condition_fact(pool, updates["condition_id"])

    # Fetch existing symptom fact by ID
    row = await pool.fetchrow(
        "SELECT id, content, valid_at, created_at, metadata FROM facts"
        " WHERE id = $1 AND predicate = 'symptom' AND scope = 'health'"
        " AND validity = 'active'",
        sym_uuid,
    )
    if row is None:
        raise ValueError(f"Symptom {symptom_id} not found")

    row = _row_to_dict(row)
    existing_meta = row.get("metadata", {})

    new_meta = dict(existing_meta)
    if "severity" in updates:
        new_meta["severity"] = updates["severity"]
    if "condition_id" in updates:
        if updates["condition_id"] is None:
            new_meta.pop("condition_id", None)
        else:
            new_meta["condition_id"] = str(updates["condition_id"])
    if "notes" in updates:
        if updates["notes"] is None:
            new_meta.pop("notes", None)
        else:
            new_meta["notes"] = updates["notes"]

    name = updates.get("name", row["content"])
    occurred_at = updates.get("occurred_at", row["valid_at"])

    # Repair pre-classification symptom rows as part of the edit, and atomically
    # retire any catalog entry written while the symptom was still ``normal``.
    # Catalog search excludes rows with ``invalid_at`` set.
    await pool.execute(
        "WITH updated AS ("
        " UPDATE facts"
        " SET content = $2, metadata = $3, valid_at = $4, sensitivity = $5"
        " WHERE id = $1"
        " RETURNING id"
        ")"
        " UPDATE public.memory_catalog AS mc"
        " SET confidence = 0, invalid_at = now(), updated_at = now()"
        " FROM updated"
        " WHERE mc.source_schema = current_schema()"
        " AND mc.source_table = 'facts'"
        " AND mc.source_id = updated.id",
        sym_uuid,
        name,
        new_meta,
        occurred_at,
        HEALTH_SENSITIVITY_CONFIDENTIAL,
    )

    cond_id = new_meta.get("condition_id")
    cond_out = uuid.UUID(cond_id) if cond_id else None
    return {
        "id": sym_uuid,
        "name": name,
        "severity": new_meta.get("severity"),
        "condition_id": cond_out,
        "notes": new_meta.get("notes"),
        "occurred_at": occurred_at,
        "created_at": row["created_at"],
    }


async def symptom_delete(
    pool: asyncpg.Pool,
    symptom_id: str,
) -> bool:
    """Soft-delete a logged symptom by retracting its fact.

    Delegates to ``forget_memory(pool, "fact", id)``, which sets the fact's
    ``validity`` to ``'retracted'`` — the canonical soft-delete path used across
    the memory subsystem.  The fact remains in the database for audit but is
    excluded from all ``validity = 'active'`` read surfaces (including the
    dashboard GET endpoints and ``symptom_history`` / ``symptom_search``).
    Raises ``ValueError`` if no active symptom fact with this id exists.
    """
    from butlers.modules.memory.storage import forget_memory

    sym_uuid = uuid.UUID(symptom_id) if isinstance(symptom_id, str) else symptom_id

    row = await pool.fetchrow(
        "SELECT id FROM facts"
        " WHERE id = $1 AND predicate = 'symptom' AND scope = 'health'"
        " AND validity = 'active'",
        sym_uuid,
    )
    if row is None:
        raise ValueError(f"Symptom {symptom_id} not found")

    return await forget_memory(pool, "fact", sym_uuid)


async def symptom_history(
    pool: asyncpg.Pool,
    start_date: datetime | None = None,
    end_date: datetime | None = None,
) -> list[dict[str, Any]]:
    """Get symptom history, optionally filtered by date range."""
    conditions: list[str] = [
        "predicate = 'symptom'",
        "validity = 'active'",
        "scope = 'health'",
    ]
    params: list[Any] = []
    idx = 1

    if start_date is not None:
        conditions.append(f"valid_at >= ${idx}")
        params.append(start_date)
        idx += 1

    if end_date is not None:
        conditions.append(f"valid_at <= ${idx}")
        params.append(_normalize_end_date(end_date))
        idx += 1

    where = "WHERE " + " AND ".join(conditions)
    rows = await pool.fetch(
        f"SELECT id, predicate, content, valid_at, created_at, metadata"
        f" FROM facts {where} ORDER BY valid_at DESC",
        *params,
    )
    return [_fact_to_symptom(dict(r)) for r in rows]


async def symptom_search(
    pool: asyncpg.Pool,
    name: str | None = None,
    min_severity: int | None = None,
    max_severity: int | None = None,
    start_date: datetime | None = None,
    end_date: datetime | None = None,
) -> list[dict[str, Any]]:
    """Search symptoms by name, severity range, and date range.

    Filters are combined with AND logic. Name matching is case-insensitive.
    """
    conditions: list[str] = [
        "predicate = 'symptom'",
        "validity = 'active'",
        "scope = 'health'",
    ]
    params: list[Any] = []
    idx = 1

    if name is not None:
        conditions.append(f"content ILIKE ${idx}")
        params.append(name)
        idx += 1

    if min_severity is not None:
        conditions.append(f"(metadata->>'severity')::int >= ${idx}")
        params.append(min_severity)
        idx += 1

    if max_severity is not None:
        conditions.append(f"(metadata->>'severity')::int <= ${idx}")
        params.append(max_severity)
        idx += 1

    if start_date is not None:
        conditions.append(f"valid_at >= ${idx}")
        params.append(start_date)
        idx += 1

    if end_date is not None:
        conditions.append(f"valid_at <= ${idx}")
        params.append(_normalize_end_date(end_date))
        idx += 1

    where = "WHERE " + " AND ".join(conditions)
    rows = await pool.fetch(
        f"SELECT id, predicate, content, valid_at, created_at, metadata"
        f" FROM facts {where} ORDER BY valid_at DESC",
        *params,
    )
    return [_fact_to_symptom(dict(r)) for r in rows]
