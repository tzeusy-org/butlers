"""Pydantic models for the finance butler API.

Provides models for transactions, subscriptions, bills, accounts,
and spending summaries used by the finance butler's dashboard endpoints.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class TransactionModel(BaseModel):
    """A recorded financial transaction."""

    id: str
    posted_at: str
    merchant: str
    normalized_merchant: str | None = None
    description: str | None = None
    amount: str  # numeric as string to preserve precision
    currency: str
    direction: str
    category: str
    inferred_category: str | None = None
    payment_method: str | None = None
    account_id: str | None = None
    receipt_url: str | None = None
    external_ref: str | None = None
    source_message_id: str | None = None
    metadata: dict = {}
    created_at: str
    updated_at: str


class SubscriptionModel(BaseModel):
    """A tracked recurring subscription commitment."""

    id: str
    service: str
    amount: str
    currency: str
    frequency: str
    next_renewal: str
    status: str
    auto_renew: bool = True
    payment_method: str | None = None
    account_id: str | None = None
    source_message_id: str | None = None
    cancellation_url: str | None = None
    notice_period_days: int | None = None
    cancel_by: str | None = None
    metadata: dict = {}
    created_at: str
    updated_at: str


class BillModel(BaseModel):
    """A tracked payable bill obligation."""

    id: str
    payee: str
    amount: str
    currency: str
    due_date: str
    frequency: str
    status: str
    payment_method: str | None = None
    account_id: str | None = None
    source_message_id: str | None = None
    statement_period_start: str | None = None
    statement_period_end: str | None = None
    paid_at: str | None = None
    metadata: dict = {}
    created_at: str
    updated_at: str


class AccountModel(BaseModel):
    """A tracked financial account."""

    id: str
    institution: str
    type: str
    name: str | None = None
    last_four: str | None = None
    currency: str
    last_synced_at: str | None = None
    feed_degraded: bool
    feed_degraded_reason: Literal["never_synced", "stale"] | None = None
    metadata: dict = {}
    created_at: str
    updated_at: str


class CostClaimModel(BaseModel):
    """One shared typed claim with Finance's latest honest verdict."""

    id: str
    claim_key: str
    asserted_by: str
    kind: str
    direction: str
    amount: str
    currency: str
    counterparty_entity_id: str | None = None
    counterparty_label: str | None = None
    expected_on: str | None = None
    description: str
    asserted_at: str
    superseded_at: str | None = None
    retracted_at: str | None = None
    retraction_reason: str | None = None
    state: str | None = None
    matched_amount: str | None = None
    matched_currency: str | None = None
    match_refs: list[str] = []
    unmatched_reason: str | None = None
    unverifiable_reason: str | None = None
    evidence_horizon_at: str | None = None
    decided_at: str | None = None


class SpendingGroupModel(BaseModel):
    """A spending aggregation bucket (category, merchant, week, or month)."""

    key: str
    amount: str
    count: int


class CurrencySpendingSummaryModel(BaseModel):
    """One non-converted spending aggregate for a single ISO currency."""

    currency: str
    total_spend: str
    groups: list[SpendingGroupModel] = []


class SpendingSummaryModel(BaseModel):
    """Aggregated spending summary over a date range."""

    start_date: str
    end_date: str
    currency: str | None
    total_spend: str
    groups: list[SpendingGroupModel] = []
    by_currency: list[CurrencySpendingSummaryModel] = []
    legacy_aggregate_degraded: bool = False
    degraded_reason: Literal["multiple_currencies_unconverted"] | None = None


class FinanceExpectedSignalModel(BaseModel):
    """Content-blind Finance recurrence measurability state."""

    signal_key: str
    producer: str
    producer_endpoint_identity: str | None
    expected_cadence_seconds: int
    last_observed_at: str | None
    measurability: Literal["present", "absent", "unmeasurable"]
    unmeasurable_reason: str | None
    evaluated_at: str


class FinanceExpectedSignalsResponse(BaseModel):
    """Explicitly degraded envelope; unavailable state is never an all-clear."""

    signals: list[FinanceExpectedSignalModel] | None
    available: bool
    degraded_reason: str | None = None


class ObligationModel(BaseModel):
    """One forward obligation ledger row (bu-8cdl1.10 slice 3), denormalized
    with its subscription's service/amount and cancellation-door status."""

    subscription_id: str
    service: str
    amount: str
    currency: str
    period: str
    cancellation_url: str | None = None
    notice_period_days: int | None = None
    cancel_by: str | None = None
    warn_by: str | None = None
    unknown_door: bool
    price_change_amount: str | None = None
    price_change_direction: Literal["increase", "decrease"] | None = None
    days_remaining_to_act: int | None = None


class ObligationsResponse(BaseModel):
    """Response envelope for GET /obligations. Explicitly degraded, never a
    fabricated all-clear when the ledger read fails (response-conventions
    fleet-wide rule)."""

    items: list[ObligationModel] = []
    count: int = 0
    available: bool = True
    degraded_reason: Literal["obligation_ledger_unavailable"] | None = None


class UpcomingBillItemModel(BaseModel):
    """A bill with urgency classification for the upcoming-bills endpoint."""

    bill: BillModel
    urgency: str
    days_until_due: int


class DistinctMerchantModel(BaseModel):
    """Aggregate row from the distinct-merchants query."""

    merchant: str
    normalized_merchant: str | None = None
    count: int
    total_amount: str  # numeric as string to preserve precision


class BulkUpdateMatchModel(BaseModel):
    """Match criteria for a single bulk-update op."""

    merchant_pattern: str


class BulkUpdateSetModel(BaseModel):
    """Fields to overlay on matching transaction fact metadata."""

    normalized_merchant: str | None = None
    inferred_category: str | None = None


class BulkUpdateOpModel(BaseModel):
    """A single op in a bulk-update request."""

    match: BulkUpdateMatchModel
    set: BulkUpdateSetModel


class BulkUpdateOpResultModel(BaseModel):
    """Result of a single bulk-update op."""

    pattern: str
    set: dict
    matched: int
    updated: int


class BulkUpdateRequestModel(BaseModel):
    """Request body for the bulk-metadata-update endpoint."""

    ops: list[BulkUpdateOpModel]


class BulkUpdateResponseModel(BaseModel):
    """Response from the bulk-metadata-update endpoint."""

    updated_total: int
    results: list[BulkUpdateOpResultModel]


# ---------------------------------------------------------------------------
# Bulk transaction ingestion models
# ---------------------------------------------------------------------------


class BulkTransactionItem(BaseModel):
    """A single normalized transaction in a bulk ingestion request."""

    posted_at: str  # ISO 8601 datetime string (required)
    merchant: str  # required
    amount: str  # string-encoded decimal, required; negative=debit, positive=credit
    currency: str = "USD"
    category: str = "uncategorized"
    description: str | None = None
    payment_method: str | None = None
    account_id: str | None = None  # per-row override; inherits from request-level if absent
    source_message_id: str | None = None
    metadata: dict = {}


class BulkTransactionRequest(BaseModel):
    """Request body for the bulk transaction ingestion endpoint."""

    transactions: list[BulkTransactionItem]
    account_id: str | None = None  # top-level account_id inherited by all rows
    source: str | None = None  # stored as import_source in fact metadata


class BulkTransactionErrorDetail(BaseModel):
    """Per-row error detail in a bulk ingestion response."""

    index: int
    reason: str  # "duplicate", "invalid_date", "invalid_amount", or other


class BulkTransactionResponse(BaseModel):
    """Response from the bulk transaction ingestion endpoint."""

    total: int
    imported: int
    skipped: int
    errors: int
    error_details: list[BulkTransactionErrorDetail] = []
