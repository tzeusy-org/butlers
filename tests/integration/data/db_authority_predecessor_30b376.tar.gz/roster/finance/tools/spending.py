"""Finance butler spending summary — aggregate outflow spend over a date range."""

from __future__ import annotations

import logging
from datetime import date, timedelta
from decimal import Decimal
from typing import Any

import asyncpg

from butlers.tools.finance.transactions import _has_column

logger = logging.getLogger(__name__)

VALID_GROUP_BY_MODES = {"category", "merchant", "week", "month"}


def _current_month_bounds() -> tuple[date, date]:
    """Return (start_date, end_date) for the current calendar month."""
    today = date.today()
    start = today.replace(day=1)
    # End of month: first day of next month minus one day
    if today.month == 12:
        end = date(today.year + 1, 1, 1)
    else:
        end = date(today.year, today.month + 1, 1)
    # end_date is inclusive — use last day of current month
    end = end - timedelta(days=1)
    return start, end


def _iso(d: date) -> str:
    return d.isoformat()


async def spending_summary(
    pool: asyncpg.Pool,
    start_date: date | str | None = None,
    end_date: date | str | None = None,
    group_by: str | None = None,
    category_filter: str | None = None,
    account_id: str | None = None,
) -> dict[str, Any]:
    """Aggregate outflow (debit-direction) spending across a date range.

    Parameters
    ----------
    pool:
        Database connection pool (schema must be set to ``finance``).
    start_date:
        Inclusive start date (ISO-8601 or ``date`` object).
        Defaults to the first day of the current calendar month.
    end_date:
        Inclusive end date (ISO-8601 or ``date`` object).
        Defaults to the last day of the current calendar month.
    group_by:
        How to bucket the results.  Supported values: ``category``,
        ``merchant``, ``week``, ``month``.  When *None* the results are not
        bucketed (single overall group).
    category_filter:
        If supplied, only transactions whose effective category (the
        ``inferred_category`` overlay when present, else the raw ``category``
        column) matches exactly are included.
    account_id:
        If supplied, only transactions linked to this account UUID are included.

    Returns
    -------
    dict
        A ``SpendingSummaryResponse``-shaped dict::

            {
                "start_date": "2026-02-01",
                "end_date": "2026-02-23",
                "currency": "USD",
                "total_spend": "427.50",
                "groups": [
                    {"key": "groceries", "amount": "210.00", "count": 5},
                    ...
                ],
            }

        Amounts are returned as strings so callers can preserve
        ``NUMERIC(14,2)`` precision without floating-point loss.

    Raises
    ------
    ValueError
        If ``group_by`` is not one of the supported grouping modes.
    """
    if group_by is not None and group_by not in VALID_GROUP_BY_MODES:
        raise ValueError(
            f"Unsupported group_by value: {group_by!r}. "
            f"Must be one of: {', '.join(sorted(VALID_GROUP_BY_MODES))}"
        )

    # Resolve date range — default to current calendar month
    if start_date is None or end_date is None:
        default_start, default_end = _current_month_bounds()
        if start_date is None:
            start_date = default_start
        if end_date is None:
            end_date = default_end

    # Normalise to date objects
    if isinstance(start_date, str):
        start_date = date.fromisoformat(start_date)
    if isinstance(end_date, str):
        end_date = date.fromisoformat(end_date)

    # Check whether the deleted_at column exists (added in finance_002 migration).
    has_deleted_at = await _has_column(pool, "transactions", "deleted_at")

    # Build WHERE clauses.
    #
    # Parity with the dashboard API `get_spending_summary` (roster/finance/api/router.py):
    # 'transfer' and 'uncategorized' are NOT real spend — transfers move money between
    # the owner's own accounts and uncategorized is an unclassified bucket. Excluding both
    # — keyed off the effective category (overlay inferred_category preferred, else the raw
    # category column) — and excluding soft-deleted rows keeps the spoken total equal to the
    # dashboard total. The exclusion applies to every group_by dimension, not just category.
    conditions: list[str] = [
        "direction = 'debit'",
        "COALESCE(metadata->>'inferred_category', category) NOT IN ('transfer', 'uncategorized')",
        "posted_at::date >= $1",
        "posted_at::date <= $2",
    ]
    if has_deleted_at:
        conditions.append("deleted_at IS NULL")
    params: list[Any] = [start_date, end_date]
    idx = 3

    if category_filter is not None:
        conditions.append(f"COALESCE(metadata->>'inferred_category', category) = ${idx}")
        params.append(category_filter)
        idx += 1

    if account_id is not None:
        conditions.append(f"account_id = ${idx}::uuid")
        params.append(account_id)
        idx += 1

    where_clause = " AND ".join(conditions)

    currency_rows = await pool.fetch(
        f"""
        SELECT currency, COALESCE(SUM(amount), 0) AS total, COUNT(*) AS count
        FROM transactions
        WHERE {where_clause}
        GROUP BY currency
        ORDER BY currency
        """,
        *params,
    )
    totals_by_currency = {
        str(row["currency"]): {
            "currency": str(row["currency"]),
            "total_spend": str(Decimal(str(row["total"]))),
            "groups": [],
        }
        for row in currency_rows
    }

    grouped_rows: list[Any]

    if group_by is None:
        # No grouping — single bucket covering the whole range
        grouped_rows = [
            {
                "currency": row["currency"],
                "key": "total",
                "amount": row["total"],
                "count": row["count"],
            }
            for row in currency_rows
        ]

    elif group_by == "category":
        # Overlay-aware category, matching the dashboard API group expression.
        group_expr = "COALESCE(metadata->>'inferred_category', category)"
        grouped_rows = await pool.fetch(
            f"""
            SELECT currency, {group_expr} AS key,
                   SUM(amount) AS amount,
                   COUNT(*) AS count
            FROM transactions
            WHERE {where_clause}
            GROUP BY currency, {group_expr}
            ORDER BY currency, amount DESC
            """,
            *params,
        )

    elif group_by == "merchant":
        # Overlay-aware merchant, matching the dashboard API group expression.
        group_expr = "COALESCE(metadata->>'normalized_merchant', merchant)"
        grouped_rows = await pool.fetch(
            f"""
            SELECT currency, {group_expr} AS key,
                   SUM(amount) AS amount,
                   COUNT(*) AS count
            FROM transactions
            WHERE {where_clause}
            GROUP BY currency, {group_expr}
            ORDER BY currency, amount DESC
            """,
            *params,
        )

    elif group_by == "week":
        # ISO week bucket: "YYYY-Www" e.g. "2026-W08"
        grouped_rows = await pool.fetch(
            f"""
            SELECT currency,
                   TO_CHAR(DATE_TRUNC('week', posted_at), 'IYYY-"W"IW') AS key,
                   SUM(amount) AS amount,
                   COUNT(*) AS count
            FROM transactions
            WHERE {where_clause}
            GROUP BY currency, DATE_TRUNC('week', posted_at)
            ORDER BY currency, DATE_TRUNC('week', posted_at) ASC
            """,
            *params,
        )

    elif group_by == "month":
        # Calendar month bucket: "YYYY-MM" e.g. "2026-02"
        grouped_rows = await pool.fetch(
            f"""
            SELECT currency,
                   TO_CHAR(DATE_TRUNC('month', posted_at), 'YYYY-MM') AS key,
                   SUM(amount) AS amount,
                   COUNT(*) AS count
            FROM transactions
            WHERE {where_clause}
            GROUP BY currency, DATE_TRUNC('month', posted_at)
            ORDER BY currency, DATE_TRUNC('month', posted_at) ASC
            """,
            *params,
        )

    legacy_groups: dict[str, dict[str, Any]] = {}
    for row in grouped_rows:
        currency_key = str(row["currency"])
        group = {
            "key": str(row["key"]),
            "amount": str(Decimal(str(row["amount"]))),
            "count": int(row["count"]),
        }
        totals_by_currency[currency_key]["groups"].append(group)
        legacy = legacy_groups.setdefault(
            group["key"], {"key": group["key"], "amount": Decimal("0"), "count": 0}
        )
        legacy["amount"] += Decimal(group["amount"])
        legacy["count"] += group["count"]

    currencies = list(totals_by_currency)
    degraded = len(currencies) > 1
    total_spend = sum(
        (Decimal(item["total_spend"]) for item in totals_by_currency.values()), Decimal("0")
    )
    groups = [
        {"key": item["key"], "amount": str(item["amount"]), "count": item["count"]}
        for item in legacy_groups.values()
    ]
    if group_by in {"week", "month"}:
        groups.sort(key=lambda item: item["key"])
    else:
        groups.sort(key=lambda item: Decimal(item["amount"]), reverse=True)

    return {
        "start_date": _iso(start_date),
        "end_date": _iso(end_date),
        "currency": currencies[0] if len(currencies) == 1 else None,
        "total_spend": str(total_spend),
        "groups": groups,
        "by_currency": list(totals_by_currency.values()),
        "legacy_aggregate_degraded": degraded,
        "degraded_reason": "multiple_currencies_unconverted" if degraded else None,
    }
