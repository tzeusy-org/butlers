"""Tests for finance butler dashboard API endpoints.

Verifies the API contract (status codes, response shapes, filtering, pagination)
for the finance butler's GET endpoints.

Issue: butlers-ee32.8
"""

from __future__ import annotations

import uuid
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from butlers.api.deps import get_db

pytestmark = pytest.mark.unit

# ---------------------------------------------------------------------------
# Load the finance router for dependency override
# ---------------------------------------------------------------------------

_ROUTER_PATH = Path(__file__).parents[1] / "api" / "router.py"


def _load_finance_router():
    """Dynamically load the finance router module."""
    import importlib.util
    import sys

    module_name = "_finance_api_router_test"
    if module_name in sys.modules:
        return sys.modules[module_name]

    spec = importlib.util.spec_from_file_location(module_name, _ROUTER_PATH)
    assert spec is not None and spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = mod
    spec.loader.exec_module(mod)
    return mod


_finance_router_mod = _load_finance_router()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_NOW = datetime.now(tz=UTC)
_TODAY = date.today()
_UUID = str(uuid.uuid4())
_ACCT_UUID = str(uuid.uuid4())


def _tx_row(
    *,
    id: Any = None,
    posted_at: Any = None,
    merchant: str = "Trader Joe's",
    description: str | None = None,
    amount: Any = "55.00",
    currency: str = "USD",
    direction: str = "debit",
    category: str = "groceries",
    payment_method: str | None = None,
    account_id: Any = None,
    receipt_url: str | None = None,
    external_ref: str | None = None,
    source_message_id: str | None = None,
    metadata: dict | None = None,
    overlay_metadata: dict | None = None,
    created_at: Any = None,
    updated_at: Any = None,
) -> dict:
    return {
        "id": uuid.UUID(id) if id else uuid.uuid4(),
        "posted_at": posted_at or _NOW,
        "merchant": merchant,
        "description": description,
        "amount": Decimal(amount),
        "currency": currency,
        "direction": direction,
        "category": category,
        "payment_method": payment_method,
        "account_id": uuid.UUID(account_id) if account_id else None,
        "receipt_url": receipt_url,
        "external_ref": external_ref,
        "source_message_id": source_message_id,
        "metadata": metadata or {},
        # Facts overlay row (bu-v3a4x.1). None when the transaction has no
        # overlay; the LATERAL join produces NULL in that case.
        "overlay_metadata": overlay_metadata,
        "created_at": created_at or _NOW,
        "updated_at": updated_at or _NOW,
    }


def _sub_row(
    *,
    id: Any = None,
    service: str = "Netflix",
    amount: str = "15.49",
    currency: str = "USD",
    frequency: str = "monthly",
    next_renewal: Any = None,
    status: str = "active",
    auto_renew: bool = True,
    payment_method: str | None = None,
    account_id: Any = None,
    source_message_id: str | None = None,
    cancellation_url: str | None = None,
    notice_period_days: int | None = None,
    cancel_by: Any = None,
    metadata: dict | None = None,
    created_at: Any = None,
    updated_at: Any = None,
) -> dict:
    return {
        "id": uuid.UUID(id) if id else uuid.uuid4(),
        "service": service,
        "amount": Decimal(amount),
        "currency": currency,
        "frequency": frequency,
        "next_renewal": next_renewal or (_TODAY + timedelta(days=30)),
        "status": status,
        "auto_renew": auto_renew,
        "payment_method": payment_method,
        "account_id": uuid.UUID(account_id) if account_id else None,
        "source_message_id": source_message_id,
        "cancellation_url": cancellation_url,
        "notice_period_days": notice_period_days,
        "cancel_by": cancel_by,
        "metadata": metadata or {},
        "created_at": created_at or _NOW,
        "updated_at": updated_at or _NOW,
    }


def _obligation_row(
    *,
    subscription_id: Any = None,
    service: str = "Netflix",
    amount: str = "15.49",
    currency: str = "USD",
    period: Any = None,
    cancellation_url: str | None = None,
    notice_period_days: int | None = None,
    cancel_by: Any = None,
    warn_by: Any = None,
    unknown_door: bool = True,
    price_change_amount: Any = None,
    price_change_direction: str | None = None,
) -> dict:
    return {
        "subscription_id": uuid.UUID(subscription_id) if subscription_id else uuid.uuid4(),
        "service": service,
        "amount": Decimal(amount),
        "currency": currency,
        "period": period or (_TODAY + timedelta(days=30)),
        "cancellation_url": cancellation_url,
        "notice_period_days": notice_period_days,
        "cancel_by": cancel_by,
        "warn_by": warn_by,
        "unknown_door": unknown_door,
        "price_change_amount": Decimal(price_change_amount) if price_change_amount else None,
        "price_change_direction": price_change_direction,
    }


def _bill_row(
    *,
    id: Any = None,
    payee: str = "Comcast",
    amount: str = "89.99",
    currency: str = "USD",
    due_date: Any = None,
    frequency: str = "monthly",
    status: str = "pending",
    payment_method: str | None = None,
    account_id: Any = None,
    source_message_id: str | None = None,
    statement_period_start: Any = None,
    statement_period_end: Any = None,
    paid_at: Any = None,
    metadata: dict | None = None,
    created_at: Any = None,
    updated_at: Any = None,
) -> dict:
    return {
        "id": uuid.UUID(id) if id else uuid.uuid4(),
        "payee": payee,
        "amount": Decimal(amount),
        "currency": currency,
        "due_date": due_date or (_TODAY + timedelta(days=7)),
        "frequency": frequency,
        "status": status,
        "payment_method": payment_method,
        "account_id": uuid.UUID(account_id) if account_id else None,
        "source_message_id": source_message_id,
        "statement_period_start": statement_period_start,
        "statement_period_end": statement_period_end,
        "paid_at": paid_at,
        "metadata": metadata or {},
        "created_at": created_at or _NOW,
        "updated_at": updated_at or _NOW,
    }


def _account_row(
    *,
    id: Any = None,
    institution: str = "Chase",
    type: str = "credit",
    name: str | None = "Sapphire",
    last_four: str | None = "4242",
    currency: str = "USD",
    last_synced_at: Any = None,
    metadata: dict | None = None,
    created_at: Any = None,
    updated_at: Any = None,
) -> dict:
    return {
        "id": uuid.UUID(id) if id else uuid.uuid4(),
        "institution": institution,
        "type": type,
        "name": name,
        "last_four": last_four,
        "currency": currency,
        "last_synced_at": last_synced_at,
        "metadata": metadata or {},
        "created_at": created_at or _NOW,
        "updated_at": updated_at or _NOW,
    }


def _make_app(
    *,
    fetch_rows: list | None = None,
    fetchval_return: int | None = 0,
    fetchrow_return: dict | None = None,
):
    """Build a FastAPI test app with a mocked finance DatabaseManager."""
    from fastapi import FastAPI

    mock_pool = AsyncMock()
    mock_pool.fetch = AsyncMock(return_value=fetch_rows or [])
    mock_pool.fetchval = AsyncMock(return_value=fetchval_return)
    mock_pool.fetchrow = AsyncMock(return_value=fetchrow_return)

    mock_db = MagicMock()
    mock_db.pool.return_value = mock_pool

    app = FastAPI()
    app.include_router(_finance_router_mod.router)
    app.dependency_overrides[get_db] = lambda: mock_db

    return app, mock_pool


# ---------------------------------------------------------------------------
# Tests: GET /api/finance/transactions
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_transactions_empty():
    """GET /api/finance/transactions returns empty list when no data."""
    app, _ = _make_app(fetch_rows=[], fetchval_return=0)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/transactions")

    assert response.status_code == 200
    body = response.json()
    assert body["data"] == []
    assert body["meta"]["total"] == 0
    assert body["meta"]["offset"] == 0
    assert body["meta"]["limit"] == 50


@pytest.mark.asyncio
async def test_list_transactions_with_results():
    """GET /api/finance/transactions returns transaction records."""
    rows = [_tx_row(merchant="Netflix", category="subscriptions"), _tx_row()]
    app, _ = _make_app(fetch_rows=rows, fetchval_return=2)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/transactions")

    assert response.status_code == 200
    body = response.json()
    assert body["meta"]["total"] == 2
    assert len(body["data"]) == 2

    item = body["data"][0]
    assert "id" in item
    assert "posted_at" in item
    assert "merchant" in item
    assert "amount" in item
    assert "currency" in item
    assert "direction" in item
    assert "category" in item
    assert "metadata" in item
    assert "created_at" in item
    assert "updated_at" in item


@pytest.mark.asyncio
async def test_list_transactions_pagination_params():
    """GET /api/finance/transactions forwards offset/limit params correctly."""
    app, mock_pool = _make_app(fetch_rows=[], fetchval_return=100)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/transactions?offset=10&limit=5")

    assert response.status_code == 200
    body = response.json()
    assert body["meta"]["total"] == 100
    assert body["meta"]["offset"] == 10
    assert body["meta"]["limit"] == 5


@pytest.mark.asyncio
async def test_list_transactions_excludes_soft_deleted():
    """GET /api/finance/transactions filters out soft-deleted rows (deleted_at IS NULL).

    Spec finance-crud-operations §"Filtered transaction listing" requires every
    transaction read to apply WHERE deleted_at IS NULL. Both the count and the
    row-fetch queries must carry the clause.
    """
    app, mock_pool = _make_app(fetch_rows=[], fetchval_return=0)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/transactions")

    assert response.status_code == 200
    count_sql = mock_pool.fetchval.call_args[0][0]
    fetch_sql = mock_pool.fetch.call_args[0][0]
    assert "deleted_at IS NULL" in count_sql
    assert "deleted_at IS NULL" in fetch_sql


@pytest.mark.asyncio
async def test_list_transactions_filter_by_category():
    """GET /api/finance/transactions filters by category."""
    rows = [_tx_row(category="groceries")]
    app, mock_pool = _make_app(fetch_rows=rows, fetchval_return=1)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/transactions?category=groceries")

    assert response.status_code == 200
    body = response.json()
    assert body["meta"]["total"] == 1
    # Verify category filter was in the query
    call_args = mock_pool.fetchval.call_args[0][0]
    assert "category" in call_args


@pytest.mark.asyncio
async def test_list_transactions_filter_by_merchant():
    """GET /api/finance/transactions filters by merchant substring."""
    rows = [_tx_row(merchant="Amazon")]
    app, mock_pool = _make_app(fetch_rows=rows, fetchval_return=1)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/transactions?merchant=amazon")

    assert response.status_code == 200
    body = response.json()
    assert body["meta"]["total"] == 1
    call_args = mock_pool.fetchval.call_args[0][0]
    assert "ILIKE" in call_args


@pytest.mark.asyncio
async def test_list_transactions_schema_prefix():
    """GET /api/finance/transactions uses finance schema prefix in queries."""
    app, mock_pool = _make_app(fetch_rows=[], fetchval_return=0)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        await client.get("/api/finance/transactions")

    call_args = mock_pool.fetchval.call_args[0][0]
    assert "finance.transactions" in call_args


@pytest.mark.asyncio
async def test_list_transactions_optional_fields():
    """GET /api/finance/transactions maps optional fields correctly."""
    rows = [
        _tx_row(
            description="Prime monthly",
            payment_method="Amex",
            account_id=_ACCT_UUID,
            receipt_url="https://example.com/r",
            external_ref="ext-001",
            source_message_id="msg-001",
            metadata={"order_id": "ORD-123"},
        )
    ]
    app, _ = _make_app(fetch_rows=rows, fetchval_return=1)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/transactions")

    item = response.json()["data"][0]
    assert item["description"] == "Prime monthly"
    assert item["payment_method"] == "Amex"
    assert item["account_id"] == _ACCT_UUID
    assert item["receipt_url"] == "https://example.com/r"
    assert item["external_ref"] == "ext-001"
    assert item["source_message_id"] == "msg-001"
    assert item["metadata"]["order_id"] == "ORD-123"


@pytest.mark.asyncio
async def test_list_transactions_joins_facts_overlay():
    """GET /api/finance/transactions joins the facts overlay on the natural key.

    The split-brain fix (bu-v3a4x.1): overlay edits (normalized_merchant,
    inferred_category, bulk-metadata) live in the bitemporal `facts` store, not
    on `finance.transactions`. The read must LEFT JOIN LATERAL the facts overlay
    keyed on (posted_at, merchant, currency, abs(amount)).
    """
    app, mock_pool = _make_app(fetch_rows=[], fetchval_return=0)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        await client.get("/api/finance/transactions")

    fetch_sql = mock_pool.fetch.call_args[0][0]
    count_sql = mock_pool.fetchval.call_args[0][0]
    for sql in (fetch_sql, count_sql):
        assert "LEFT JOIN LATERAL" in sql
        assert "FROM facts f" in sql
        assert "f.scope = 'finance'" in sql
        assert "f.validity = 'active'" in sql
        # Natural-key join (idempotency-key components).
        assert "f.valid_at = t.posted_at" in sql
        assert "f.metadata->>'merchant' = t.merchant" in sql
        assert "(f.metadata->>'amount')::numeric = abs(t.amount)" in sql


@pytest.mark.asyncio
async def test_list_transactions_overlay_values_win():
    """Overlay normalized_merchant / inferred_category surface over base values.

    Resolves bu-v3a4x.2: these projection columns were structurally always null
    because the dashboard read the transaction's own metadata, which never
    carries overlay edits. They must now populate from the facts overlay. Bulk
    metadata edits in the overlay must also merge into the response metadata.
    """
    rows = [
        _tx_row(
            merchant="STARBUCKS #001",
            category="uncategorized",
            metadata={"order_id": "ORD-9"},
            overlay_metadata={
                "merchant": "STARBUCKS #001",
                "normalized_merchant": "Starbucks",
                "inferred_category": "dining",
                "review_flag": "needs_audit",
            },
        )
    ]
    app, _ = _make_app(fetch_rows=rows, fetchval_return=1)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/transactions")

    assert response.status_code == 200
    item = response.json()["data"][0]
    # Base columns are preserved (overlay is non-destructive).
    assert item["merchant"] == "STARBUCKS #001"
    assert item["category"] == "uncategorized"
    # Overlay-sourced projections now populate (previously always null).
    assert item["normalized_merchant"] == "Starbucks"
    assert item["inferred_category"] == "dining"
    # Bulk-metadata overlay edits merge into the response metadata blob...
    assert item["metadata"]["review_flag"] == "needs_audit"
    # ...without clobbering base metadata...
    assert item["metadata"]["order_id"] == "ORD-9"
    # ...and the projected keys are not duplicated into the metadata blob.
    assert "normalized_merchant" not in item["metadata"]
    assert "inferred_category" not in item["metadata"]


@pytest.mark.asyncio
async def test_list_transactions_no_overlay_falls_back_to_base():
    """A transaction with NO facts overlay falls back to base values (nulls)."""
    rows = [
        _tx_row(
            merchant="Trader Joe's",
            category="groceries",
            metadata={"order_id": "ORD-1"},
            overlay_metadata=None,
        )
    ]
    app, _ = _make_app(fetch_rows=rows, fetchval_return=1)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/transactions")

    assert response.status_code == 200
    item = response.json()["data"][0]
    assert item["merchant"] == "Trader Joe's"
    assert item["category"] == "groceries"
    assert item["normalized_merchant"] is None
    assert item["inferred_category"] is None
    assert item["metadata"] == {"order_id": "ORD-1"}


# ---------------------------------------------------------------------------
# Tests: GET /api/finance/subscriptions
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_subscriptions_empty():
    """GET /api/finance/subscriptions returns empty list when no data."""
    app, _ = _make_app(fetch_rows=[], fetchval_return=0)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/subscriptions")

    assert response.status_code == 200
    body = response.json()
    assert body["data"] == []
    assert body["meta"]["total"] == 0


@pytest.mark.asyncio
async def test_list_subscriptions_with_results():
    """GET /api/finance/subscriptions returns subscription records."""
    rows = [_sub_row(service="Netflix"), _sub_row(service="Spotify", amount="9.99")]
    app, _ = _make_app(fetch_rows=rows, fetchval_return=2)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/subscriptions")

    assert response.status_code == 200
    body = response.json()
    assert body["meta"]["total"] == 2
    assert len(body["data"]) == 2

    item = body["data"][0]
    for field in ("id", "service", "amount", "currency", "frequency", "next_renewal", "status"):
        assert field in item


@pytest.mark.asyncio
async def test_list_subscriptions_cancellation_door_fields_roundtrip():
    """GET /api/finance/subscriptions surfaces the cancellation door fields."""
    rows = [
        _sub_row(
            service="Netflix",
            cancellation_url="https://netflix.com/cancel",
            notice_period_days=30,
            cancel_by=_TODAY + timedelta(days=1),
        )
    ]
    app, _ = _make_app(fetch_rows=rows, fetchval_return=1)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/subscriptions")

    item = response.json()["data"][0]
    assert item["cancellation_url"] == "https://netflix.com/cancel"
    assert item["notice_period_days"] == 30
    assert item["cancel_by"] == str(_TODAY + timedelta(days=1))


@pytest.mark.asyncio
async def test_list_subscriptions_cancellation_door_fields_missing_is_valid():
    """A subscription with no cancellation door metadata renders nulls, not an error."""
    rows = [_sub_row(service="Netflix")]
    app, _ = _make_app(fetch_rows=rows, fetchval_return=1)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/subscriptions")

    assert response.status_code == 200
    item = response.json()["data"][0]
    assert item["cancellation_url"] is None
    assert item["notice_period_days"] is None
    assert item["cancel_by"] is None


@pytest.mark.asyncio
async def test_list_subscriptions_filter_by_status():
    """GET /api/finance/subscriptions filters by status."""
    rows = [_sub_row(status="active")]
    app, mock_pool = _make_app(fetch_rows=rows, fetchval_return=1)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/subscriptions?status=active")

    assert response.status_code == 200
    assert response.json()["meta"]["total"] == 1
    call_args = mock_pool.fetchval.call_args[0][0]
    assert "status" in call_args


@pytest.mark.asyncio
async def test_list_subscriptions_pagination():
    """GET /api/finance/subscriptions respects pagination parameters."""
    app, _ = _make_app(fetch_rows=[], fetchval_return=50)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/subscriptions?offset=20&limit=10")

    body = response.json()
    assert body["meta"]["total"] == 50
    assert body["meta"]["offset"] == 20
    assert body["meta"]["limit"] == 10


@pytest.mark.asyncio
async def test_list_subscriptions_schema_prefix():
    """GET /api/finance/subscriptions uses finance schema prefix."""
    app, mock_pool = _make_app(fetch_rows=[], fetchval_return=0)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        await client.get("/api/finance/subscriptions")

    call_args = mock_pool.fetchval.call_args[0][0]
    assert "finance.subscriptions" in call_args


# ---------------------------------------------------------------------------
# Tests: GET /api/finance/obligations (bu-8cdl1.10 slice 3)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_obligations_empty():
    """GET /api/finance/obligations returns an empty, available envelope."""
    app, _ = _make_app(fetch_rows=[])

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/obligations")

    assert response.status_code == 200
    body = response.json()
    assert body == {"items": [], "count": 0, "available": True, "degraded_reason": None}


@pytest.mark.asyncio
async def test_list_obligations_known_door_carries_warn_and_days_remaining():
    """A known-door row surfaces the door fields and days-remaining-to-act."""
    cancel_by = _TODAY + timedelta(days=3)
    warn_by = _TODAY - timedelta(days=4)
    rows = [
        _obligation_row(
            service="Adobe",
            cancellation_url="https://adobe.com/cancel",
            notice_period_days=7,
            cancel_by=cancel_by,
            warn_by=warn_by,
            unknown_door=False,
        )
    ]
    app, _ = _make_app(fetch_rows=rows)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/obligations")

    assert response.status_code == 200
    item = response.json()["items"][0]
    assert item["service"] == "Adobe"
    assert item["unknown_door"] is False
    assert item["cancellation_url"] == "https://adobe.com/cancel"
    assert item["notice_period_days"] == 7
    assert item["cancel_by"] == str(cancel_by)
    assert item["warn_by"] == str(warn_by)
    assert item["days_remaining_to_act"] == 3


@pytest.mark.asyncio
async def test_list_obligations_unknown_door_renders_null_dates_not_error():
    """A missing-door row renders nulls for cancel_by/warn_by, not an error."""
    rows = [_obligation_row(service="Dropbox", unknown_door=True)]
    app, _ = _make_app(fetch_rows=rows)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/obligations")

    assert response.status_code == 200
    item = response.json()["items"][0]
    assert item["unknown_door"] is True
    assert item["cancel_by"] is None
    assert item["warn_by"] is None
    assert item["days_remaining_to_act"] is None


@pytest.mark.asyncio
async def test_list_obligations_surfaces_price_change_flag():
    """A pre-charge price-change flag round-trips onto the obligation item."""
    rows = [
        _obligation_row(
            service="Adobe",
            price_change_amount="699.00",
            price_change_direction="increase",
        )
    ]
    app, _ = _make_app(fetch_rows=rows)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/obligations")

    item = response.json()["items"][0]
    assert item["price_change_amount"] == "699.00"
    assert item["price_change_direction"] == "increase"


@pytest.mark.asyncio
async def test_list_obligations_failure_is_degraded_not_empty_all_clear():
    """A ledger read failure returns an explicit degraded envelope, never a
    fabricated empty all-clear (response-conventions fleet-wide rule)."""
    app, pool = _make_app()
    pool.fetch.side_effect = RuntimeError("obligation_ledger unavailable")

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/obligations")

    assert response.status_code == 200
    assert response.json() == {
        "items": [],
        "count": 0,
        "available": False,
        "degraded_reason": "obligation_ledger_unavailable",
    }


@pytest.mark.asyncio
async def test_list_obligations_schema_prefix():
    """GET /api/finance/obligations joins the finance schema-qualified tables."""
    app, mock_pool = _make_app(fetch_rows=[])

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        await client.get("/api/finance/obligations")

    call_args = mock_pool.fetch.call_args[0][0]
    assert "finance.obligation_ledger" in call_args
    assert "finance.subscriptions" in call_args


# ---------------------------------------------------------------------------
# Tests: GET /api/finance/bills
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_bills_empty():
    """GET /api/finance/bills returns empty list when no data."""
    app, _ = _make_app(fetch_rows=[], fetchval_return=0)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/bills")

    assert response.status_code == 200
    body = response.json()
    assert body["data"] == []
    assert body["meta"]["total"] == 0


@pytest.mark.asyncio
async def test_list_bills_with_results():
    """GET /api/finance/bills returns bill records."""
    rows = [_bill_row(payee="Comcast"), _bill_row(payee="Rent", amount="2200.00")]
    app, _ = _make_app(fetch_rows=rows, fetchval_return=2)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/bills")

    body = response.json()
    assert body["meta"]["total"] == 2
    assert len(body["data"]) == 2

    item = body["data"][0]
    for field in ("id", "payee", "amount", "currency", "due_date", "frequency", "status"):
        assert field in item


@pytest.mark.asyncio
async def test_list_bills_filter_by_status():
    """GET /api/finance/bills filters by status."""
    rows = [_bill_row(status="pending")]
    app, mock_pool = _make_app(fetch_rows=rows, fetchval_return=1)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/bills?status=pending")

    assert response.status_code == 200
    call_args = mock_pool.fetchval.call_args[0][0]
    assert "status" in call_args


@pytest.mark.asyncio
async def test_list_bills_filter_by_payee():
    """GET /api/finance/bills filters by payee substring."""
    rows = [_bill_row(payee="Comcast")]
    app, mock_pool = _make_app(fetch_rows=rows, fetchval_return=1)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/bills?payee=comcast")

    assert response.status_code == 200
    call_args = mock_pool.fetchval.call_args[0][0]
    assert "ILIKE" in call_args


@pytest.mark.asyncio
async def test_list_bills_pagination():
    """GET /api/finance/bills respects pagination parameters."""
    app, _ = _make_app(fetch_rows=[], fetchval_return=30)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/bills?offset=5&limit=10")

    body = response.json()
    assert body["meta"]["total"] == 30
    assert body["meta"]["offset"] == 5
    assert body["meta"]["limit"] == 10


@pytest.mark.asyncio
async def test_list_bills_schema_prefix():
    """GET /api/finance/bills uses finance schema prefix."""
    app, mock_pool = _make_app(fetch_rows=[], fetchval_return=0)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        await client.get("/api/finance/bills")

    call_args = mock_pool.fetchval.call_args[0][0]
    assert "finance.bills" in call_args


# ---------------------------------------------------------------------------
# Tests: GET /api/finance/accounts
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_cost_claims_projects_unverifiable_reason():
    claim_id = uuid.uuid4()
    rows = [
        {
            "id": claim_id,
            "claim_key": "loan:fact-1",
            "asserted_by": "relationship",
            "kind": "receivable",
            "direction": "inbound",
            "amount": Decimal("25.00"),
            "currency": "SGD",
            "counterparty_entity_id": None,
            "counterparty_label": "Alex",
            "expected_on": None,
            "description": "Lunch",
            "asserted_at": _NOW,
            "superseded_at": None,
            "retracted_at": None,
            "retraction_reason": None,
            "state": "unverifiable",
            "matched_amount": None,
            "matched_currency": None,
            "match_refs": [],
            "unmatched_reason": None,
            "unverifiable_reason": "no_account",
            "evidence_horizon_at": None,
            "decided_at": _NOW,
        }
    ]
    app, _ = _make_app(fetch_rows=rows, fetchval_return=1)
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/cost-claims")

    assert response.status_code == 200
    assert response.json()["data"][0]["unverifiable_reason"] == "no_account"


@pytest.mark.asyncio
async def test_list_cost_claims_keeps_unreviewed_claim_without_fabricating_state():
    row = {
        "id": uuid.uuid4(),
        "claim_key": "loan:fact-unreviewed",
        "asserted_by": "relationship",
        "kind": "receivable",
        "direction": "inbound",
        "amount": Decimal("25.00"),
        "currency": "SGD",
        "counterparty_entity_id": None,
        "counterparty_label": "Alex",
        "expected_on": None,
        "description": "Lunch",
        "asserted_at": _NOW,
        "superseded_at": None,
        "retracted_at": None,
        "retraction_reason": None,
        "state": None,
        "matched_amount": None,
        "matched_currency": None,
        "match_refs": None,
        "unmatched_reason": None,
        "unverifiable_reason": None,
        "evidence_horizon_at": None,
        "decided_at": None,
    }
    app, pool = _make_app(fetch_rows=[row], fetchval_return=1)
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/cost-claims")

    assert response.status_code == 200
    assert response.json()["data"][0]["state"] is None
    assert "LEFT JOIN public.cost_claim_resolutions" in pool.fetch.call_args[0][0]


@pytest.mark.asyncio
async def test_list_accounts_empty():
    """GET /api/finance/accounts returns empty list when no data."""
    app, _ = _make_app(fetch_rows=[], fetchval_return=0)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/accounts")

    assert response.status_code == 200
    body = response.json()
    assert body["data"] == []
    assert body["meta"]["total"] == 0


@pytest.mark.asyncio
async def test_list_accounts_with_results():
    """GET /api/finance/accounts returns account records."""
    rows = [_account_row(institution="Chase"), _account_row(institution="Ally", type="savings")]
    app, _ = _make_app(fetch_rows=rows, fetchval_return=2)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/accounts")

    body = response.json()
    assert body["meta"]["total"] == 2
    assert len(body["data"]) == 2

    item = body["data"][0]
    for field in ("id", "institution", "type", "currency", "metadata"):
        assert field in item


@pytest.mark.asyncio
async def test_list_accounts_surfaces_feed_staleness():
    rows = [
        _account_row(institution="Never", last_synced_at=None),
        _account_row(institution="Fresh", last_synced_at=datetime.now(UTC)),
        _account_row(institution="Stale", last_synced_at=datetime.now(UTC) - timedelta(hours=25)),
    ]
    app, _ = _make_app(fetch_rows=rows, fetchval_return=3)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/accounts")

    by_name = {row["institution"]: row for row in response.json()["data"]}
    assert by_name["Never"]["feed_degraded_reason"] == "never_synced"
    assert by_name["Stale"]["feed_degraded_reason"] == "stale"
    assert by_name["Fresh"]["feed_degraded"] is False
    assert by_name["Fresh"]["last_synced_at"] is not None


@pytest.mark.asyncio
async def test_list_accounts_excludes_inactive():
    """GET /api/finance/accounts filters out inactive accounts (is_active = true).

    accounts.is_active (migration finance_006) gates dashboard visibility;
    deactivated accounts must not appear in reads. The clause must be present
    even with no query filters supplied.
    """
    app, mock_pool = _make_app(fetch_rows=[], fetchval_return=0)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/accounts")

    assert response.status_code == 200
    count_sql = mock_pool.fetchval.call_args[0][0]
    fetch_sql = mock_pool.fetch.call_args[0][0]
    assert "is_active = true" in count_sql
    assert "is_active = true" in fetch_sql


@pytest.mark.asyncio
async def test_list_accounts_filter_by_type():
    """GET /api/finance/accounts filters by account type."""
    rows = [_account_row(type="credit")]
    app, mock_pool = _make_app(fetch_rows=rows, fetchval_return=1)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/accounts?type=credit")

    assert response.status_code == 200
    call_args = mock_pool.fetchval.call_args[0][0]
    assert "type" in call_args


@pytest.mark.asyncio
async def test_list_accounts_pagination():
    """GET /api/finance/accounts respects pagination parameters."""
    app, _ = _make_app(fetch_rows=[], fetchval_return=20)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/accounts?offset=10&limit=5")

    body = response.json()
    assert body["meta"]["total"] == 20
    assert body["meta"]["offset"] == 10
    assert body["meta"]["limit"] == 5


@pytest.mark.asyncio
async def test_list_accounts_schema_prefix():
    """GET /api/finance/accounts uses finance schema prefix."""
    app, mock_pool = _make_app(fetch_rows=[], fetchval_return=0)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        await client.get("/api/finance/accounts")

    call_args = mock_pool.fetchval.call_args[0][0]
    assert "finance.accounts" in call_args


# ---------------------------------------------------------------------------
# Tests: GET /api/finance/spending-summary
# ---------------------------------------------------------------------------


def _spending_fetchrow():
    """Return a mock fetchrow result for spending total/currency."""
    return {"total": Decimal("150.00"), "currency": "USD"}


@pytest.mark.asyncio
async def test_spending_summary_basic_shape():
    """GET /api/finance/spending-summary returns SpendingSummaryModel shape."""
    group_rows = [
        {"key": "groceries", "amount": Decimal("100.00"), "count": 2},
        {"key": "dining", "amount": Decimal("50.00"), "count": 1},
    ]

    app, mock_pool = _make_app(fetchrow_return=_spending_fetchrow())
    mock_pool.fetch = AsyncMock(return_value=group_rows)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/spending-summary")

    assert response.status_code == 200
    body = response.json()
    assert "start_date" in body
    assert "end_date" in body
    assert "currency" in body
    assert "total_spend" in body
    assert "groups" in body
    assert isinstance(body["groups"], list)


@pytest.mark.asyncio
async def test_spending_summary_mixed_currency_is_explicitly_degraded():
    total = {"total": Decimal("180.00"), "currency": None, "currency_count": 2}
    rows = [
        {"currency": "EUR", "key": "groceries", "amount": Decimal("80"), "count": 1},
        {"currency": "USD", "key": "groceries", "amount": Decimal("100"), "count": 1},
    ]
    app, mock_pool = _make_app(fetchrow_return=total)
    mock_pool.fetch = AsyncMock(return_value=rows)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/spending-summary")

    body = response.json()
    assert body["currency"] is None
    assert body["legacy_aggregate_degraded"] is True
    assert body["degraded_reason"] == "multiple_currencies_unconverted"
    assert [item["currency"] for item in body["by_currency"]] == ["EUR", "USD"]


@pytest.mark.asyncio
async def test_spending_summary_excludes_soft_deleted():
    """GET /api/finance/spending-summary excludes soft-deleted debits from totals.

    Spec finance-crud-operations §"Spending aggregation" requires aggregation
    WHERE direction = 'debit' AND deleted_at IS NULL. Both the total fetchrow and
    the grouped fetch query must carry the clause so soft-deleted transactions do
    not inflate spending totals.
    """
    app, mock_pool = _make_app(fetchrow_return=_spending_fetchrow())
    mock_pool.fetch = AsyncMock(return_value=[])

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/spending-summary")

    assert response.status_code == 200
    total_sql = mock_pool.fetchrow.call_args[0][0]
    group_sql = mock_pool.fetch.call_args[0][0]
    assert "deleted_at IS NULL" in total_sql
    assert "direction = 'debit'" in total_sql
    assert "deleted_at IS NULL" in group_sql


@pytest.mark.asyncio
async def test_spending_summary_excludes_transfer_and_uncategorized():
    """GET /api/finance/spending-summary excludes transfer + uncategorized (bu-t5w6w).

    'transfer' moves money between the owner's own accounts and 'uncategorized'
    is an unclassified bucket — neither is real spend. Both the total fetchrow
    and the grouped fetch must carry a NOT IN ('transfer', 'uncategorized')
    guard keyed off the effective category so the 'Top category' KPI and the
    spend total reflect genuine spending only.
    """
    app, mock_pool = _make_app(fetchrow_return=_spending_fetchrow())
    mock_pool.fetch = AsyncMock(return_value=[])

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/spending-summary")

    assert response.status_code == 200
    total_sql = mock_pool.fetchrow.call_args[0][0]
    group_sql = mock_pool.fetch.call_args[0][0]

    for sql in (total_sql, group_sql):
        # Exclusion keyed off the effective (overlay-aware) category: the facts
        # overlay's inferred_category wins, falling back to the base column.
        assert "COALESCE(ovl.overlay_metadata->>'inferred_category', t.category)" in sql
        assert "NOT IN ('transfer', 'uncategorized')" in sql
        # The facts overlay join must be present on both reads.
        assert "LEFT JOIN LATERAL" in sql
        assert "FROM facts f" in sql
        # Prior guards must remain intact.
        assert "direction = 'debit'" in sql
        assert "deleted_at IS NULL" in sql


@pytest.mark.asyncio
async def test_spending_summary_group_by_category():
    """GET /api/finance/spending-summary?group_by=category uses category grouping."""
    group_rows = [{"key": "groceries", "amount": Decimal("80.00"), "count": 3}]

    app, mock_pool = _make_app(fetchrow_return=_spending_fetchrow())
    mock_pool.fetch = AsyncMock(return_value=group_rows)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/spending-summary?group_by=category")

    assert response.status_code == 200
    body = response.json()
    assert body["groups"][0]["key"] == "groceries"
    assert body["groups"][0]["count"] == 3


@pytest.mark.asyncio
async def test_spending_summary_group_by_merchant():
    """GET /api/finance/spending-summary?group_by=merchant uses merchant grouping."""
    group_rows = [{"key": "Netflix", "amount": Decimal("15.49"), "count": 1}]

    app, mock_pool = _make_app(fetchrow_return=_spending_fetchrow())
    mock_pool.fetch = AsyncMock(return_value=group_rows)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/spending-summary?group_by=merchant")

    assert response.status_code == 200
    body = response.json()
    assert body["groups"][0]["key"] == "Netflix"


@pytest.mark.asyncio
async def test_spending_summary_empty_groups():
    """GET /api/finance/spending-summary returns empty groups when no transactions."""
    app, mock_pool = _make_app(fetchrow_return={"total": Decimal("0"), "currency": "USD"})
    mock_pool.fetch = AsyncMock(return_value=[])

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/spending-summary")

    assert response.status_code == 200
    body = response.json()
    assert body["groups"] == []
    assert body["total_spend"] == "0"


@pytest.mark.asyncio
async def test_spending_summary_invalid_group_by():
    """GET /api/finance/spending-summary with invalid group_by returns 422."""
    app, _ = _make_app()

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/spending-summary?group_by=invalid")

    assert response.status_code == 422


@pytest.mark.asyncio
async def test_spending_summary_date_params():
    """GET /api/finance/spending-summary accepts start_date and end_date params."""
    app, mock_pool = _make_app(fetchrow_return=_spending_fetchrow())
    mock_pool.fetch = AsyncMock(return_value=[])

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get(
            "/api/finance/spending-summary?start_date=2026-01-01&end_date=2026-01-31"
        )

    assert response.status_code == 200
    body = response.json()
    assert body["start_date"] == "2026-01-01"
    assert body["end_date"] == "2026-01-31"


# ---------------------------------------------------------------------------
# Tests: GET /api/finance/upcoming-bills
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_upcoming_bills_empty():
    """GET /api/finance/upcoming-bills returns empty items when no bills."""
    app, mock_pool = _make_app(fetch_rows=[])

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/upcoming-bills")

    assert response.status_code == 200
    body = response.json()
    assert body["items"] == []
    assert body["count"] == 0
    assert "total_amount" in body
    assert "days_ahead" in body


@pytest.mark.asyncio
async def test_upcoming_bills_with_results():
    """GET /api/finance/upcoming-bills returns bills with urgency classification."""
    today = date.today()
    rows = [
        _bill_row(payee="Comcast", due_date=today + timedelta(days=5)),
        _bill_row(payee="Rent", amount="2200.00", due_date=today + timedelta(days=1)),
    ]
    app, mock_pool = _make_app(fetch_rows=rows)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/upcoming-bills")

    assert response.status_code == 200
    body = response.json()
    assert body["count"] == 2

    item = body["items"][0]
    assert "bill" in item
    assert "urgency" in item
    assert "days_until_due" in item
    assert item["urgency"] in ("due_today", "due_soon", "upcoming", "overdue")


@pytest.mark.asyncio
async def test_upcoming_bills_urgency_classification():
    """GET /api/finance/upcoming-bills classifies bills correctly by urgency."""
    today = date.today()
    rows = [
        _bill_row(payee="Overdue Bill", due_date=today - timedelta(days=3)),
        _bill_row(payee="Due Today", due_date=today),
        _bill_row(payee="Due Soon", due_date=today + timedelta(days=2)),
        _bill_row(payee="Upcoming", due_date=today + timedelta(days=10)),
    ]
    app, mock_pool = _make_app(fetch_rows=rows)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/upcoming-bills?days_ahead=30")

    body = response.json()
    items = body["items"]
    urgencies = {item["bill"]["payee"]: item["urgency"] for item in items}

    assert urgencies["Overdue Bill"] == "overdue"
    assert urgencies["Due Today"] == "due_today"
    assert urgencies["Due Soon"] == "due_soon"
    assert urgencies["Upcoming"] == "upcoming"


@pytest.mark.asyncio
async def test_upcoming_bills_days_ahead_param():
    """GET /api/finance/upcoming-bills respects days_ahead parameter."""
    app, mock_pool = _make_app(fetch_rows=[])

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/upcoming-bills?days_ahead=7")

    assert response.status_code == 200
    body = response.json()
    assert body["days_ahead"] == 7


@pytest.mark.asyncio
async def test_upcoming_bills_include_overdue_false():
    """GET /api/finance/upcoming-bills?include_overdue=false excludes overdue bills."""
    today = date.today()
    # Row that would be overdue; with include_overdue=false, the query should exclude it
    rows = [_bill_row(payee="Future Bill", due_date=today + timedelta(days=3))]
    app, mock_pool = _make_app(fetch_rows=rows)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/upcoming-bills?include_overdue=false")

    assert response.status_code == 200
    body = response.json()
    assert body["include_overdue"] is False
    # Confirm fetch was called (verifies the query path was taken)
    assert mock_pool.fetch.called


# ---------------------------------------------------------------------------
# Tests: GET /api/finance/merchants/distinct
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_distinct_merchants_empty():
    """GET /api/finance/merchants/distinct returns empty list when no merchants."""
    from unittest.mock import AsyncMock, patch

    mock_facts = MagicMock()
    mock_facts.list_distinct_merchants = AsyncMock(
        return_value={"items": [], "total": 0, "limit": 500, "offset": 0}
    )

    app, _ = _make_app()
    with patch.dict("sys.modules", {"butlers.tools.finance.facts": mock_facts}):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.get("/api/finance/merchants/distinct")

    assert response.status_code == 200
    body = response.json()
    assert body["data"] == []
    assert body["meta"]["total"] == 0


@pytest.mark.asyncio
async def test_list_distinct_merchants_with_results():
    """GET /api/finance/merchants/distinct returns merchant aggregates."""
    from unittest.mock import AsyncMock, patch

    items = [
        {
            "merchant": "STARBUCKS #001",
            "normalized_merchant": "Starbucks",
            "count": 5,
            "total_amount": "25.00",
        },
        {
            "merchant": "AMAZON MKTPL",
            "normalized_merchant": None,
            "count": 2,
            "total_amount": "50.00",
        },
    ]
    mock_facts = MagicMock()
    mock_facts.list_distinct_merchants = AsyncMock(
        return_value={"items": items, "total": 2, "limit": 500, "offset": 0}
    )

    app, _ = _make_app()
    with patch.dict("sys.modules", {"butlers.tools.finance.facts": mock_facts}):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.get("/api/finance/merchants/distinct")

    assert response.status_code == 200
    body = response.json()
    assert body["meta"]["total"] == 2
    assert len(body["data"]) == 2
    first = body["data"][0]
    assert first["merchant"] == "STARBUCKS #001"
    assert first["normalized_merchant"] == "Starbucks"
    assert first["count"] == 5
    assert first["total_amount"] == "25.00"


@pytest.mark.asyncio
async def test_list_distinct_merchants_passes_filters():
    """GET /api/finance/merchants/distinct forwards query params to facts layer."""
    from unittest.mock import AsyncMock, patch

    mock_facts = MagicMock()
    mock_facts.list_distinct_merchants = AsyncMock(
        return_value={"items": [], "total": 0, "limit": 10, "offset": 5}
    )

    app, _ = _make_app()
    with patch.dict("sys.modules", {"butlers.tools.finance.facts": mock_facts}):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.get(
                "/api/finance/merchants/distinct"
                "?min_count=3&unnormalized_only=true&limit=10&offset=5"
            )

    assert response.status_code == 200
    call_kwargs = mock_facts.list_distinct_merchants.call_args[1]
    assert call_kwargs["min_count"] == 3
    assert call_kwargs["unnormalized_only"] is True
    assert call_kwargs["limit"] == 10
    assert call_kwargs["offset"] == 5


# ---------------------------------------------------------------------------
# Tests: PATCH /api/finance/transactions/bulk-metadata
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bulk_update_transactions_success():
    """PATCH /api/finance/transactions/bulk-metadata applies overlay and returns results."""
    from unittest.mock import AsyncMock, patch

    mock_facts = MagicMock()
    mock_facts.bulk_update_transactions = AsyncMock(
        return_value={
            "updated_total": 3,
            "results": [
                {
                    "pattern": "STARBUCKS%",
                    "set": {"normalized_merchant": "Starbucks"},
                    "matched": 3,
                    "updated": 3,
                }
            ],
        }
    )

    app, _ = _make_app()
    with patch.dict("sys.modules", {"butlers.tools.finance.facts": mock_facts}):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.patch(
                "/api/finance/transactions/bulk-metadata",
                json={
                    "ops": [
                        {
                            "match": {"merchant_pattern": "STARBUCKS%"},
                            "set": {"normalized_merchant": "Starbucks"},
                        }
                    ]
                },
            )

    assert response.status_code == 200
    body = response.json()
    assert body["updated_total"] == 3
    assert len(body["results"]) == 1
    assert body["results"][0]["pattern"] == "STARBUCKS%"


@pytest.mark.asyncio
async def test_bulk_update_transactions_empty_ops():
    """PATCH /api/finance/transactions/bulk-metadata with empty ops returns 200."""
    from unittest.mock import AsyncMock, patch

    mock_facts = MagicMock()
    mock_facts.bulk_update_transactions = AsyncMock(
        return_value={"updated_total": 0, "results": []}
    )

    app, _ = _make_app()
    with patch.dict("sys.modules", {"butlers.tools.finance.facts": mock_facts}):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.patch(
                "/api/finance/transactions/bulk-metadata",
                json={"ops": []},
            )

    assert response.status_code == 200
    body = response.json()
    assert body["updated_total"] == 0


@pytest.mark.asyncio
async def test_bulk_update_transactions_too_many_ops():
    """PATCH /api/finance/transactions/bulk-metadata with >200 ops returns 422."""
    from unittest.mock import AsyncMock, patch

    mock_facts = MagicMock()
    mock_facts.bulk_update_transactions = AsyncMock(
        return_value={"updated_total": 0, "results": []}
    )

    ops = [
        {"match": {"merchant_pattern": f"MERCHANT{i}%"}, "set": {"normalized_merchant": "X"}}
        for i in range(201)
    ]

    app, _ = _make_app()
    with patch.dict("sys.modules", {"butlers.tools.finance.facts": mock_facts}):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.patch(
                "/api/finance/transactions/bulk-metadata",
                json={"ops": ops},
            )

    assert response.status_code == 422


@pytest.mark.asyncio
async def test_bulk_update_transactions_value_error_422():
    """PATCH /api/finance/transactions/bulk-metadata propagates ValueError as 422."""
    from unittest.mock import AsyncMock, patch

    mock_facts = MagicMock()
    mock_facts.bulk_update_transactions = AsyncMock(
        side_effect=ValueError("set keys ['merchant'] are not allowed")
    )

    app, _ = _make_app()
    with patch.dict("sys.modules", {"butlers.tools.finance.facts": mock_facts}):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.patch(
                "/api/finance/transactions/bulk-metadata",
                json={
                    "ops": [
                        {
                            "match": {"merchant_pattern": "STARBUCKS%"},
                            "set": {"normalized_merchant": "Starbucks"},
                        }
                    ]
                },
            )

    assert response.status_code == 422


# ---------------------------------------------------------------------------
# Tests: 503 when pool not available
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_transactions_503_when_pool_unavailable():
    """GET /api/finance/transactions returns 503 when DB pool is not available."""
    from fastapi import FastAPI

    mock_db = MagicMock()
    mock_db.pool.side_effect = KeyError("finance")

    app = FastAPI()
    app.include_router(_finance_router_mod.router)
    app.dependency_overrides[get_db] = lambda: mock_db

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/transactions")

    assert response.status_code == 503


@pytest.mark.asyncio
async def test_subscriptions_503_when_pool_unavailable():
    """GET /api/finance/subscriptions returns 503 when DB pool is not available."""
    from fastapi import FastAPI

    mock_db = MagicMock()
    mock_db.pool.side_effect = KeyError("finance")

    app = FastAPI()
    app.include_router(_finance_router_mod.router)
    app.dependency_overrides[get_db] = lambda: mock_db

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/subscriptions")

    assert response.status_code == 503


@pytest.mark.asyncio
async def test_obligations_503_when_pool_unavailable():
    """GET /api/finance/obligations returns 503 when DB pool is not available."""
    from fastapi import FastAPI

    mock_db = MagicMock()
    mock_db.pool.side_effect = KeyError("finance")

    app = FastAPI()
    app.include_router(_finance_router_mod.router)
    app.dependency_overrides[get_db] = lambda: mock_db

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/obligations")

    assert response.status_code == 503


# ---------------------------------------------------------------------------
# Tests: POST /api/finance/transactions/bulk — bulk transaction ingestion
# ---------------------------------------------------------------------------

_BULK_TXN = {
    "posted_at": "2026-01-15T10:00:00Z",
    "merchant": "Trader Joe's",
    "amount": "-55.00",
    "currency": "USD",
    "category": "groceries",
}


def _make_bulk_facts_mock(result: dict) -> MagicMock:
    """Return a mock canonical finance facts module with bulk_record_transactions."""
    mock_facts = MagicMock()
    mock_facts.bulk_record_transactions = AsyncMock(return_value=result)
    return mock_facts


@pytest.mark.asyncio
async def test_bulk_ingest_transactions_success():
    """POST /api/finance/transactions/bulk imports rows and returns counts."""
    mock_facts = _make_bulk_facts_mock(
        {
            "total": 2,
            "imported": 2,
            "skipped": 0,
            "errors": 0,
            "error_details": [],
        }
    )

    app, _ = _make_app()
    with patch.dict("sys.modules", {"butlers.tools.finance.facts": mock_facts}):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.post(
                "/api/finance/transactions/bulk",
                json={
                    "transactions": [
                        _BULK_TXN,
                        {
                            **_BULK_TXN,
                            "merchant": "Whole Foods",
                            "posted_at": "2026-01-16T00:00:00Z",
                        },
                    ]
                },
            )

    assert response.status_code == 200
    body = response.json()
    assert body["imported"] == 2
    assert body["skipped"] == 0
    assert body["errors"] == 0
    assert body["total"] == 2
    assert body["error_details"] == []


@pytest.mark.asyncio
async def test_bulk_ingest_transactions_second_batch_all_skipped():
    """POST /api/finance/transactions/bulk — submitting same batch twice, second run all skipped."""
    mock_facts = _make_bulk_facts_mock(
        {
            "total": 1,
            "imported": 0,
            "skipped": 1,
            "errors": 0,
            "error_details": [{"index": 0, "reason": "duplicate"}],
        }
    )

    app, _ = _make_app()
    with patch.dict("sys.modules", {"butlers.tools.finance.facts": mock_facts}):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.post(
                "/api/finance/transactions/bulk",
                json={"transactions": [_BULK_TXN]},
            )

    assert response.status_code == 200
    body = response.json()
    assert body["imported"] == 0
    assert body["skipped"] == 1
    assert body["total"] == 1
    assert body["error_details"][0]["reason"] == "duplicate"


@pytest.mark.asyncio
async def test_bulk_ingest_transactions_per_row_errors():
    """POST /api/finance/transactions/bulk — mixed valid/invalid rows returns partial success."""
    mock_facts = _make_bulk_facts_mock(
        {
            "total": 3,
            "imported": 1,
            "skipped": 0,
            "errors": 2,
            "error_details": [
                {"index": 0, "reason": "invalid_date"},
                {"index": 2, "reason": "missing_merchant"},
            ],
        }
    )

    app, _ = _make_app()
    with patch.dict("sys.modules", {"butlers.tools.finance.facts": mock_facts}):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.post(
                "/api/finance/transactions/bulk",
                json={
                    "transactions": [
                        {**_BULK_TXN, "posted_at": "not-a-date"},  # row 0: bad date
                        _BULK_TXN,  # row 1: valid
                        {**_BULK_TXN, "merchant": ""},  # row 2: missing merchant
                    ]
                },
            )

    assert response.status_code == 200
    body = response.json()
    assert body["imported"] == 1
    assert body["errors"] == 2
    assert body["error_details"][0]["reason"] == "invalid_date"
    assert body["error_details"][1]["reason"] == "missing_merchant"


@pytest.mark.asyncio
async def test_bulk_ingest_transactions_too_many_rows_422():
    """POST /api/finance/transactions/bulk with >500 rows returns 422."""
    app, _ = _make_app()

    transactions = [_BULK_TXN] * 501

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.post(
            "/api/finance/transactions/bulk",
            json={"transactions": transactions},
        )

    assert response.status_code == 422


@pytest.mark.asyncio
async def test_bulk_ingest_transactions_account_id_inheritance():
    """POST /api/finance/transactions/bulk — top-level account_id inherited by rows."""
    acct_id = str(uuid.uuid4())
    mock_facts = _make_bulk_facts_mock(
        {"total": 1, "imported": 1, "skipped": 0, "errors": 0, "error_details": []}
    )

    app, _ = _make_app()
    with patch.dict("sys.modules", {"butlers.tools.finance.facts": mock_facts}):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.post(
                "/api/finance/transactions/bulk",
                json={"transactions": [_BULK_TXN], "account_id": acct_id},
            )

    assert response.status_code == 200
    # Verify account_id was passed down to the tool layer
    call_kwargs = mock_facts.bulk_record_transactions.call_args
    assert call_kwargs[1]["account_id"] == acct_id or (
        len(call_kwargs[0]) > 2 and call_kwargs[0][2] == acct_id
    )


@pytest.mark.asyncio
async def test_bulk_ingest_transactions_source_metadata():
    """POST /api/finance/transactions/bulk — source label passed to tool layer."""
    mock_facts = _make_bulk_facts_mock(
        {"total": 1, "imported": 1, "skipped": 0, "errors": 0, "error_details": []}
    )

    app, _ = _make_app()
    with patch.dict("sys.modules", {"butlers.tools.finance.facts": mock_facts}):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.post(
                "/api/finance/transactions/bulk",
                json={"transactions": [_BULK_TXN], "source": "csv_import"},
            )

    assert response.status_code == 200
    call_kwargs = mock_facts.bulk_record_transactions.call_args
    assert call_kwargs[1]["source"] == "csv_import" or (
        len(call_kwargs[0]) > 3 and call_kwargs[0][3] == "csv_import"
    )


@pytest.mark.asyncio
async def test_bulk_ingest_transactions_empty_batch_422():
    """POST /api/finance/transactions/bulk with empty transactions list returns 422."""
    app, _ = _make_app()

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.post(
            "/api/finance/transactions/bulk",
            json={"transactions": []},
        )

    assert response.status_code == 422


@pytest.mark.asyncio
async def test_bulk_ingest_transactions_503_when_pool_unavailable():
    """POST /api/finance/transactions/bulk returns 503 when DB pool not available."""
    from fastapi import FastAPI

    mock_db = MagicMock()
    mock_db.pool.side_effect = KeyError("finance")

    app = FastAPI()
    app.include_router(_finance_router_mod.router)
    app.dependency_overrides[get_db] = lambda: mock_db

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.post(
            "/api/finance/transactions/bulk",
            json={"transactions": [_BULK_TXN]},
        )

    assert response.status_code == 503


@pytest.mark.asyncio
async def test_bulk_ingest_transactions_value_error_propagates_422():
    """POST /api/finance/transactions/bulk propagates ValueError from tool as 422."""
    mock_facts = MagicMock()
    mock_facts.bulk_record_transactions = AsyncMock(
        side_effect=ValueError("Batch too large: 999 exceeds maximum of 500")
    )

    app, _ = _make_app()
    with patch.dict("sys.modules", {"butlers.tools.finance.facts": mock_facts}):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.post(
                "/api/finance/transactions/bulk",
                json={"transactions": [_BULK_TXN]},
            )

    assert response.status_code == 422


@pytest.mark.asyncio
async def test_expected_signals_exposes_unmeasurable_state_without_payment_claim():
    app, pool = _make_app(
        fetch_rows=[
            {
                "signal_key": "finance:recurrence:group-1",
                "producer": "connector:gmail",
                "producer_endpoint_identity": "gmail:user:owner@example.invalid",
                "expected_cadence_seconds": 2_592_000,
                "last_observed_at": _NOW,
                "measurability": "unmeasurable",
                "unmeasurable_reason": "producer_stale_or_offline",
                "evaluated_at": _NOW,
            }
        ]
    )

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/expected-signals")

    assert response.status_code == 200
    body = response.json()
    assert body["available"] is True
    assert body["signals"][0]["measurability"] == "unmeasurable"
    assert "payment" not in str(body).lower()
    assert "signal_key LIKE 'finance:%'" in pool.fetch.await_args.args[0]


@pytest.mark.asyncio
async def test_expected_signals_failure_is_degraded_not_empty_all_clear():
    app, pool = _make_app()
    pool.fetch.side_effect = RuntimeError("projection unavailable")

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/finance/expected-signals")

    assert response.status_code == 200
    assert response.json() == {
        "signals": None,
        "available": False,
        "degraded_reason": "expected_signals_unavailable",
    }
