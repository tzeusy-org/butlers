"""Regression coverage for Chronicler MCP module startup configuration."""

from __future__ import annotations

from pathlib import Path

import pytest

from butlers.config import load_config
from butlers.daemon import ButlerDaemon
from butlers.lifecycle import StartupState, _startup_modules

pytestmark = pytest.mark.unit

ROSTER_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[3]


async def test_chronicler_mcp_module_is_selected_for_startup() -> None:
    """The day-close prompt depends on the ``chronicler_day_close_bundle`` MCP tool."""
    config_dir = ROSTER_DIR
    config = load_config(config_dir)

    assert config.modules.get("chronicler") == {}

    daemon = ButlerDaemon(config_dir=config_dir)
    daemon.config = config
    await _startup_modules(daemon, StartupState())
    selected_names = {module.name for module in daemon._modules}

    assert "chronicler" in selected_names


def test_day_close_prompt_keeps_prose_human_readable() -> None:
    """Scheduled day-close prompt should not ask for raw refs in user prose."""
    config = load_config(ROSTER_DIR)
    task = next(t for t in config.schedules if t.name == "chronicler_day_close")
    prompt = task.prompt or ""
    normalized_prompt = " ".join(prompt.lower().split())

    assert "trusted scheduled target" in normalized_prompt
    assert "do not recompute" in normalized_prompt
    assert "compute yesterday's local date" not in normalized_prompt
    assert "Does not print raw source_ref values" in prompt
    assert "system records provenance" in prompt
    assert "human-facing message" in prompt
    assert "episodes_truncated" in prompt
    assert "cites source_ref values" not in prompt.lower()


def test_day_close_system_prompt_requires_trusted_date_and_timezone() -> None:
    """Runtime guidance cannot weaken the scheduler's exact tuple binding."""
    prompt = " ".join((ROSTER_DIR / "AGENTS.md").read_text().lower().split())

    assert "trusted scheduled target" in prompt
    assert "date_label" in prompt
    assert "timezone" in prompt
    assert "do not recompute" in prompt
