"""Chronicler butler endpoints.

Read and correction API at ``/api/chronicler/*`` — distinct from the
operational ``/api/timeline`` cross-butler event stream. All responses
carry provenance fields (source_name, source_ref, precision, privacy)
per RFC 0014 §D7.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
import zoneinfo
from collections import defaultdict
from datetime import UTC, date, datetime, timedelta
from datetime import time as dt_time
from typing import Annotated, Any, Protocol
from uuid import UUID

from fastapi import APIRouter, Body, Depends, HTTPException, Query, Request, Response
from fastapi.responses import JSONResponse
from opentelemetry import trace

from butlers.api.audit_emit import authenticated_principal, emit_dashboard_audit
from butlers.api.db import DatabaseManager
from butlers.api.deps import ButlerUnreachableError, Db, MCPClientManager, get_mcp_manager
from butlers.api.models import (
    ApiResponse,
    ErrorDetail,
    ErrorResponse,
    PaginatedResponse,
    PaginationMeta,
)
from butlers.chronicler.adapters.comms import CHANNEL_LABELS
from butlers.chronicler.adapters.sessions import (
    EXCLUDED_TRIGGER_SOURCE_PREFIX,
    EXCLUDED_TRIGGER_SOURCES,
)
from butlers.chronicler.aggregations import (
    LANES,
    category_for,
    lane_for_activity,
    lane_for_category,
    sources_for_lane,
    union_seconds,
    untracked_seconds_for_window,
)
from butlers.chronicler.balance import (
    DEFAULT_BASELINE_LOOKBACK_DAYS,
    compute_daily_balance,
    compute_lane_streak,
    is_lane_anomalous,
)
from butlers.chronicler.day_close_cache import (
    InvalidDayCloseTimezoneError,
    MissingDayCloseTimezoneError,
    day_close_cache_key,
    resolve_day_close_timezone,
)
from butlers.chronicler.editorial import WAKING_HOUR_END, WAKING_HOUR_START, day_window_utc
from butlers.chronicler.models import RoutineOrigin
from butlers.chronicler.prose_admission import classify_day_close_candidate
from butlers.chronicler.rollups import DEFAULT_TIMEZONE as ROLLUPS_DEFAULT_TIMEZONE
from butlers.chronicler.storage import (
    create_declared_routine,
    delete_routine,
    get_routine,
    list_daily_rollup_flags_range,
    list_daily_rollups_range,
    list_routines,
    update_routine,
    upsert_tier2_cache,
)
from butlers.roster_imports import roster_module

_models = roster_module("chronicler", "api/models", api_source=__file__)

ChroniclerPointEvent = _models.ChroniclerPointEvent
ChroniclerEpisode = _models.ChroniclerEpisode
ChroniclerOverride = _models.ChroniclerOverride
SourceStateRow = _models.SourceStateRow
SubsourceCheckpoint = _models.SubsourceCheckpoint
SubmitCorrectionRequest = _models.SubmitCorrectionRequest
ResolveGapInterviewRequest = _models.ResolveGapInterviewRequest
AggregateByDayRow = _models.AggregateByDayRow
SourceBreakdownEntry = _models.SourceBreakdownEntry
CategoryBucket = _models.CategoryBucket
CategoryBuckets = _models.CategoryBuckets
DayCloseFreshResponse = _models.DayCloseFreshResponse
DayCloseStaleResponse = _models.DayCloseStaleResponse
DayCloseInvalidResponse = _models.DayCloseInvalidResponse
DayCloseRefreshRequest = _models.DayCloseRefreshRequest
DayCloseRefreshResponse = _models.DayCloseRefreshResponse
DayCloseRefreshQuietResponse = _models.DayCloseRefreshQuietResponse
EpisodeExplainResponse = _models.EpisodeExplainResponse
OpsSessionRow = _models.OpsSessionRow
ProjectionHealthRow = _models.ProjectionHealthRow
ChroniclesAttentionItem = _models.ChroniclesAttentionItem
ChroniclesBriefing = _models.ChroniclesBriefing
ChroniclesBriefingSubqueryAvailability = _models.ChroniclesBriefingSubqueryAvailability
ChroniclesKpi = _models.ChroniclesKpi
ChroniclesLaneHours = _models.ChroniclesLaneHours
ChroniclesRecentDay = _models.ChroniclesRecentDay
ChroniclesStreaks = _models.ChroniclesStreaks
EvidenceChainLink = _models.EvidenceChainLink
ActivityEvidenceChain = _models.ActivityEvidenceChain
CorrectionPrompt = _models.CorrectionPrompt
CorrectionPrompts = _models.CorrectionPrompts
RoutineRow = _models.RoutineRow
CreateRoutineRequest = _models.CreateRoutineRequest
UpdateRoutineRequest = _models.UpdateRoutineRequest
RollupLaneRow = _models.RollupLaneRow
RollupFlagRow = _models.RollupFlagRow
RollupDay = _models.RollupDay
RollupsResponse = _models.RollupsResponse
BalanceLaneRow = _models.BalanceLaneRow
BalanceResponse = _models.BalanceResponse
TrendLaneDay = _models.TrendLaneDay
TrendLaneSeries = _models.TrendLaneSeries
TrendAnomaly = _models.TrendAnomaly
TrendsResponse = _models.TrendsResponse
CompanionEntry = _models.CompanionEntry
WhoYouWereWithResponse = _models.WhoYouWereWithResponse

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/chronicler", tags=["chronicler"])

BUTLER_DB = "chronicler"


class DayCloseDispatchCallable(Protocol):
    """Protocol for the day-close dispatch callable injected via _get_day_close_dispatch_fn.

    Accepts a prompt string and returns a SpawnerResult-compatible object.
    The handler calls write_day_close_cache() with the result.
    """

    async def __call__(self, *, prompt: str, trigger_source: str) -> Any: ...


def _get_day_close_dispatch_fn() -> DayCloseDispatchCallable | None:
    """Dependency stub — returns None by default.

    Returns None when running without an in-process spawner (e.g. standalone
    API mode, tests).  Override via ``app.dependency_overrides`` to inject the
    real spawner dispatch when the butler daemon is available.

    When None, the refresh endpoint returns 503.
    """
    return None


def _pool(db: DatabaseManager):
    try:
        return db.pool(BUTLER_DB)
    except KeyError as exc:
        raise HTTPException(
            status_code=503,
            detail="Chronicler butler database is not available",
        ) from exc


def _coerce_payload(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            loaded = json.loads(value)
        except json.JSONDecodeError:
            return {"raw": value}
        if isinstance(loaded, dict):
            return loaded
        return {"raw": loaded}
    return {"raw": value}


def _row_to_episode(row: Any) -> ChroniclerEpisode:
    payload = _coerce_payload(row["payload"])
    keys = row.keys()
    raw_ids = row["participant_entity_ids"] if "participant_entity_ids" in keys else None
    participant_entity_ids = [str(uid) for uid in raw_ids] if raw_ids is not None else []
    return ChroniclerEpisode(
        id=str(row["id"]),
        source_name=row["source_name"],
        source_ref=row["source_ref"],
        episode_type=row["episode_type"],
        start_at=row["start_at"],
        end_at=row["end_at"],
        precision=row["precision"],
        title=row["title"],
        payload=payload,
        privacy=row["privacy"],
        retention_days=row["retention_days"],
        tombstone_at=row["tombstone_at"],
        canonical_start_at=row["canonical_start_at"],
        canonical_end_at=row["canonical_end_at"],
        canonical_title=row["canonical_title"],
        canonical_privacy=row["canonical_privacy"],
        corrected_at=row["corrected_at"],
        correction_note=row["correction_note"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        # The episode payload carries its life-balance Activity lane (Work,
        # Play, …) — not the raw source category. Intent/unmapped rows have no
        # lane and surface as "other" for display.
        category=lane_for_category(
            category_for(
                row["source_name"],
                row["episode_type"],
                trigger_source=payload.get("trigger_source"),
            )
        )
        or "other",
        participant_entity_ids=participant_entity_ids,
    )


def _row_to_point_event(row: Any) -> ChroniclerPointEvent:
    return ChroniclerPointEvent(
        id=str(row["id"]),
        source_name=row["source_name"],
        source_ref=row["source_ref"],
        event_type=row["event_type"],
        occurred_at=row["occurred_at"],
        precision=row["precision"],
        title=row["title"],
        payload=_coerce_payload(row["payload"]),
        privacy=row["privacy"],
        retention_days=row["retention_days"],
        tombstone_at=row["tombstone_at"],
        canonical_occurred_at=row["canonical_occurred_at"],
        canonical_title=row["canonical_title"],
        canonical_privacy=row["canonical_privacy"],
        corrected_at=row["corrected_at"],
        correction_note=row["correction_note"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
    )


def _row_to_override(row: Any) -> ChroniclerOverride:
    return ChroniclerOverride(
        id=str(row["id"]),
        target_kind=row["target_kind"],
        target_id=str(row["target_id"]),
        corrected_start_at=row["corrected_start_at"],
        corrected_end_at=row["corrected_end_at"],
        corrected_title=row["corrected_title"],
        corrected_privacy=row["corrected_privacy"],
        corrected_tombstone_at=row["corrected_tombstone_at"],
        note=row["note"],
        submitted_by=row["submitted_by"],
        created_at=row["created_at"],
    )


# ── GET /api/chronicler/events ────────────────────────────────────────────


@router.get("/events", response_model=PaginatedResponse[ChroniclerPointEvent])
async def list_events(
    source_name: str | None = Query(None, description="Filter by source adapter"),
    event_type: str | None = Query(None, description="Filter by event type"),
    since: datetime | None = Query(None, description="occurred_at >= since"),
    until: datetime | None = Query(None, description="occurred_at < until"),
    include_tombstoned: bool = Query(False),
    offset: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=500),
    *,
    db: Db,
) -> PaginatedResponse[ChroniclerPointEvent]:
    pool = _pool(db)

    clauses: list[str] = []
    args: list[Any] = []

    if not include_tombstoned:
        clauses.append("tombstone_at IS NULL")
    if source_name is not None:
        args.append(source_name)
        clauses.append(f"source_name = ${len(args)}")
    if event_type is not None:
        args.append(event_type)
        clauses.append(f"event_type = ${len(args)}")
    if since is not None:
        args.append(since)
        clauses.append(f"occurred_at >= ${len(args)}")
    if until is not None:
        args.append(until)
        clauses.append(f"occurred_at < ${len(args)}")

    where = (" WHERE " + " AND ".join(clauses)) if clauses else ""

    total = await pool.fetchval(f"SELECT count(*) FROM v_point_events_corrected{where}", *args) or 0

    args.append(limit)
    args.append(offset)
    rows = await pool.fetch(
        f"""
        SELECT * FROM v_point_events_corrected{where}
        ORDER BY occurred_at DESC
        LIMIT ${len(args) - 1} OFFSET ${len(args)}
        """,
        *args,
    )

    data = [_row_to_point_event(r) for r in rows]
    return PaginatedResponse[ChroniclerPointEvent](
        data=data,
        meta=PaginationMeta(total=total, offset=offset, limit=limit),
    )


# ── GET /api/chronicler/episodes ──────────────────────────────────────────


@router.get("/episodes", response_model=PaginatedResponse[ChroniclerEpisode])
async def list_episodes(
    source_name: str | None = Query(None),
    episode_type: str | None = Query(None),
    start_from: datetime | None = Query(None, description="start_at >= start_from"),
    start_to: datetime | None = Query(None, description="start_at < start_to"),
    overlaps_start: datetime | None = Query(
        None,
        description="Overlap window start (both overlaps_start and overlaps_end required)",
    ),
    overlaps_end: datetime | None = Query(
        None,
        description="Overlap window end (both overlaps_start and overlaps_end required)",
    ),
    participant_entity_id: UUID | None = Query(
        None,
        description="Filter episodes where the entity appears in any role via episode_entities",
    ),
    include_tombstoned: bool = Query(False),
    offset: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=500),
    *,
    db: Db,
) -> PaginatedResponse[ChroniclerEpisode]:
    if (overlaps_start is None) != (overlaps_end is None):
        raise HTTPException(
            status_code=400,
            detail="overlaps_start and overlaps_end must be provided together",
        )

    _tracer = trace.get_tracer("butlers.chronicler")
    with _tracer.start_as_current_span("chronicler.episodes.list") as span:
        # Emit a filter_kind dimension so request rate can be sliced by query
        # shape in Grafana.  Mirrors the chronicler.episodes.explain pattern.
        if participant_entity_id is not None:
            span.set_attribute("chronicler.episodes.filter_kind", "participant_join")
        else:
            span.set_attribute("chronicler.episodes.filter_kind", "none")

        pool = _pool(db)

        clauses: list[str] = []
        args: list[Any] = []

        if not include_tombstoned:
            clauses.append("tombstone_at IS NULL")
        if source_name is not None:
            args.append(source_name)
            clauses.append(f"source_name = ${len(args)}")
        if episode_type is not None:
            args.append(episode_type)
            clauses.append(f"episode_type = ${len(args)}")
        if start_from is not None:
            args.append(start_from)
            clauses.append(f"start_at >= ${len(args)}")
        if start_to is not None:
            args.append(start_to)
            clauses.append(f"start_at < ${len(args)}")
        if overlaps_start is not None and overlaps_end is not None:
            args.append(overlaps_end)
            clauses.append(f"start_at < ${len(args)}")
            args.append(overlaps_start)
            clauses.append(f"(end_at IS NULL OR end_at > ${len(args)})")
        if participant_entity_id is not None:
            args.append(participant_entity_id)
            clauses.append(f"${len(args)}::uuid = ANY(participant_entity_ids)")

        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""

        total = await pool.fetchval(f"SELECT count(*) FROM v_episodes_corrected{where}", *args) or 0

        args.append(limit)
        args.append(offset)
        rows = await pool.fetch(
            f"""
            SELECT * FROM v_episodes_corrected{where}
            ORDER BY start_at DESC
            LIMIT ${len(args) - 1} OFFSET ${len(args)}
            """,
            *args,
        )

        data = [_row_to_episode(r) for r in rows]
        return PaginatedResponse[ChroniclerEpisode](
            data=data,
            meta=PaginationMeta(total=total, offset=offset, limit=limit),
        )


# ── GET /api/chronicler/episodes/{id} ─────────────────────────────────────


@router.get("/episodes/{episode_id}", response_model=ChroniclerEpisode)
async def get_episode(
    episode_id: UUID,
    include_tombstoned: bool = Query(False),
    *,
    db: Db,
) -> ChroniclerEpisode:
    pool = _pool(db)
    clause = "" if include_tombstoned else "AND tombstone_at IS NULL"
    row = await pool.fetchrow(
        f"SELECT * FROM v_episodes_corrected WHERE id = $1 {clause}",
        episode_id,
    )
    if row is None:
        raise HTTPException(status_code=404, detail="Episode not found")
    return _row_to_episode(row)


# ── GET /api/chronicler/episodes/{id}/events ──────────────────────────────


@router.get(
    "/episodes/{episode_id}/events",
    response_model=list[ChroniclerPointEvent],
)
async def list_episode_events(
    episode_id: UUID,
    *,
    db: Db,
) -> list[ChroniclerPointEvent]:
    pool = _pool(db)
    # 404 if episode doesn't exist.
    exists = await pool.fetchval(
        "SELECT 1 FROM episodes WHERE id = $1",
        episode_id,
    )
    if not exists:
        raise HTTPException(status_code=404, detail="Episode not found")

    rows = await pool.fetch(
        """
        SELECT v.*
        FROM episode_event_links l
        JOIN v_point_events_corrected v ON v.id = l.event_id
        WHERE l.episode_id = $1
        ORDER BY v.occurred_at ASC
        """,
        episode_id,
    )
    return [_row_to_point_event(r) for r in rows]


# ── GET /api/chronicler/episodes/{id}/corrections ─────────────────────────


@router.get(
    "/episodes/{episode_id}/corrections",
    response_model=list[ChroniclerOverride],
)
async def list_episode_corrections(
    episode_id: UUID,
    *,
    db: Db,
) -> list[ChroniclerOverride]:
    pool = _pool(db)
    exists = await pool.fetchval(
        "SELECT 1 FROM episodes WHERE id = $1",
        episode_id,
    )
    if not exists:
        raise HTTPException(status_code=404, detail="Episode not found")

    rows = await pool.fetch(
        """
        SELECT * FROM overrides
        WHERE target_kind = 'episode' AND target_id = $1
        ORDER BY created_at DESC
        """,
        episode_id,
    )
    return [_row_to_override(r) for r in rows]


# ── POST /api/chronicler/episodes/{id}/corrections ────────────────────────


@router.post(
    "/episodes/{episode_id}/corrections",
    response_model=ChroniclerOverride,
    status_code=201,
)
async def submit_episode_correction(
    episode_id: UUID,
    request: Request,
    body: SubmitCorrectionRequest = Body(...),
    *,
    db: Db,
) -> ChroniclerOverride:
    """Record an owner correction for one episode.

    ``submitted_by`` is derived from the authenticated principal, so the stored
    attribution and the audit entry record who actually submitted the
    correction; a ``submitted_by`` in the request body is ignored.
    """
    pool = _pool(db)
    submitted_by = authenticated_principal()

    exists = await pool.fetchval(
        "SELECT 1 FROM episodes WHERE id = $1",
        episode_id,
    )
    if not exists:
        raise HTTPException(status_code=404, detail="Episode not found")

    if not any(
        (
            body.corrected_start_at is not None,
            body.corrected_end_at is not None,
            body.corrected_title is not None,
            body.corrected_privacy is not None,
            body.corrected_tombstone_at is not None,
            body.note is not None,
        )
    ):
        raise HTTPException(
            status_code=400,
            detail="At least one correction field or a note is required",
        )

    if body.corrected_privacy is not None and body.corrected_privacy not in (
        "normal",
        "sensitive",
        "restricted",
    ):
        raise HTTPException(
            status_code=400,
            detail="corrected_privacy must be one of 'normal', 'sensitive', 'restricted'",
        )

    row = await pool.fetchrow(
        """
        INSERT INTO overrides (
            target_kind, target_id, corrected_start_at, corrected_end_at,
            corrected_title, corrected_privacy, corrected_tombstone_at,
            note, submitted_by
        )
        VALUES ('episode', $1, $2, $3, $4, $5, $6, $7, $8)
        RETURNING *
        """,
        episode_id,
        body.corrected_start_at,
        body.corrected_end_at,
        body.corrected_title,
        body.corrected_privacy,
        body.corrected_tombstone_at,
        body.note,
        submitted_by,
    )

    # Explicit audit — middleware also fires; this carries the semantic operation label.
    await emit_dashboard_audit(
        db,
        butler="chronicler",
        operation="episode_correction_create",
        method="POST",
        path=f"/api/chronicler/episodes/{episode_id}/corrections",
        path_params={"episode_id": str(episode_id)},
        body={"corrected_privacy": body.corrected_privacy, "submitted_by": submitted_by},
        response_status=201,
        request=request,
    )

    return _row_to_override(row)


# ── POST /api/chronicler/episodes/{id}/explain ────────────────────────────

_EPISODE_EXPLAIN_RATE_LIMIT_HOURS = 24

# Token-budget guard: cap the bundle at ~4 000 chars (~1 000 tokens) so that
# the LLM prompt stays well within context limits even on small models.
_EPISODE_EXPLAIN_BUNDLE_CHAR_LIMIT = 4_000


def _build_episode_bundle(
    episode_row: Any,
    event_rows: list[Any],
    override_rows: list[Any],
    *,
    char_limit: int = _EPISODE_EXPLAIN_BUNDLE_CHAR_LIMIT,
) -> str:
    """Serialize an episode + linked events + corrections into a token-bounded prompt bundle.

    The bundle is a compact JSON object.  If the serialised form exceeds
    ``char_limit`` the events and corrections arrays are truncated (most-recent
    first for corrections, chronological for events) until it fits.  The
    episode detail is never truncated — only the supporting arrays.

    Returns the serialised string.
    """

    def _ep_dict(r: Any) -> dict:
        def _iso(v: Any) -> str | None:
            return v.isoformat() if v is not None else None

        return {
            "id": str(r["id"]),
            "source_name": r["source_name"],
            "episode_type": r["episode_type"],
            "canonical_start_at": _iso(r["canonical_start_at"]),
            "canonical_end_at": _iso(r["canonical_end_at"]),
            "canonical_title": r["canonical_title"],
            "canonical_privacy": r["canonical_privacy"],
            "precision": r["precision"],
            "corrected_at": _iso(r["corrected_at"]),
            "correction_note": r["correction_note"],
        }

    def _ev_dict(r: Any) -> dict:
        def _iso(v: Any) -> str | None:
            return v.isoformat() if v is not None else None

        return {
            "id": str(r["id"]),
            "event_type": r["event_type"],
            "canonical_occurred_at": _iso(r["canonical_occurred_at"]),
            "canonical_title": r["canonical_title"],
            "canonical_privacy": r["canonical_privacy"],
            "source_name": r["source_name"],
        }

    def _ov_dict(r: Any) -> dict:
        def _iso(v: Any) -> str | None:
            return v.isoformat() if v is not None else None

        return {
            "id": str(r["id"]),
            "corrected_start_at": _iso(r["corrected_start_at"]),
            "corrected_end_at": _iso(r["corrected_end_at"]),
            "corrected_title": r["corrected_title"],
            "corrected_privacy": r["corrected_privacy"],
            "note": r["note"],
            "submitted_by": r["submitted_by"],
            "created_at": _iso(r["created_at"]),
        }

    ep_dict = _ep_dict(episode_row)
    ev_dicts = [_ev_dict(r) for r in event_rows]
    ov_dicts = [_ov_dict(r) for r in override_rows]

    # Binary search on the number of events + corrections included.
    # Start with all rows; shrink from the end until it fits.
    max_events = len(ev_dicts)
    max_overrides = len(ov_dicts)

    while True:
        bundle = {
            "episode": ep_dict,
            "linked_events": ev_dicts[:max_events],
            "correction_history": ov_dicts[:max_overrides],
        }
        serialised = json.dumps(bundle, default=str)
        if len(serialised) <= char_limit:
            return serialised
        # Shrink: remove one override first (most-recent is already first), then events.
        if max_overrides > 0:
            max_overrides -= 1
        elif max_events > 0:
            max_events -= 1
        else:
            # Episode dict alone already exceeds the limit — return as-is.
            return serialised


@router.post(
    "/episodes/{episode_id}/explain",
    response_model=EpisodeExplainResponse,
    status_code=200,
)
async def explain_episode(
    episode_id: UUID,
    request: Request,
    *,
    db: Db,
    dispatch_fn: DayCloseDispatchCallable | None = Depends(_get_day_close_dispatch_fn),
) -> EpisodeExplainResponse:
    """Invoke a Tier-2 LLM drilldown for a specific episode (rate-limited: 1 per 24 h per episode).

    Assembles a token-bounded bundle from:
    - Episode detail (corrected view)
    - Linked point events
    - Correction history

    Returns 404 if the episode does not exist.
    Returns 403 if the episode is sensitive (privacy = 'sensitive' or 'restricted').
    Returns 429 with ``code=episode_explain_rate_limited`` and
    ``details.retry_after_seconds`` if called within the 24 h window.
    Returns 503 when no dispatch callable is wired.
    """
    _tracer = trace.get_tracer("butlers.chronicler")
    with _tracer.start_as_current_span("chronicler.episodes.explain") as span:
        span.set_attribute("chronicler.episodes.explain.episode_id", str(episode_id))
        return await _explain_episode_inner(episode_id, db, dispatch_fn, request=request, span=span)


async def _explain_episode_inner(
    episode_id: UUID,
    db: DatabaseManager,
    dispatch_fn: DayCloseDispatchCallable | None,
    *,
    request: Request | None = None,
    span: Any,
) -> EpisodeExplainResponse:
    pool = _pool(db)
    cache_key = f"episode_explain:{episode_id}"
    now = datetime.now(UTC)

    # ── Fetch episode (404 if not found) ──────────────────────────────────────
    episode_row = await pool.fetchrow(
        "SELECT * FROM v_episodes_corrected WHERE id = $1 AND tombstone_at IS NULL",
        episode_id,
    )
    if episode_row is None:
        span.set_attribute("chronicler.episodes.explain.outcome", "not_found")
        raise HTTPException(status_code=404, detail="Episode not found")

    # ── Sensitive episode guard ───────────────────────────────────────────────
    # Sensitive and restricted episodes are excluded from LLM drilldown to
    # prevent private data from being processed by an external model.
    canonical_privacy: str = episode_row["canonical_privacy"]
    if canonical_privacy in ("sensitive", "restricted"):
        span.set_attribute("chronicler.episodes.explain.outcome", "excluded")
        return JSONResponse(
            status_code=403,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="episode_explain_excluded",
                    message=(
                        f"Episode {episode_id} has privacy={canonical_privacy!r} "
                        "and is excluded from LLM drilldown."
                    ),
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    # ── Rate-limit check ──────────────────────────────────────────────────────
    existing_row = await pool.fetchrow(
        """
        SELECT cache_built_at
        FROM tier2_cache
        WHERE cache_key = $1
          AND superseded_at IS NULL
        """,
        cache_key,
    )

    if existing_row is not None:
        cache_built_at: datetime = existing_row["cache_built_at"]
        age = now - cache_built_at
        if age < timedelta(hours=_EPISODE_EXPLAIN_RATE_LIMIT_HOURS):
            remaining = timedelta(hours=_EPISODE_EXPLAIN_RATE_LIMIT_HOURS) - age
            retry_after = int(remaining.total_seconds())
            span.set_attribute("chronicler.episodes.explain.outcome", "rate_limited")
            span.set_attribute("chronicler.episodes.explain.retry_after_seconds", retry_after)
            return JSONResponse(
                status_code=429,
                content=ErrorResponse(
                    error=ErrorDetail(
                        code="episode_explain_rate_limited",
                        message=(
                            f"An explain for episode {episode_id} was performed recently. "
                            f"Retry after {retry_after} seconds."
                        ),
                        butler="chronicler",
                        details={"retry_after_seconds": retry_after},
                    )
                ).model_dump(exclude_none=True),
            )

    # ── Dispatch guard ────────────────────────────────────────────────────────
    if dispatch_fn is None:
        span.set_attribute("chronicler.episodes.explain.outcome", "dispatch_unavailable")
        return JSONResponse(
            status_code=503,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="dispatch_unavailable",
                    message="Episode explain dispatch is not available in this deployment mode.",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    # ── Bundle construction (token-bounded) ───────────────────────────────────
    event_rows = await pool.fetch(
        """
        SELECT v.*
        FROM episode_event_links l
        JOIN v_point_events_corrected v ON v.id = l.event_id
        WHERE l.episode_id = $1
        ORDER BY v.occurred_at ASC
        """,
        episode_id,
    )

    override_rows = await pool.fetch(
        """
        SELECT * FROM overrides
        WHERE target_kind = 'episode' AND target_id = $1
        ORDER BY created_at DESC
        """,
        episode_id,
    )

    bundle = _build_episode_bundle(episode_row, event_rows, override_rows)
    span.set_attribute("chronicler.episodes.explain.bundle_chars", len(bundle))

    prompt = (
        f"You are the Chronicler butler. The user has requested a Tier-2 explanation "
        f"for a specific episode. Below is a JSON bundle containing the episode detail, "
        f"linked point events, and correction history. Provide a concise, factual "
        f"explanation of what this episode represents, citing the source adapter and "
        f"any corrections applied. Do not speculate. Respect privacy: if a field is "
        f"absent or masked, do not invent content.\n\n"
        f"Episode bundle:\n{bundle}"
    )

    # ── Dispatch ──────────────────────────────────────────────────────────────
    result = await dispatch_fn(
        prompt=prompt,
        trigger_source=f"api:episode_explain:{episode_id}",
    )

    # ── Write result to tier2_cache ───────────────────────────────────────────
    # Use the episode's canonical_start_at / canonical_end_at as the window.
    # This allows the same staleness-detection machinery to work on this cache row.
    ep_start = episode_row["canonical_start_at"]
    ep_end = episode_row["canonical_end_at"] or now

    # Extract output from the result.
    if hasattr(result, "success") and result.success and getattr(result, "output", None):
        prose = result.output.strip()
    elif isinstance(result, dict) and result.get("success") and result.get("output"):
        prose = result["output"].strip()
    else:
        prose = ""

    if prose:
        try:
            await upsert_tier2_cache(
                pool,
                cache_key=cache_key,
                start_at=ep_start,
                end_at=ep_end,
                prose=prose,
                provenance_refs=[episode_row["source_ref"]],
            )
        except Exception:
            logger.exception("explain_episode: failed to write tier2_cache[%s]", cache_key)

    # ── Return response ───────────────────────────────────────────────────────
    new_row = await pool.fetchrow(
        "SELECT cache_built_at FROM tier2_cache WHERE cache_key = $1 AND superseded_at IS NULL",
        cache_key,
    )
    if new_row is None:
        span.set_attribute("chronicler.episodes.explain.outcome", "cache_write_failed")
        return JSONResponse(
            status_code=502,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="cache_write_failed",
                    message="Episode explain dispatch completed but no cache row was written.",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    span.set_attribute("chronicler.episodes.explain.outcome", "dispatched")

    # Explicit audit — middleware also fires; this carries the semantic operation label.
    await emit_dashboard_audit(
        db,
        butler="chronicler",
        operation="episode_explain_invoke",
        method="POST",
        path=f"/api/chronicler/episodes/{episode_id}/explain",
        path_params={"episode_id": str(episode_id)},
        response_status=200,
        request=request,
    )

    return EpisodeExplainResponse(
        episode_id=str(episode_id),
        cache_key=cache_key,
        cache_built_at=new_row["cache_built_at"],
    )


# ── GET /api/chronicler/source-state ─────────────────────────────────────


def _rows_to_source_state(
    adapter_rows: list[Any],
    checkpoint_rows: list[Any],
) -> list[SourceStateRow]:
    """Build SourceStateRow list from adapter state and checkpoint rows.

    Joins projection_checkpoints rows to their parent source_adapter_state row.
    ``last_run_at`` and ``last_error`` are the latest values across all subsources.
    ``subsource_checkpoints`` contains the per-subsource detail array.
    """
    # Group checkpoint rows by source_name.
    checkpoints_by_source: dict[str, list[Any]] = {}
    for cp in checkpoint_rows:
        checkpoints_by_source.setdefault(cp["source_name"], []).append(cp)

    results: list[SourceStateRow] = []
    for row in adapter_rows:
        sn = row["source_name"]
        cps = checkpoints_by_source.get(sn, [])

        # Aggregate: latest last_run_at and latest last_error across subsources.
        last_run_at: datetime | None = None
        last_error: str | None = None
        for cp in cps:
            cp_run = cp["last_run_at"]
            if cp_run is not None and (last_run_at is None or cp_run > last_run_at):
                last_run_at = cp_run
                last_error = cp["last_error"]

        subsource_checkpoints = [
            SubsourceCheckpoint(
                subsource=cp["subsource"],
                last_run_at=cp["last_run_at"],
                last_error=cp["last_error"],
            )
            for cp in cps
        ] or None

        results.append(
            SourceStateRow(
                source_name=sn,
                chronicler_compatibility=row["chronicler_compatibility"],
                read_surface=row["read_surface"],
                boundary_semantics=row["boundary_semantics"],
                optional_schema=row["optional_schema"],
                active=row["active"],
                inactive_reason=row["inactive_reason"],
                last_run_at=last_run_at,
                last_error=last_error,
                subsource_checkpoints=subsource_checkpoints,
            )
        )

    return results


@router.get("/source-state", response_model=ApiResponse[list[SourceStateRow]])
async def list_source_state(
    *,
    db: Db,
) -> ApiResponse[list[SourceStateRow]]:
    """Return one record per registered source adapter joined with its projection checkpoints.

    Records are returned sorted by ``source_name ASC``.
    An empty ``source_adapter_state`` table returns ``{"data": [], "meta": {}}``.
    """
    _tracer = trace.get_tracer("butlers.chronicler")
    with _tracer.start_as_current_span("chronicler.source_state") as span:
        pool = _pool(db)

        t0 = time.perf_counter()
        adapter_rows = await pool.fetch(
            "SELECT source_name, chronicler_compatibility, read_surface, boundary_semantics,"
            " optional_schema, active, inactive_reason"
            " FROM source_adapter_state"
            " ORDER BY source_name ASC"
        )

        checkpoint_rows = await pool.fetch(
            "SELECT source_name, subsource, last_run_at, last_error"
            " FROM projection_checkpoints"
            " ORDER BY source_name ASC, subsource ASC"
        )
        query_latency_ms = (time.perf_counter() - t0) * 1000

        data = _rows_to_source_state(adapter_rows, checkpoint_rows)

        span.set_attribute("chronicler.source_state.row_count", len(data))
        span.set_attribute("chronicler.source_state.query_latency_ms", query_latency_ms)

        return ApiResponse[list[SourceStateRow]](data=data)


# ── GET /api/chronicler/ops/sessions ──────────────────────────────────────
#
# Engineering escape hatch: query operational sessions that CoreSessionsAdapter
# intentionally excludes from the user-facing episodes table.  Reads directly
# from each butler's raw sessions table via fan_out, filtered to ONLY the
# excluded trigger_source values (tick, qa, healing, schedule:*).
#
# This endpoint is intended for engineers diagnosing scheduler cadence,
# switchboard tick rate, and QA canary health — NOT for user-facing UIs.
# See roster/chronicler/AGENTS.md "Ops sessions escape hatch" for usage.


@router.get("/ops/sessions", response_model=PaginatedResponse[OpsSessionRow])
async def list_ops_sessions(
    trigger_source: str | None = Query(
        None,
        description=(
            "Filter to a specific operational trigger_source "
            "(e.g. 'tick', 'qa', 'healing', 'schedule:chronicler_day_close'). "
            "Returns all operational trigger sources when omitted."
        ),
    ),
    since: datetime | None = Query(None, description="started_at >= since"),
    until: datetime | None = Query(None, description="started_at < until"),
    limit: int = Query(50, ge=1, le=500),
    *,
    db: Db,
) -> PaginatedResponse[OpsSessionRow]:
    """Return operational sessions excluded from the user-facing Chronicles.

    Operational sessions (trigger_source in tick, qa, healing, schedule:*) are
    filtered out by ``CoreSessionsAdapter`` before projection so they never
    appear in ``/api/chronicler/episodes``.  This endpoint reads the raw
    sessions tables directly so engineers can audit scheduler cadence,
    switchboard tick rate, and QA canary health without that data polluting
    user-facing Chronicles views.

    Results are sorted by ``started_at DESC`` across all butler schemas.
    The ``butler`` field identifies the schema each row came from.

    **This endpoint is for engineering/ops use only.  It is not intended for
    user-facing dashboards.**
    """
    excluded_exact = list(EXCLUDED_TRIGGER_SOURCES)
    excluded_prefix_pattern = EXCLUDED_TRIGGER_SOURCE_PREFIX + "%"

    # Build the SQL filter: select rows that match the operational exclusion
    # set (i.e. the inverse of what CoreSessionsAdapter admits).
    # Optional further filter on a specific trigger_source value.
    clauses: list[str] = ["(trigger_source = ANY($1::text[]) OR trigger_source LIKE $2)"]
    args: list[Any] = [excluded_exact, excluded_prefix_pattern]

    if trigger_source is not None:
        args.append(trigger_source)
        clauses.append(f"trigger_source = ${len(args)}")
    if since is not None:
        args.append(since)
        clauses.append(f"started_at >= ${len(args)}")
    if until is not None:
        args.append(until)
        clauses.append(f"started_at < ${len(args)}")

    where = "WHERE " + " AND ".join(clauses)
    args.append(limit)

    sql = f"""
        SELECT id, trigger_source, started_at, completed_at, duration_ms, success, model
        FROM sessions
        {where}
        ORDER BY started_at DESC
        LIMIT ${len(args)}
    """

    fan_results, _failed = await db.fan_out_with_status(sql, args=tuple(args))

    rows: list[OpsSessionRow] = []
    for butler_name, butler_rows in sorted(fan_results.items()):
        for row in butler_rows:
            rows.append(
                OpsSessionRow(
                    butler=butler_name,
                    session_id=str(row["id"]),
                    trigger_source=str(row["trigger_source"] or ""),
                    started_at=row["started_at"],
                    completed_at=row["completed_at"],
                    duration_ms=row["duration_ms"],
                    success=row["success"],
                    model=row["model"],
                )
            )

    # Sort merged results by started_at DESC and apply limit.
    rows.sort(key=lambda r: r.started_at, reverse=True)
    rows = rows[:limit]

    return PaginatedResponse[OpsSessionRow](
        data=rows,
        meta=PaginationMeta(total=len(rows), offset=0, limit=limit),
    )


# ── GET /api/chronicler/projection-health ─────────────────────────────────


@router.get("/projection-health", response_model=ApiResponse[list[ProjectionHealthRow]])
async def projection_health(
    *,
    db: Db,
) -> ApiResponse[list[ProjectionHealthRow]]:
    """Return per-checkpoint projection health from ``projection_checkpoints``.

    Exposes ``source_name``, ``subsource``, ``last_error``, ``last_run_at``,
    ``rows_projected``, and ``watermark`` for every row in the table.  Sorted
    by ``source_name ASC, subsource ASC``.

    Useful for surfacing ingestion errors without requiring direct DB access.
    An empty ``projection_checkpoints`` table returns ``{"data": [], "meta": {}}``.
    """
    pool = _pool(db)

    rows = await pool.fetch(
        "SELECT source_name, subsource, last_error, last_run_at,"
        " rows_projected, watermark"
        " FROM projection_checkpoints"
        " ORDER BY source_name ASC, subsource ASC"
    )

    data = [
        ProjectionHealthRow(
            source_name=row["source_name"],
            subsource=row["subsource"],
            last_error=row["last_error"],
            last_run_at=row["last_run_at"],
            rows_projected=row["rows_projected"],
            watermark=row["watermark"],
        )
        for row in rows
    ]

    return ApiResponse[list[ProjectionHealthRow]](data=data)


# ── Precision ordering ─────────────────────────────────────────────────────

# Ordered least-precise → most-precise.  Lower index = less precise.
_PRECISION_ORDER = ["unknown", "day", "hour", "minute", "exact"]


def _least_precise(values: list[str]) -> str:
    """Return the least-precise precision value from a list.

    If a value is not in the known ordering it is treated as less precise
    than ``unknown`` so that unrecognized tokens never silently inflate
    confidence.
    """
    if not values:
        return "unknown"
    return min(values, key=lambda p: _PRECISION_ORDER.index(p) if p in _PRECISION_ORDER else -1)


# ── GET /api/chronicler/aggregate/by-category ────────────────────────────


@router.get("/aggregate/by-category", response_model=ApiResponse[CategoryBuckets])
async def aggregate_by_category(
    start_at: datetime | None = Query(None, description="Inclusive window start (UTC or tz-aware)"),
    end_at: datetime | None = Query(None, description="Exclusive window end (UTC or tz-aware)"),
    tz: str = Query("UTC", description="IANA timezone for display purposes"),
    privacy_tier: str | None = Query(
        None,
        description=(
            "Comma-separated privacy values to include (e.g. 'normal,sensitive'). "
            "Default: exclude restricted (include normal and sensitive)."
        ),
    ),
    include_tombstoned: bool = Query(False),
    *,
    db: Db,
) -> ApiResponse[CategoryBuckets]:
    """Return total episode duration bucketed by category across the requested window.

    Buckets are sorted by ``total_seconds DESC``, then ``category ASC`` for
    deterministic ordering.  Restricted episodes are excluded by default.
    Tombstoned episodes are excluded unless ``include_tombstoned=true``;
    opt-in preserves marked source provenance for audit without allocating the
    tombstoned interval to a live category.
    Open episodes (``end_at IS NULL``) are clipped to ``query_end`` so that
    in-progress activities are counted up to the window boundary.
    """
    # ── Parameter validation ───────────────────────────────────────────
    if start_at is None or end_at is None:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="missing_parameter",
                    message="start_at and end_at are required",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    if end_at <= start_at:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="invalid_time_range",
                    message="end_at must be strictly after start_at",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    try:
        tz_info = zoneinfo.ZoneInfo(tz)
    except (zoneinfo.ZoneInfoNotFoundError, KeyError):
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="invalid_timezone",
                    message=f"Unrecognized IANA timezone: {tz!r}",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    # ── Resolve privacy filter ─────────────────────────────────────────
    # Default: include 'normal' and 'sensitive'; exclude 'restricted'.
    if privacy_tier is not None:
        allowed_tiers = {t.strip() for t in privacy_tier.split(",") if t.strip()}
    else:
        allowed_tiers = {"normal", "sensitive"}

    _tracer = trace.get_tracer("butlers.chronicler")
    with _tracer.start_as_current_span("chronicler.aggregate.by_category") as span:
        pool = _pool(db)

        # ── Fetch raw episode rows from the corrected view ─────────────────
        # Read from v_episodes_corrected using start_at/end_at/privacy so that
        # user-submitted overrides are honoured.
        clauses: list[str] = [
            "start_at < $2",
            "(end_at IS NULL OR end_at > $1)",
        ]
        args: list[Any] = [start_at, end_at]

        if not include_tombstoned:
            clauses.append("tombstone_at IS NULL")

        # Build privacy IN clause from allowed_tiers.
        tier_placeholders = ", ".join(f"${len(args) + i + 1}" for i in range(len(allowed_tiers)))
        for tier in sorted(allowed_tiers):
            args.append(tier)
        clauses.append(f"privacy IN ({tier_placeholders})")

        where = "WHERE " + " AND ".join(clauses)

        t0 = time.perf_counter()
        rows = await pool.fetch(
            f"""
            SELECT
                source_name,
                episode_type,
                start_at,
                end_at,
                precision,
                privacy,
                retention_days,
                tombstone_at,
                layer,
                confidence,
                payload->>'trigger_source' AS trigger_source
            FROM v_episodes_corrected
            {where}
            """,
            *args,
        )
        query_latency_ms = (time.perf_counter() - t0) * 1000
        span.set_attribute("chronicler.aggregate.query_latency_ms", query_latency_ms)

        # ── Aggregate in Python ────────────────────────────────────────────
        # group by (lane, source_name) to build per-source breakdowns,
        # then roll up to per-lane buckets.
        #
        # Only the 'activity' layer is counted (tasks.md §4): intent (calendar)
        # and evidence (raw signals) episodes are dropped by lane_for_activity,
        # so an uncorroborated calendar block contributes 0 s to every lane.
        #
        # Durations are collected as half-open [overlap_start, overlap_end)
        # intervals and unioned (not summed) at rollup, so two concurrent
        # episodes in the same bucket count once and a lane total can never
        # exceed the window length.
        cat_src: dict[tuple[str, str], dict[str, Any]] = defaultdict(
            lambda: {
                "intervals": [],
                "low_intervals": [],
                "low_episode_count": 0,
                "episode_count": 0,
                "tombstoned": False,
                "precision_values": [],
                "retention_days_values": [],
            }
        )

        # Every non-tombstoned activity-layer episode's window-clipped span,
        # regardless of whether its source resolves to a lane. Feeds
        # untracked_seconds_for_window below (bu-whhll.13): "was anything
        # recorded" is a broader question than "did it resolve to a lane".
        activity_intervals: list[tuple[datetime, datetime]] = []

        for row in rows:
            ep_start: datetime = row["start_at"]
            ep_end: datetime | None = row["end_at"]
            source_name: str = row["source_name"]
            episode_type: str = row["episode_type"]
            precision: str = row["precision"]
            retention_days: int | None = row["retention_days"]
            is_tombstoned: bool = row["tombstone_at"] is not None
            row_trigger_source: str | None = row["trigger_source"]
            ep_layer: str = row["layer"]
            ep_confidence: str = row["confidence"]

            # Clip open episodes to query_end.
            ep_end_resolved = ep_end if ep_end is not None else end_at

            # Duration = LEAST(end_at, query_end) - GREATEST(start_at, query_start), clamped at 0.
            overlap_start = max(ep_start, start_at)
            overlap_end = min(ep_end_resolved, end_at)
            if overlap_end <= overlap_start:
                continue

            if ep_layer == "activity" and not is_tombstoned:
                activity_intervals.append((overlap_start, overlap_end))

            # Only activity-layer episodes count toward a lane bucket; intent
            # (calendar) and evidence rows resolve to None and are dropped
            # (the "calendar = 5h" fix).
            ep_lane = lane_for_activity(
                ep_layer, source_name, episode_type, trigger_source=row_trigger_source
            )
            if ep_lane is None:
                if ep_layer == "activity":
                    logger.warning(
                        "chronicler.aggregate.unmapped_source=%s episode_type=%s",
                        source_name,
                        episode_type,
                    )
                    span.set_attribute("chronicler.aggregate.unmapped_source", source_name)
                continue

            bucket_key = (ep_lane, source_name)
            bucket = cat_src[bucket_key]
            # include_tombstoned retains a marked provenance entry for audit,
            # but a tombstone cannot allocate time to a live category.  The
            # untracked slice intentionally treats it as uncovered, so adding
            # its interval here would count the same period twice.
            if is_tombstoned:
                bucket["tombstoned"] = True
                continue
            bucket["intervals"].append((overlap_start, overlap_end))
            bucket["episode_count"] += 1
            bucket["precision_values"].append(precision)
            bucket["retention_days_values"].append(retention_days)
            # Track the low-confidence share separately so the dashboard can flag
            # how much of a lane still needs owner confirmation. Collected as its
            # own interval set and unioned, so it never exceeds the lane total.
            if ep_confidence == "low":
                bucket["low_intervals"].append((overlap_start, overlap_end))
                bucket["low_episode_count"] += 1

        # Roll up per-(category, source) to per-category buckets. Intervals are
        # unioned at both levels: per-source for the breakdown, and across all
        # sources for the category total.
        cat_buckets: dict[str, dict[str, Any]] = defaultdict(
            lambda: {
                "intervals": [],
                "low_intervals": [],
                "low_episode_count": 0,
                "episode_count": 0,
                "source_breakdown": [],
                "precision_values": [],
                "retention_days_values": [],
            }
        )

        for (ep_lane, source_name), src_data in cat_src.items():
            bucket = cat_buckets[ep_lane]
            bucket["intervals"].extend(src_data["intervals"])
            bucket["low_intervals"].extend(src_data["low_intervals"])
            bucket["low_episode_count"] += src_data["low_episode_count"]
            bucket["episode_count"] += src_data["episode_count"]
            bucket["precision_values"].extend(src_data["precision_values"])
            bucket["retention_days_values"].extend(src_data["retention_days_values"])
            bucket["source_breakdown"].append(
                SourceBreakdownEntry(
                    source_name=source_name,
                    total_seconds=union_seconds(src_data["intervals"]),
                    episode_count=src_data["episode_count"],
                    tombstoned=src_data["tombstoned"],
                )
            )

        # Build CategoryBucket list sorted by total_seconds DESC, category ASC.
        result_buckets: list[CategoryBucket] = []
        for ep_lane, data in cat_buckets.items():
            non_null_retentions = [r for r in data["retention_days_values"] if r is not None]
            result_buckets.append(
                CategoryBucket(
                    category=ep_lane,
                    total_seconds=union_seconds(data["intervals"]),
                    episode_count=data["episode_count"],
                    low_confidence_seconds=union_seconds(data["low_intervals"]),
                    low_confidence_episode_count=data["low_episode_count"],
                    source_breakdown=data["source_breakdown"],
                    precision=_least_precise(data["precision_values"]),
                    retention_floor_days=min(non_null_retentions) if non_null_retentions else None,
                )
            )

        result_buckets.sort(key=lambda b: (-b.total_seconds, b.category))

        span.set_attribute("chronicler.aggregate.bucket_count", len(result_buckets))

        # Untracked-slice math (bu-whhll.13): waking-window seconds not covered
        # by any activity-layer episode, so the pie can render an honest
        # 'untracked' slice instead of renormalising over tracked evidence only.
        untracked_seconds = untracked_seconds_for_window(
            activity_intervals,
            start_at,
            end_at,
            tz_info,
            waking_hour_start=WAKING_HOUR_START,
            waking_hour_end=WAKING_HOUR_END,
        )
        span.set_attribute("chronicler.aggregate.untracked_seconds", untracked_seconds)

        return ApiResponse[CategoryBuckets](
            data=CategoryBuckets(
                start_at=start_at,
                end_at=end_at,
                tz=tz,
                buckets=result_buckets,
                untracked_seconds=untracked_seconds,
            )
        )


# ── GET /api/chronicler/aggregate/by-day ─────────────────────────────────


@router.get("/aggregate/by-day", response_model=list[AggregateByDayRow])
async def aggregate_by_day(
    start_at: datetime | None = Query(None, description="Inclusive window start (UTC or tz-aware)"),
    end_at: datetime | None = Query(None, description="Exclusive window end (UTC or tz-aware)"),
    tz: str = Query("UTC", description="IANA timezone for day-boundary computation"),
    category: str | None = Query(None, description="Optional category filter"),
    privacy_tier: str | None = Query(
        None,
        description=(
            "Comma-separated privacy values to include (e.g. 'normal,sensitive'). "
            "Default: exclude restricted (include normal and sensitive)."
        ),
    ),
    include_tombstoned: bool = Query(False),
    *,
    db: Db,
) -> list[AggregateByDayRow]:
    """Return time-bucketed episode durations grouped by (day, category).

    Day boundaries are resolved in the requested IANA timezone so that
    DST-extended (25 h) and DST-shortened (23 h) days are treated as
    single buckets with actual-duration semantics.  Each row includes
    ``day_start`` / ``day_end`` timestamps in the requested timezone so
    callers can verify bucket boundaries without re-deriving DST rules.

    Restricted episodes are excluded by default.  Sensitive episodes
    contribute to duration totals but their identifying fields are not
    surfaced.  Tombstoned episodes are excluded unless
    ``include_tombstoned=true`` is supplied.
    """
    # ── Parameter validation ───────────────────────────────────────────
    if start_at is None or end_at is None:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="missing_parameter",
                    message="start_at and end_at are required",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    if end_at <= start_at:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="invalid_time_range",
                    message="end_at must be strictly after start_at",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    try:
        tzinfo = zoneinfo.ZoneInfo(tz)
    except (zoneinfo.ZoneInfoNotFoundError, KeyError):
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="invalid_timezone",
                    message=f"Unrecognized IANA timezone: {tz!r}",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    _tracer = trace.get_tracer("butlers.chronicler")
    with _tracer.start_as_current_span("chronicler.aggregate.by_day") as span:
        pool = _pool(db)

        # ── Fetch raw episode rows from the corrected view ─────────────────
        # Only select relations from the chronicler schema (v_episodes_corrected).
        # No LLM. No cross-schema references.
        # Use the corrected start_at/end_at columns so user-submitted overrides
        # are honoured in window filtering and duration arithmetic.
        clauses: list[str] = [
            "start_at < $2",
            "(end_at IS NULL OR end_at > $1)",
        ]
        args: list[Any] = [start_at, end_at]

        if not include_tombstoned:
            clauses.append("tombstone_at IS NULL")

        # Resolve privacy filter — default: include 'normal' and 'sensitive'; exclude 'restricted'.
        if privacy_tier is not None:
            allowed_tiers = {t.strip() for t in privacy_tier.split(",") if t.strip()}
        else:
            allowed_tiers = {"normal", "sensitive"}

        # Build privacy IN clause from allowed_tiers.
        tier_placeholders = ", ".join(f"${len(args) + i + 1}" for i in range(len(allowed_tiers)))
        for tier in sorted(allowed_tiers):
            args.append(tier)
        clauses.append(f"privacy IN ({tier_placeholders})")

        where = "WHERE " + " AND ".join(clauses)

        t0 = time.perf_counter()
        rows = await pool.fetch(
            f"""
            SELECT
                source_name,
                episode_type,
                start_at,
                end_at,
                precision,
                privacy,
                retention_days,
                tombstone_at,
                layer,
                payload->>'trigger_source' AS trigger_source
            FROM v_episodes_corrected
            {where}
            """,
            *args,
        )
        query_latency_ms = (time.perf_counter() - t0) * 1000
        span.set_attribute("chronicler.aggregate.query_latency_ms", query_latency_ms)

        # ── Enumerate calendar days in the requested timezone ──────────────
        # Compute the first and last local calendar day that overlaps the window.
        local_start = start_at.astimezone(tzinfo)
        local_end = end_at.astimezone(tzinfo)

        first_day = local_start.date()
        last_day = (local_end - timedelta(microseconds=1)).astimezone(tzinfo).date()

        # Build a mapping: day_str -> (day_start_utc, day_end_utc)
        day_bounds: dict[str, tuple[datetime, datetime]] = {}
        current_day = first_day
        while current_day <= last_day:
            ds = datetime(
                current_day.year, current_day.month, current_day.day, 0, 0, 0, tzinfo=tzinfo
            )
            next_day = current_day + timedelta(days=1)
            de = datetime(next_day.year, next_day.month, next_day.day, 0, 0, 0, tzinfo=tzinfo)
            day_bounds[current_day.isoformat()] = (ds, de)
            current_day = next_day

        if not day_bounds:
            return []

        # ── Aggregate in Python ────────────────────────────────────────────
        # Group by (day_str, category, source_name) and sum overlap seconds.
        # This avoids pushing category_for() logic into SQL and keeps it
        # in the Python layer where the category taxonomy lives.
        #
        # Complexity: O(N×k) where k = average episode span in days (typically << D).
        # For each episode we compute which days it overlaps via date arithmetic and
        # iterate only those days — avoiding the naive O(N×D) scan over all buckets.

        # day_cat_src[(day, category, source_name)] = {
        #   "intervals": list[tuple[datetime, datetime]],
        #   "episode_count": int,
        #   "tombstoned": bool,
        #   "precision_values": list[str],
        #   "retention_days_values": list[int | None],
        # }
        # Intervals are unioned (not summed) at rollup so concurrent episodes in
        # a bucket count once and a category total cannot exceed the day length.
        day_cat_src: dict[tuple[str, str, str], dict[str, Any]] = defaultdict(
            lambda: {
                "intervals": [],
                "episode_count": 0,
                "tombstoned": False,
                "precision_values": [],
                "retention_days_values": [],
            }
        )

        for row in rows:
            ep_start: datetime = row["start_at"]
            ep_end: datetime | None = row["end_at"]
            source_name: str = row["source_name"]
            episode_type: str = row["episode_type"]
            precision: str = row["precision"]
            retention_days: int | None = row["retention_days"]
            is_tombstoned: bool = row["tombstone_at"] is not None
            row_trigger_source: str | None = row["trigger_source"]
            ep_layer: str = row["layer"]

            # Only activity-layer episodes count; intent (calendar) and evidence
            # rows resolve to None and are dropped (the "calendar = 5h" fix).
            ep_lane = lane_for_activity(
                ep_layer, source_name, episode_type, trigger_source=row_trigger_source
            )
            if ep_lane is None:
                if ep_layer == "activity":
                    logger.warning(
                        "chronicler.aggregate.unmapped_source=%s episode_type=%s",
                        source_name,
                        episode_type,
                    )
                    span.set_attribute("chronicler.aggregate.unmapped_source", source_name)
                continue

            # Optional caller filter is by lane (the dashboard renders lanes).
            if category is not None and ep_lane != category:
                continue

            if is_tombstoned:
                logger.warning(
                    "chronicler.aggregate.tombstoned_episode source=%s episode_type=%s",
                    source_name,
                    episode_type,
                )

            # If end_at is NULL treat as open-ended — only count the portion
            # that falls within each day window.
            ep_end_resolved = ep_end if ep_end is not None else end_at

            # Compute the local-date range this episode overlaps, clipped to the
            # query window.  ep_end_resolved is exclusive (like day_end), so we
            # subtract 1 µs before converting to a local date to avoid counting a
            # day that the episode only *touches* at its very start boundary.
            ep_first_day = max(ep_start, start_at).astimezone(tzinfo).date()
            ep_last_day = (
                min(
                    ep_end_resolved - timedelta(microseconds=1),
                    end_at - timedelta(microseconds=1),
                )
                .astimezone(tzinfo)
                .date()
            )

            # Clamp to the query window's day range (defensive — SQL WHERE should
            # already guarantee overlap, but rounding/DST can produce edge cases).
            ep_first_day = max(ep_first_day, first_day)
            ep_last_day = min(ep_last_day, last_day)

            ep_day = ep_first_day
            while ep_day <= ep_last_day:
                day_str = ep_day.isoformat()
                ds, de = day_bounds[day_str]

                # Overlap = max(0, min(ep_end, de) - max(ep_start, ds))
                overlap_start = max(ep_start, ds)
                overlap_end = min(ep_end_resolved, de)
                if overlap_end > overlap_start:
                    bucket_key = (day_str, ep_lane, source_name)
                    bucket = day_cat_src[bucket_key]
                    bucket["intervals"].append((overlap_start, overlap_end))
                    bucket["episode_count"] += 1
                    bucket["tombstoned"] = bucket["tombstoned"] or is_tombstoned
                    bucket["precision_values"].append(precision)
                    bucket["retention_days_values"].append(retention_days)

                ep_day += timedelta(days=1)

        # ── Build final response rows ──────────────────────────────────────
        # First group day_cat_src by (day, category) to produce per-bucket source breakdowns.
        day_cat: dict[tuple[str, str], dict[str, Any]] = defaultdict(
            lambda: {
                "intervals": [],
                "episode_count": 0,
                "source_breakdown": [],
                "precision_values": [],
                "retention_days_values": [],
            }
        )

        for (day_str, ep_lane, source_name), src_data in day_cat_src.items():
            bucket = day_cat[(day_str, ep_lane)]
            bucket["intervals"].extend(src_data["intervals"])
            bucket["episode_count"] += src_data["episode_count"]
            bucket["precision_values"].extend(src_data["precision_values"])
            bucket["retention_days_values"].extend(src_data["retention_days_values"])
            bucket["source_breakdown"].append(
                SourceBreakdownEntry(
                    source_name=source_name,
                    total_seconds=union_seconds(src_data["intervals"]),
                    episode_count=src_data["episode_count"],
                    tombstoned=src_data["tombstoned"],
                )
            )

        result: list[AggregateByDayRow] = []
        for (day_str, ep_lane), data in sorted(day_cat.items()):
            ds, de = day_bounds[day_str]
            non_null_retentions = [r for r in data["retention_days_values"] if r is not None]
            result.append(
                AggregateByDayRow(
                    day=day_str,
                    category=ep_lane,
                    total_seconds=union_seconds(data["intervals"]),
                    episode_count=data["episode_count"],
                    day_start=ds,
                    day_end=de,
                    source_breakdown=data["source_breakdown"],
                    precision=_least_precise(data["precision_values"]),
                    retention_floor_days=min(non_null_retentions) if non_null_retentions else None,
                )
            )

        # Sort by (day ASC, category ASC) — already guaranteed by sorted() above.
        span.set_attribute("chronicler.aggregate.bucket_count", len(result))
        return result


# ── GET /api/chronicler/rollups ───────────────────────────────────────────
#
# bu-333dq, telemetry-distillation bead 5 (design doc §6.5). Reads the
# already-materialized chronicler.daily_rollups / daily_rollup_flags tables
# (beads 3/4) — no episode scanning here, that is the batch job's job.

# Generous multi-quarter cap on the requested [start_date, end_date] span.
# This is a single-butler own-schema read (two queries total regardless of
# span, see list_daily_rollups_range/list_daily_rollup_flags_range below),
# not a fan-out across pools — the cap exists to bound response size for the
# dashboard trend widget, not to bound round trips.
_ROLLUPS_MAX_RANGE_DAYS = 92


@router.get("/rollups", response_model=ApiResponse[RollupsResponse])
async def get_rollups(
    rollup_date: date | None = Query(
        None,
        alias="date",
        description=(
            "Single local calendar day to fetch. Mutually exclusive with start_date/end_date."
        ),
    ),
    start_date: date | None = Query(
        None,
        description="Inclusive range start (local calendar day). Must be paired with end_date.",
    ),
    end_date: date | None = Query(
        None,
        description="Inclusive range end (local calendar day). Must be paired with start_date.",
    ),
    *,
    db: Db,
) -> ApiResponse[RollupsResponse]:
    """Return daily rollups + deterministic anomaly flags for one day or a range.

    **Local-day semantics**: ``date``/``start_date``/``end_date`` are
    calendar dates in the rollup materializer's timezone
    (``rollups.DEFAULT_TIMEZONE``, currently ``Asia/Singapore`` — see design
    doc §3.3 and PR #2998). They are NOT UTC dates: ``date=2026-07-05`` means
    the Singapore calendar day the ``chronicler_rollup_daily`` job rolls up,
    the same local day ``/briefing`` and ``/aggregate/day-close`` already key
    on. Every ``daily_rollups`` row also carries its own ``timezone`` column
    (currently always the same value), echoed back per-day in the response.

    Provide exactly one of ``date`` alone, or ``start_date`` + ``end_date``
    together (both required if either is given; ``end_date`` must not be
    before ``start_date``; span capped at 92 days).

    **Three distinct "no number here" states** (classify-before-flagging,
    design doc §2.5 — see ``RollupsResponse``/``RollupDay``/``RollupLaneRow``
    docstrings for the full contract):

    - ``RollupDay.status == "not_yet_materialized"`` — a legitimately absent
      day (not yet fully elapsed, or the materializer job's lookback window
      has not reached it). Not an error: ``rollups_source_error`` stays
      ``False`` for this day.
    - ``RollupLaneRow.unavailable == True`` — a ``feeder_dark`` flag on this
      day names a source that contributes to this lane. The lane's
      ``seconds``/``episode_count`` may be a truthful 0 or a stale carried
      value; either way a client MUST render "data unavailable" for it, never
      a false all-clear zero.
    - ``RollupsResponse.rollups_source_error == True`` — the query itself
      failed (e.g. a dropped connection). Every requested day is returned
      with ``status == "unknown"`` and empty ``lanes``/``flags`` — this is
      never a truthful empty result.
    """
    if rollup_date is not None and (start_date is not None or end_date is not None):
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="conflicting_parameters",
                    message="Provide either 'date' or 'start_date'+'end_date', not both.",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    if rollup_date is not None:
        range_start: date = rollup_date
        range_end: date = rollup_date
    else:
        if (start_date is None) != (end_date is None):
            return JSONResponse(
                status_code=400,
                content=ErrorResponse(
                    error=ErrorDetail(
                        code="missing_parameter",
                        message="start_date and end_date must be provided together.",
                        butler="chronicler",
                    )
                ).model_dump(exclude_none=True),
            )
        if start_date is None or end_date is None:
            return JSONResponse(
                status_code=400,
                content=ErrorResponse(
                    error=ErrorDetail(
                        code="missing_parameter",
                        message="Provide either 'date' or 'start_date'+'end_date'.",
                        butler="chronicler",
                    )
                ).model_dump(exclude_none=True),
            )
        if end_date < start_date:
            return JSONResponse(
                status_code=400,
                content=ErrorResponse(
                    error=ErrorDetail(
                        code="invalid_time_range",
                        message="end_date must not be before start_date.",
                        butler="chronicler",
                    )
                ).model_dump(exclude_none=True),
            )
        range_start, range_end = start_date, end_date

    span_days = (range_end - range_start).days + 1
    if span_days > _ROLLUPS_MAX_RANGE_DAYS:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="range_too_large",
                    message=(
                        f"Requested range spans {span_days} days; max is {_ROLLUPS_MAX_RANGE_DAYS}."
                    ),
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    _tracer = trace.get_tracer("butlers.chronicler")
    with _tracer.start_as_current_span("chronicler.rollups") as span:
        pool = _pool(db)

        rollups_source_error = False
        try:
            rollup_rows = await list_daily_rollups_range(
                pool, start_date=range_start, end_date=range_end
            )
            flag_rows = await list_daily_rollup_flags_range(
                pool, start_date=range_start, end_date=range_end
            )
        except Exception:
            logger.exception(
                "chronicler.rollups: query failed for range %s..%s", range_start, range_end
            )
            rollups_source_error = True
            rollup_rows = []
            flag_rows = []

        span.set_attribute("chronicler.rollups.source_error", rollups_source_error)

        rollups_by_date: dict[date, list[Any]] = defaultdict(list)
        for r in rollup_rows:
            rollups_by_date[r.local_date].append(r)
        flags_by_date: dict[date, list[Any]] = defaultdict(list)
        for f in flag_rows:
            flags_by_date[f.local_date].append(f)

        days: list[RollupDay] = []
        current = range_start
        while current <= range_end:
            day_rollups = rollups_by_date.get(current, [])
            day_flags = flags_by_date.get(current, [])

            if rollups_source_error:
                status = "unknown"
            elif day_rollups:
                status = "materialized"
            else:
                status = "not_yet_materialized"

            if status != "materialized":
                # Both "unknown" (query failed) and "not_yet_materialized"
                # (legitimately no rows yet) return empty lanes/flags — the
                # ``status`` string is what distinguishes them, not the shape
                # of this array. Only a "materialized" day gets the
                # zero-filled-per-LANES treatment below.
                lane_rows: list[Any] = []
                flag_out: list[Any] = []
            else:
                feeder_dark_row = next((f for f in day_flags if f.flag_type == "feeder_dark"), None)
                dark_sources: set[str] = (
                    set(feeder_dark_row.detail.get("dark_sources", []))
                    if feeder_dark_row
                    else set()
                )
                lanes_by_name = {r.lane: r for r in day_rollups}
                lane_rows = [
                    RollupLaneRow(
                        lane=lane,
                        seconds=lanes_by_name[lane].seconds if lane in lanes_by_name else 0,
                        episode_count=(
                            lanes_by_name[lane].episode_count if lane in lanes_by_name else 0
                        ),
                        distinct_place_count=(
                            lanes_by_name[lane].distinct_place_count
                            if lane in lanes_by_name
                            else None
                        ),
                        unavailable=bool(sources_for_lane(lane) & dark_sources),
                    )
                    for lane in sorted(LANES)
                ]
                flag_out = [
                    RollupFlagRow(
                        flag_type=f.flag_type,
                        severity=f.severity,
                        detail=f.detail,
                        narrative=f.narrative,
                    )
                    for f in day_flags
                ]

            # Day summary is written identically onto every lane row for the date
            # by the narration job (migration chronicler_020), so read it off the
            # first rollup row. None when not materialized (no rows carry it) or
            # when the labeling pass has not run — a legitimate absence, not an
            # error, so ``rollups_source_error`` is unaffected.
            day_narrative = day_rollups[0].narrative if day_rollups else None

            days.append(
                RollupDay(
                    local_date=current.isoformat(),
                    timezone=day_rollups[0].timezone if day_rollups else ROLLUPS_DEFAULT_TIMEZONE,
                    status=status,
                    lanes=lane_rows,
                    flags=flag_out,
                    narrative=day_narrative,
                )
            )
            current += timedelta(days=1)

        span.set_attribute("chronicler.rollups.day_count", len(days))

        return ApiResponse[RollupsResponse](
            data=RollupsResponse(
                start_date=range_start.isoformat(),
                end_date=range_end.isoformat(),
                tz=ROLLUPS_DEFAULT_TIMEZONE,
                days=days,
                rollups_source_error=rollups_source_error,
            )
        )


# ── GET /api/chronicler/balance, GET /api/chronicler/trends ────────────────
#
# bu-jc6htw.2 (Chronicler IEA p9b, split from old p9 per eng-bar review).
# Both endpoints read chronicler.daily_rollups (the same materialized
# per-day/per-lane totals GET /rollups reads) and derive a trailing rolling
# "usual" baseline via balance.compute_daily_balance — see balance.py's
# module docstring for why this does NOT depend on the separate memory
# write-back loop (tasks.md S8, bu-93y4rt).


def _dark_sources_from_flags(flag_rows: list[Any]) -> set[str]:
    """Extract the ``feeder_dark`` flag's dark_sources set, or empty.

    Same extraction ``GET /rollups`` performs per day — factored out so
    ``/balance`` and ``/trends`` share it without re-deriving the shape.
    """
    feeder_dark_row = next((f for f in flag_rows if f.flag_type == "feeder_dark"), None)
    if feeder_dark_row is None:
        return set()
    return set(feeder_dark_row.detail.get("dark_sources", []))


_BALANCE_MAX_LOOKBACK_DAYS = 180


@router.get("/balance", response_model=ApiResponse[BalanceResponse])
async def get_daily_balance(
    balance_date: date = Query(
        ...,
        alias="date",
        description="Local calendar day (rollup timezone) to compute balance for.",
    ),
    lookback_days: int = Query(
        DEFAULT_BASELINE_LOOKBACK_DAYS,
        ge=1,
        le=_BALANCE_MAX_LOOKBACK_DAYS,
        description="Trailing local-day window (excluding today) used for the 'usual' baseline",
    ),
    *,
    db: Db,
) -> ApiResponse[BalanceResponse]:
    """Return the target day's per-lane totals annotated against the owner's
    rolling baseline ("vs usual").

    ``date`` uses the same local-day semantics as ``GET /rollups``
    (``rollups.DEFAULT_TIMEZONE``). The baseline is the trailing mean over
    ``lookback_days`` materialized prior days for each lane — a lane with no
    baseline history yet reports ``baseline_seconds=null`` rather than a
    fabricated 0 (see ``BalanceLaneRow`` docstring).

    Mirrors ``GET /rollups``'s three-state day status
    (``materialized``/``not_yet_materialized``/``unknown``) and the
    ``feeder_dark``-marks-lane-unavailable cross-reference.
    """
    baseline_start = balance_date - timedelta(days=lookback_days)
    baseline_end = balance_date - timedelta(days=1)

    _tracer = trace.get_tracer("butlers.chronicler")
    with _tracer.start_as_current_span("chronicler.balance") as span:
        pool = _pool(db)

        balance_source_error = False
        try:
            target_rows = await list_daily_rollups_range(
                pool, start_date=balance_date, end_date=balance_date
            )
            baseline_rows = await list_daily_rollups_range(
                pool, start_date=baseline_start, end_date=baseline_end
            )
            target_flags = await list_daily_rollup_flags_range(
                pool, start_date=balance_date, end_date=balance_date
            )
        except Exception:
            logger.exception("chronicler.balance: query failed for date=%s", balance_date)
            balance_source_error = True
            target_rows, baseline_rows, target_flags = [], [], []

        span.set_attribute("chronicler.balance.source_error", balance_source_error)

        if balance_source_error:
            status = "unknown"
        elif target_rows:
            status = "materialized"
        else:
            status = "not_yet_materialized"

        lanes: list[BalanceLaneRow] = []
        if status == "materialized":
            day_seconds_by_lane = {r.lane: r.seconds for r in target_rows}
            baseline_seconds_by_lane: dict[str, list[int]] = defaultdict(list)
            for r in baseline_rows:
                baseline_seconds_by_lane[r.lane].append(r.seconds)
            dark_sources = _dark_sources_from_flags(target_flags)

            for lb in compute_daily_balance(day_seconds_by_lane, baseline_seconds_by_lane):
                lanes.append(
                    BalanceLaneRow(
                        lane=lb.lane,
                        seconds=lb.seconds,
                        baseline_seconds=lb.baseline_seconds,
                        delta_seconds=lb.delta_seconds,
                        baseline_sample_days=lb.baseline_sample_days,
                        unavailable=bool(sources_for_lane(lb.lane) & dark_sources),
                    )
                )

        span.set_attribute("chronicler.balance.lane_count", len(lanes))

        return ApiResponse[BalanceResponse](
            data=BalanceResponse(
                local_date=balance_date.isoformat(),
                timezone=ROLLUPS_DEFAULT_TIMEZONE,
                status=status,
                baseline_lookback_days=lookback_days,
                lanes=lanes,
                balance_source_error=balance_source_error,
            )
        )


_TRENDS_WINDOW_DAYS: dict[str, int] = {"week": 7, "month": 30}


@router.get("/trends", response_model=ApiResponse[TrendsResponse])
async def get_trends(
    window: str = Query(
        "week", description="'week' (trailing 7 days) or 'month' (trailing 30 days)."
    ),
    end_date: date | None = Query(
        None,
        description="Last local day of the window (inclusive). Defaults to the most recent day",
    ),
    lookback_days: int = Query(
        DEFAULT_BASELINE_LOOKBACK_DAYS,
        ge=1,
        le=_BALANCE_MAX_LOOKBACK_DAYS,
        description="Trailing local-day window used for each day's 'usual' baseline.",
    ),
    *,
    db: Db,
) -> ApiResponse[TrendsResponse]:
    """Return week/month-grained per-lane balance trends, streaks, and anomalies.

    Each day in the window gets the same vs-baseline treatment as
    ``GET /balance`` (trailing ``lookback_days`` mean, ``feeder_dark``
    cross-reference). ``streak_days`` is the trailing run of consecutive
    non-zero-activity days ending at ``end_date``. ``anomalies`` flags days
    whose delta clears ``balance.is_lane_anomalous``'s thresholds — a day
    needs a full-size baseline sample before it can be flagged, so the start
    of a rollup history never produces spurious anomalies.
    """
    if window not in _TRENDS_WINDOW_DAYS:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="invalid_parameter",
                    message="window must be 'week' or 'month'",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    window_days = _TRENDS_WINDOW_DAYS[window]
    resolved_end = end_date or (
        datetime.now(UTC).astimezone(zoneinfo.ZoneInfo(ROLLUPS_DEFAULT_TIMEZONE)).date()
    )
    start_date = resolved_end - timedelta(days=window_days - 1)
    fetch_start = start_date - timedelta(days=lookback_days)

    _tracer = trace.get_tracer("butlers.chronicler")
    with _tracer.start_as_current_span("chronicler.trends") as span:
        pool = _pool(db)

        trends_source_error = False
        try:
            all_rows = await list_daily_rollups_range(
                pool, start_date=fetch_start, end_date=resolved_end
            )
            all_flags = await list_daily_rollup_flags_range(
                pool, start_date=start_date, end_date=resolved_end
            )
        except Exception:
            logger.exception(
                "chronicler.trends: query failed for range %s..%s", fetch_start, resolved_end
            )
            trends_source_error = True
            all_rows, all_flags = [], []

        span.set_attribute("chronicler.trends.source_error", trends_source_error)

        rows_by_date: dict[date, list[Any]] = defaultdict(list)
        for r in all_rows:
            rows_by_date[r.local_date].append(r)
        flags_by_date: dict[date, list[Any]] = defaultdict(list)
        for f in all_flags:
            flags_by_date[f.local_date].append(f)

        lane_series: dict[str, list[TrendLaneDay]] = {lane: [] for lane in sorted(LANES)}
        lane_daily_seconds: dict[str, list[int]] = {lane: [] for lane in sorted(LANES)}
        anomalies: list[TrendAnomaly] = []

        current = start_date
        while current <= resolved_end:
            day_rows = rows_by_date.get(current, [])
            if trends_source_error:
                day_status = "unknown"
            elif day_rows:
                day_status = "materialized"
            else:
                day_status = "not_yet_materialized"

            if day_status == "materialized":
                day_seconds_by_lane = {r.lane: r.seconds for r in day_rows}
                baseline_start = current - timedelta(days=lookback_days)
                baseline_end = current - timedelta(days=1)
                baseline_seconds_by_lane: dict[str, list[int]] = defaultdict(list)
                for d in range(lookback_days):
                    day_in_baseline = baseline_end - timedelta(days=d)
                    if day_in_baseline < baseline_start:
                        break
                    for r in rows_by_date.get(day_in_baseline, []):
                        baseline_seconds_by_lane[r.lane].append(r.seconds)
                dark_sources = _dark_sources_from_flags(flags_by_date.get(current, []))

                for lb in compute_daily_balance(day_seconds_by_lane, baseline_seconds_by_lane):
                    unavailable = bool(sources_for_lane(lb.lane) & dark_sources)
                    lane_series[lb.lane].append(
                        TrendLaneDay(
                            local_date=current.isoformat(),
                            status=day_status,
                            seconds=lb.seconds,
                            baseline_seconds=lb.baseline_seconds,
                            delta_seconds=lb.delta_seconds,
                            unavailable=unavailable,
                        )
                    )
                    lane_daily_seconds[lb.lane].append(lb.seconds)
                    if not unavailable and is_lane_anomalous(lb):
                        anomalies.append(
                            TrendAnomaly(
                                lane=lb.lane,
                                local_date=current.isoformat(),
                                seconds=lb.seconds,
                                baseline_seconds=lb.baseline_seconds,
                                delta_seconds=lb.delta_seconds,
                                direction="spike" if lb.delta_seconds > 0 else "drop",
                            )
                        )
            else:
                for lane in sorted(LANES):
                    lane_series[lane].append(
                        TrendLaneDay(local_date=current.isoformat(), status=day_status)
                    )
                    lane_daily_seconds[lane].append(0)

            current += timedelta(days=1)

        lanes = [
            TrendLaneSeries(
                lane=lane,
                days=lane_series[lane],
                streak_days=compute_lane_streak(lane_daily_seconds[lane]),
            )
            for lane in sorted(LANES)
        ]

        span.set_attribute("chronicler.trends.anomaly_count", len(anomalies))

        return ApiResponse[TrendsResponse](
            data=TrendsResponse(
                window=window,
                start_date=start_date.isoformat(),
                end_date=resolved_end.isoformat(),
                tz=ROLLUPS_DEFAULT_TIMEZONE,
                baseline_lookback_days=lookback_days,
                lanes=lanes,
                anomalies=anomalies,
                trends_source_error=trends_source_error,
            )
        )


# ── GET /api/chronicler/who-you-were-with ───────────────────────────────────
#
# bu-jc6htw.2 (Chronicler IEA p9b). Per RFC 0014 §D17 the chronicler dashboard
# API must not read cross-schema — companion identity was already resolved to
# an entity_id at write time (adapters.comms.CommsSocialAdapter, via
# relationship.entity_facts, grant core_150). This handler reads ONLY
# chronicler's own schema (v_episodes_corrected + episode_entities) for
# entity_id/duration/channel, then resolves entity_id -> display_name via
# DatabaseManager.fan_out_with_status against the relationship butler's OWN
# pool — the same sanctioned cross-BUTLER pattern GET /ops/sessions uses
# (fan_out queries a butler's own schema-scoped pool, never the chronicler
# pool cross-schema).


def _channel_for_payload(payload: dict[str, Any]) -> str:
    """Human-readable channel label for a social-lane episode's payload.

    Comms-sourced episodes carry ``payload.channel`` (e.g. ``"telegram_bot"``,
    mapped through ``CHANNEL_LABELS``). A social-lane episode with no
    ``channel`` key is a non-comms (e.g. future co-presence) source and is
    labelled ``"in-person"`` per the "Who-You-Were-With Endpoint" spec
    (channel is "in-person vs a comms channel").
    """
    channel = payload.get("channel")
    if not channel:
        return "in-person"
    return CHANNEL_LABELS.get(channel, channel)


@router.get("/who-you-were-with", response_model=ApiResponse[WhoYouWereWithResponse])
async def get_who_you_were_with(
    start_at: datetime | None = Query(None, description="Inclusive window start (UTC or tz-aware)"),
    end_at: datetime | None = Query(None, description="Exclusive window end (UTC or tz-aware)"),
    tz: str = Query("UTC", description="IANA timezone for display purposes"),
    *,
    db: Db,
) -> ApiResponse[WhoYouWereWithResponse]:
    """Return the resolved people the owner spent time with in the window.

    Reads ``activity``-layer, ``social``-lane episodes and their
    ``episode_entities`` participant rows (role != 'owner'). Groups by
    (entity_id, channel) and unions overlapping episode spans per group, same
    convention every other aggregate endpoint uses. Episodes with no resolved
    participant are returned as a single ``unattributed=True`` entry per
    channel rather than dropped.

    Restricted episodes are excluded; tombstoned episodes are excluded.
    """
    if start_at is None or end_at is None:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="missing_parameter",
                    message="start_at and end_at are required",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    if end_at <= start_at:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="invalid_time_range",
                    message="end_at must be strictly after start_at",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    try:
        zoneinfo.ZoneInfo(tz)
    except (zoneinfo.ZoneInfoNotFoundError, KeyError):
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="invalid_timezone",
                    message=f"Unrecognized IANA timezone: {tz!r}",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    _tracer = trace.get_tracer("butlers.chronicler")
    with _tracer.start_as_current_span("chronicler.who_you_were_with") as span:
        pool = _pool(db)

        source_error = False
        try:
            rows = await pool.fetch(
                """
                SELECT
                    e.id AS episode_id,
                    e.source_name,
                    e.episode_type,
                    e.start_at,
                    e.end_at,
                    e.payload,
                    ee.entity_id
                FROM v_episodes_corrected e
                LEFT JOIN episode_entities ee
                    ON ee.episode_id = e.id AND ee.role != 'owner'
                WHERE e.layer = 'activity'
                  AND e.tombstone_at IS NULL
                  AND e.privacy IN ('normal', 'sensitive')
                  AND e.start_at < $2
                  AND (e.end_at IS NULL OR e.end_at > $1)
                """,
                start_at,
                end_at,
            )
        except Exception:
            logger.exception(
                "chronicler.who_you_were_with: query failed for window %s..%s", start_at, end_at
            )
            source_error = True
            rows = []

        span.set_attribute("chronicler.who_you_were_with.source_error", source_error)

        groups: dict[tuple[Any, str], dict[str, Any]] = defaultdict(
            lambda: {"intervals": [], "episode_count": 0}
        )
        distinct_entity_ids: set[Any] = set()

        for row in rows:
            payload = _coerce_payload(row["payload"])
            ep_lane = lane_for_activity(
                "activity",
                row["source_name"],
                row["episode_type"],
                trigger_source=payload.get("trigger_source"),
            )
            if ep_lane != "social":
                continue

            ep_start: datetime = row["start_at"]
            ep_end: datetime | None = row["end_at"]
            ep_end_resolved = ep_end if ep_end is not None else end_at
            overlap_start = max(ep_start, start_at)
            overlap_end = min(ep_end_resolved, end_at)
            if overlap_end <= overlap_start:
                continue

            channel = _channel_for_payload(payload)
            entity_id = row["entity_id"]
            if entity_id is not None:
                distinct_entity_ids.add(entity_id)

            group_key = (entity_id, channel)
            group = groups[group_key]
            group["intervals"].append((overlap_start, overlap_end))
            group["episode_count"] += 1

        # ── Resolve entity_id -> display_name via the relationship butler's
        # own pool (cross-BUTLER fan_out, not a cross-schema chronicler read).
        display_names: dict[Any, str] = {}
        companion_names_unavailable = False
        if distinct_entity_ids:
            entities_results, failed = await db.fan_out_with_status(
                "SELECT id, canonical_name FROM entities WHERE id = ANY($1::uuid[])",
                args=(list(distinct_entity_ids),),
                butler_names=["relationship"],
            )
            if "relationship" in failed:
                companion_names_unavailable = True
            for name_rows in entities_results.values():
                for r in name_rows:
                    if r["canonical_name"]:
                        display_names[r["id"]] = r["canonical_name"]

        companions: list[CompanionEntry] = []
        for (entity_id, channel), data in groups.items():
            companions.append(
                CompanionEntry(
                    entity_id=str(entity_id) if entity_id is not None else None,
                    display_name=display_names.get(entity_id) if entity_id is not None else None,
                    unattributed=entity_id is None,
                    channel=channel,
                    co_present_seconds=union_seconds(data["intervals"]),
                    episode_count=data["episode_count"],
                )
            )

        companions.sort(key=lambda c: -c.co_present_seconds)

        span.set_attribute("chronicler.who_you_were_with.companion_count", len(companions))

        return ApiResponse[WhoYouWereWithResponse](
            data=WhoYouWereWithResponse(
                start_at=start_at,
                end_at=end_at,
                tz=tz,
                companions=companions,
                companion_names_unavailable=companion_names_unavailable,
                who_you_were_with_source_error=source_error,
            )
        )


# ── GET /api/chronicler/aggregate/day-close ───────────────────────────────


@router.get(
    "/aggregate/day-close",
    response_model=Annotated[
        DayCloseFreshResponse | DayCloseStaleResponse | DayCloseInvalidResponse,
        "Fresh prose, stale marker, or invalid-without-prose marker",
    ],
    openapi_extra={
        "parameters": [
            {
                "name": "date",
                "in": "query",
                "required": True,
                "description": "Required non-empty YYYY-MM-DD date for the day-close window.",
                "schema": {"type": "string", "format": "date", "minLength": 1},
            },
            {
                "name": "tz",
                "in": "query",
                "required": True,
                "description": "Exact non-empty IANA timezone for the requested local day.",
                "schema": {"type": "string", "minLength": 1},
            },
        ]
    },
)
async def get_day_close_cache(
    date_param: str | None = Query(
        None,
        alias="date",
        description="YYYY-MM-DD date for day-close window",
        include_in_schema=False,
    ),
    tz: str | None = Query(
        None,
        description="Required exact IANA timezone for the requested local day",
        include_in_schema=False,
    ),
    *,
    db: Db,
) -> DayCloseFreshResponse | DayCloseStaleResponse | DayCloseInvalidResponse | JSONResponse:
    """Return cached day-close prose, a stale marker, or an invalid marker.

    Looks up ``tier2_cache`` by the exact
    ``cache_key=day_close:{YYYY-MM-DD}:tz:{IANA-timezone}`` tuple.
    Returns 404 if no cache entry exists.

    Admission validation precedes staleness: a row that failed the
    deterministic day-close admission predicate (bad shape or a mismatched
    structured ``date_label``) returns invalid-without-prose regardless of
    its staleness state.

    Otherwise, checks whether any episode, point_event, or override row in
    the cached window [start_at, end_at) has been modified (tombstoned,
    updated, or created) after ``cache_built_at``.

    - **Fresh:** returns ``{prose, provenance_refs, cache_built_at}``.
    - **Stale:** returns ``{stale: true, cache_built_at, last_invalidating_event_at}``.
    - **Invalid:** returns ``{invalid: true, invalid_reason, cache_built_at}``.

    No LLM is invoked on this path.
    """
    # ── Parameter validation ───────────────────────────────────────────
    if date_param is None:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="missing_parameter",
                    message="date is required",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    try:
        parsed_date = date.fromisoformat(date_param)
    except ValueError:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="invalid_date_format",
                    message=f"date must be a valid YYYY-MM-DD date; got {date_param!r}",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    try:
        timezone_name, _timezone = resolve_day_close_timezone(tz)
    except MissingDayCloseTimezoneError:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="missing_parameter",
                    message="tz is required",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )
    except InvalidDayCloseTimezoneError:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="invalid_timezone",
                    message=f"Unrecognized IANA timezone: {tz!r}",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    _tracer = trace.get_tracer("butlers.chronicler")
    with _tracer.start_as_current_span("chronicler.aggregate.day_close") as span:
        pool = _pool(db)

        cache_key = day_close_cache_key(parsed_date, timezone_name)

        # ── Step 1: fetch the cache row ──────────────────────────────────────
        t0 = time.perf_counter()
        cache_row = await pool.fetchrow(
            """
            SELECT cache_key, start_at, end_at, cache_built_at, prose, provenance_refs,
                   date_label, invalid_reason
            FROM tier2_cache
            WHERE cache_key = $1
              AND superseded_at IS NULL
            """,
            cache_key,
        )

        if cache_row is None:
            span.set_attribute("chronicler.day_close.cache_state", "miss")
            raise HTTPException(
                status_code=404, detail=f"No day-close cache entry for {parsed_date}"
            )

        start_at = cache_row["start_at"]
        end_at = cache_row["end_at"]
        cache_built_at = cache_row["cache_built_at"]

        # ── Step 1b: local-day binding and admission precede staleness ───────
        # A cache key alone cannot prove the row's persisted UTC window belongs
        # to this requested local day. Contain a malformed row before prose
        # admission or staleness can expose it as fresh/stale.
        expected_start_at, expected_end_at = day_window_utc(parsed_date, timezone_name)
        if start_at != expected_start_at or end_at != expected_end_at:
            span.set_attribute("chronicler.day_close.cache_state", "invalid")
            return DayCloseInvalidResponse(
                invalid=True,
                invalid_reason="date_mismatch",
                cache_built_at=cache_built_at,
            )

        # A row that failed the deterministic day-close admission predicate is
        # contained regardless of its staleness state (design.md decision 4).
        invalid_reason = cache_row.get("invalid_reason") or classify_day_close_candidate(
            cache_row.get("prose"),
            date_label=cache_row.get("date_label"),
            expected_date_iso=parsed_date.isoformat(),
        )
        if invalid_reason:
            span.set_attribute("chronicler.day_close.cache_state", "invalid")
            return DayCloseInvalidResponse(
                invalid=True,
                invalid_reason=invalid_reason,
                cache_built_at=cache_built_at,
            )

        # ── Step 2: query staleness signals in the cached window ─────────────
        # Nine signals:
        #   episodes.tombstone_at  > cache_built_at  (window-scoped)
        #   episodes.updated_at    > cache_built_at  (window-scoped)
        #   point_events.tombstone_at > cache_built_at  (window-scoped)
        #   point_events.updated_at   > cache_built_at  (window-scoped)
        #   overrides.created_at   > cache_built_at  (for window-overlapping overrides)
        #   episodes cited in provenance_refs but now outside the window (updated_at signal)
        #   point_events cited in provenance_refs but now outside the window (updated_at signal)
        #   overrides that move an episode INTO the window via corrected_start_at
        #   overrides that move a point_event INTO the window via corrected_start_at
        #
        # Window condition for episodes / point_events (signals 1-4):
        #   rows whose time span overlaps [start_at, end_at)
        #   i.e. start_at_col < end_at AND (end_at_col IS NULL OR end_at_col > start_at)
        #
        # Signals 6-7 (provenance-ref staleness): an episode or point_event that was
        # cited when the cache was built may have been updated to move its time range
        # OUTSIDE the cached window.  The window filter above would then miss it.
        # Fix: join against the source_ref values stored in tier2_cache.provenance_refs
        # so updates to those specific rows trigger staleness regardless of their
        # current window position.
        #
        # Signal 8 (corrected_start_at staleness): an override created after the cache
        # was built that sets corrected_start_at within [start_at, end_at) pulls an
        # episode that was originally OUTSIDE the cached window INTO scope.  Signals
        # 1-5 miss this because they scope overrides via the episode's original
        # start_at/end_at.  We detect it by checking corrected_start_at directly.
        #
        # For overrides we join back to the underlying episode/point_event to
        # scope them to the same window.  We use a single UNION query to get
        # the MAX timestamp in one round-trip.
        staleness_row = await pool.fetchrow(
            """
            SELECT MAX(ts) AS last_invalidating_event_at
            FROM (
                -- episodes.tombstone_at
                SELECT tombstone_at AS ts
                FROM episodes
                WHERE tombstone_at > $3
                  AND start_at < $2
                  AND (end_at IS NULL OR end_at > $1)

                UNION ALL

                -- episodes.updated_at
                SELECT updated_at AS ts
                FROM episodes
                WHERE updated_at > $3
                  AND start_at < $2
                  AND (end_at IS NULL OR end_at > $1)

                UNION ALL

                -- point_events.tombstone_at
                SELECT tombstone_at AS ts
                FROM point_events
                WHERE tombstone_at > $3
                  AND occurred_at >= $1
                  AND occurred_at < $2

                UNION ALL

                -- point_events.updated_at
                SELECT updated_at AS ts
                FROM point_events
                WHERE updated_at > $3
                  AND occurred_at >= $1
                  AND occurred_at < $2

                UNION ALL

                -- overrides scoped via episode window
                SELECT o.created_at AS ts
                FROM overrides o
                JOIN episodes e ON e.id = o.target_id AND o.target_kind = 'episode'
                WHERE o.created_at > $3
                  AND e.start_at < $2
                  AND (e.end_at IS NULL OR e.end_at > $1)

                UNION ALL

                -- overrides scoped via point_event window
                SELECT o.created_at AS ts
                FROM overrides o
                JOIN point_events p ON p.id = o.target_id AND o.target_kind = 'point_event'
                WHERE o.created_at > $3
                  AND p.occurred_at >= $1
                  AND p.occurred_at < $2

                UNION ALL

                -- provenance-ref staleness: episodes cited by this cache entry
                -- that were updated (possibly moving their window) after cache was built.
                -- Catches updates that push the episode outside the cached window.
                SELECT e.updated_at AS ts
                FROM tier2_cache c
                CROSS JOIN LATERAL jsonb_array_elements_text(c.provenance_refs) AS ref
                JOIN episodes e ON e.source_ref = ref
                WHERE c.cache_key = $4
                  AND c.superseded_at IS NULL
                  AND e.updated_at > $3

                UNION ALL

                -- provenance-ref staleness: point_events cited by this cache entry
                -- that were updated (possibly moving their window) after cache was built.
                SELECT p.updated_at AS ts
                FROM tier2_cache c
                CROSS JOIN LATERAL jsonb_array_elements_text(c.provenance_refs) AS ref
                JOIN point_events p ON p.source_ref = ref
                WHERE c.cache_key = $4
                  AND c.superseded_at IS NULL
                  AND p.updated_at > $3

                UNION ALL

                -- corrected_start_at staleness: an override that moves an episode INTO
                -- the cached window by setting corrected_start_at within [start_at, end_at).
                -- The episode's original start_at may lie outside the window, so signals
                -- 1-5 would miss it.  We detect it via corrected_start_at directly.
                SELECT o.created_at AS ts
                FROM overrides o
                JOIN episodes e ON e.id = o.target_id AND o.target_kind = 'episode'
                WHERE o.created_at > $3
                  AND o.corrected_start_at >= $1
                  AND o.corrected_start_at < $2

                UNION ALL

                -- corrected_start_at staleness: an override that moves a point_event INTO
                -- the cached window by setting corrected_start_at within [start_at, end_at).
                -- The point_event's original occurred_at may lie outside the window, so
                -- signals 1-5 would miss it.  Parallel to the episode branch above.
                SELECT o.created_at AS ts
                FROM overrides o
                JOIN point_events pe ON pe.id = o.target_id AND o.target_kind = 'point_event'
                WHERE o.created_at > $3
                  AND o.corrected_start_at >= $1
                  AND o.corrected_start_at < $2
            ) invalidators
            """,
            start_at,
            end_at,
            cache_built_at,
            cache_key,
        )
        query_latency_ms = (time.perf_counter() - t0) * 1000
        span.set_attribute("chronicler.day_close.query_latency_ms", query_latency_ms)

        last_invalidating_event_at = (
            staleness_row["last_invalidating_event_at"] if staleness_row else None
        )

        if last_invalidating_event_at is not None:
            span.set_attribute("chronicler.day_close.cache_state", "stale")
            return DayCloseStaleResponse(
                stale=True,
                cache_built_at=cache_built_at,
                last_invalidating_event_at=last_invalidating_event_at,
            )

        # Fresh path: return prose + provenance_refs
        raw_refs = cache_row["provenance_refs"]
        if isinstance(raw_refs, str):
            try:
                provenance_refs = json.loads(raw_refs)
            except json.JSONDecodeError:
                provenance_refs = []
        elif isinstance(raw_refs, list):
            provenance_refs = raw_refs
        else:
            provenance_refs = []

        span.set_attribute("chronicler.day_close.cache_state", "fresh")
        return DayCloseFreshResponse(
            prose=cache_row["prose"],
            provenance_refs=provenance_refs,
            cache_built_at=cache_built_at,
        )


# ── POST /api/chronicler/aggregate/day-close/refresh ─────────────────────────

_DAY_CLOSE_REFRESH_MCP_TIMEOUT_SECONDS = 110.0


def _today_in_timezone(
    timezone: zoneinfo.ZoneInfo,
    *,
    now: datetime | None = None,
) -> date:
    """Return the current local calendar date for a validated request timezone."""
    return (now or datetime.now(UTC)).astimezone(timezone).date()


@router.post(
    "/aggregate/day-close/refresh",
    response_model=DayCloseRefreshResponse | DayCloseRefreshQuietResponse,
    status_code=200,
)
async def refresh_day_close(
    request: Request,
    body: DayCloseRefreshRequest = Body(...),
    *,
    db: Db,
    mcp_manager: MCPClientManager = Depends(get_mcp_manager),
) -> DayCloseRefreshResponse | DayCloseRefreshQuietResponse | JSONResponse:
    """Re-invoke the day-close Tier-2 path on demand (rate-limited per local-day tuple).

    Checks whether a ``tier2_cache`` row for the exact requested ``(date, tz)``
    tuple was built within the last 24 hours. If so, returns 429 with
    ``code=day_close_rate_limited`` and ``details.retry_after_seconds``.

    Otherwise, proxies the request to the running Chronicler daemon's dedicated
    infrastructure tool. The daemon owns dispatch, cache admission, and witness
    persistence; this split-process dashboard API never holds an in-process spawner.
    """
    # ── Validate timezone ─────────────────────────────────────────────────────
    try:
        timezone_name, timezone = resolve_day_close_timezone(body.tz)
    except MissingDayCloseTimezoneError:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="missing_parameter",
                    message="tz is required",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )
    except InvalidDayCloseTimezoneError:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="invalid_timezone",
                    message=f"Unrecognized IANA timezone: {body.tz!r}",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    today_local = _today_in_timezone(timezone)
    if body.date >= today_local:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="day_close_not_settled",
                    message=("Day-close refresh targets must be a settled historical local day."),
                    butler="chronicler",
                    details={
                        "date": body.date.isoformat(),
                        "today": today_local.isoformat(),
                        "tz": timezone_name,
                    },
                )
            ).model_dump(exclude_none=True),
        )

    try:
        client = await mcp_manager.get_client("chronicler")
        mcp_result = await asyncio.wait_for(
            client.call_tool(
                "chronicler_day_close_refresh",
                {"date_label": body.date.isoformat(), "timezone": timezone_name},
            ),
            timeout=_DAY_CLOSE_REFRESH_MCP_TIMEOUT_SECONDS,
        )
    except ButlerUnreachableError:
        payload: dict[str, Any] = {
            "status": "error",
            "code": "dispatch_unavailable",
            "message": "The Chronicler daemon is unavailable for day-close regeneration.",
        }
    except TimeoutError:
        payload = {
            "status": "error",
            "code": "dispatch_timeout",
            "message": "Day-close regeneration exceeded its execution deadline.",
        }
    except Exception:
        logger.exception("Chronicler day-close refresh MCP call failed")
        payload = {
            "status": "error",
            "code": "dispatch_unavailable",
            "message": "Day-close regeneration could not reach the Chronicler daemon.",
        }
    else:
        payload = {}
        raw_blocks = getattr(
            mcp_result,
            "content",
            mcp_result if isinstance(mcp_result, list) else None,
        )
        blocks = raw_blocks if isinstance(raw_blocks, list | tuple) else []
        if not getattr(mcp_result, "is_error", False):
            for block in blocks:
                text = getattr(block, "text", None)
                if not text:
                    continue
                try:
                    decoded = json.loads(text)
                except (json.JSONDecodeError, TypeError):
                    continue
                if isinstance(decoded, dict):
                    payload = decoded
                    break
        if not payload:
            payload = {
                "status": "error",
                "code": "invalid_refresh_response",
                "message": "The Chronicler daemon returned an invalid regeneration response.",
            }

    if payload.get("status") != "success":
        requested_code = str(payload.get("code") or "invalid_refresh_response")
        error_contract = {
            "missing_parameter": (400, "The regeneration timezone is required."),
            "invalid_date": (400, "The regeneration date is invalid."),
            "invalid_timezone": (400, "The regeneration timezone is invalid."),
            "day_close_not_settled": (400, "The regeneration date is not settled yet."),
            "refresh_context_forbidden": (403, "The regeneration context is not permitted."),
            "day_close_rate_limited": (429, "This day was regenerated recently."),
            "task_not_found": (503, "The Chronicler day-close task is unavailable."),
            "dispatch_unavailable": (503, "The Chronicler daemon is unavailable."),
            "dispatch_failed": (502, "Day-close regeneration failed during execution."),
            "dispatch_timeout": (504, "Day-close regeneration exceeded its execution deadline."),
            "cache_write_failed": (502, "Day-close regeneration produced no usable cache."),
            "coverage_witness_write_failed": (
                502,
                "Day-close regeneration produced no durable coverage witness.",
            ),
            "invalid_refresh_response": (
                502,
                "The Chronicler daemon returned an invalid response.",
            ),
        }
        code = requested_code if requested_code in error_contract else "invalid_refresh_response"
        error_status, error_message = error_contract[code]
        details = None
        if code == "day_close_rate_limited":
            raw_details = payload.get("details")
            retry_after = (
                raw_details.get("retry_after_seconds") if isinstance(raw_details, dict) else None
            )
            if (
                isinstance(retry_after, int)
                and not isinstance(retry_after, bool)
                and retry_after > 0
            ):
                details = {"retry_after_seconds": retry_after}
            else:
                code = "invalid_refresh_response"
                error_status, error_message = error_contract[code]
        return JSONResponse(
            status_code=error_status,
            content=ErrorResponse(
                error=ErrorDetail(
                    code=code,
                    message=error_message,
                    butler="chronicler",
                    details=details,
                )
            ).model_dump(exclude_none=True),
        )

    try:
        cache_key = payload["cache_key"]
        expected_cache_key = day_close_cache_key(body.date, timezone_name)
        if not isinstance(cache_key, str) or cache_key != expected_cache_key:
            raise ValueError("refresh response cache identity mismatch")
        if payload.get("quiet") is True:
            response_body: DayCloseRefreshResponse | DayCloseRefreshQuietResponse = (
                DayCloseRefreshQuietResponse(cache_key=cache_key)
            )
        else:
            invalid = payload["invalid"]
            invalid_reason = payload["invalid_reason"]
            if type(invalid) is not bool or invalid_reason not in {
                None,
                "inadmissible_prose",
                "date_mismatch",
            }:
                raise ValueError("refresh response admission state is invalid")
            if invalid != (invalid_reason is not None):
                raise ValueError("refresh response admission state is incoherent")
            response_body = DayCloseRefreshResponse(
                cache_key=cache_key,
                cache_built_at=payload["cache_built_at"],
                invalid=invalid,
                invalid_reason=invalid_reason,
            )
    except (KeyError, TypeError, ValueError):
        return JSONResponse(
            status_code=502,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="invalid_refresh_response",
                    message="The Chronicler daemon returned an invalid response.",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    # Explicit audit — middleware also fires; this carries the semantic operation label.
    await emit_dashboard_audit(
        db,
        butler="chronicler",
        operation="day_close_refresh_invoke",
        method="POST",
        path="/api/chronicler/aggregate/day-close/refresh",
        body={"date": body.date.isoformat(), "tz": timezone_name},
        response_status=200,
        request=request,
    )
    return response_body


# ── Editorial endpoints (bu-i29ix) ────────────────────────────────────────


def _parse_date_param(date_param: str | None) -> date:
    if date_param is None:
        # Default: yesterday in UTC. The frontend always passes an explicit date
        # picked from the owner's timezone, so this is just a defensive fallback.
        return (datetime.now(UTC) - timedelta(days=1)).date()
    try:
        return date.fromisoformat(date_param)
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail=f"date must be a valid YYYY-MM-DD date; got {date_param!r}",
        ) from exc


def _resolve_owner_tz_default() -> str:
    """Default timezone when the caller does not pass one.

    The chronicler page-level invariant (dashboard-chronicles spec) bars
    cross-schema reads from page-driven endpoints. The frontend already
    fetches the owner timezone via the dashboard settings router and
    passes it explicitly to chronicler endpoints, so this helper only
    needs to provide a stable fallback when the caller omits ``tz``.
    Default matches the SGT fallback used elsewhere in the chronicler
    surface.
    """
    return "Asia/Singapore"


def _attention_to_pydantic(items: list[Any]) -> list[ChroniclesAttentionItem]:
    return [
        ChroniclesAttentionItem(
            kind=it.kind,
            severity=it.severity,
            title=it.title,
            detail=it.detail,
            action_href=it.action_href,
        )
        for it in items
    ]


def _kpi_to_pydantic(kpi: Any) -> ChroniclesKpi:
    return ChroniclesKpi(
        hours_by_top_lanes=[
            ChroniclesLaneHours(lane=lh.lane, hours=lh.hours) for lh in kpi.hours_by_top_lanes
        ],
        longest_episode_minutes=kpi.longest_episode_minutes,
        longest_episode_title=kpi.longest_episode_title,
        longest_gap_minutes=kpi.longest_gap_minutes,
        sleep_minutes=kpi.sleep_minutes,
        streaks=ChroniclesStreaks(sleep=kpi.streaks.sleep, exercise=kpi.streaks.exercise),
    )


def _recent_days_to_pydantic(rows: list[Any]) -> list[ChroniclesRecentDay]:
    return [
        ChroniclesRecentDay(
            date=r.date,
            total_minutes=r.total_minutes,
            top_lane=r.top_lane,
            episode_count=r.episode_count,
        )
        for r in rows
    ]


def _subquery_availability_to_pydantic(
    rows: list[Any],
) -> list[ChroniclesBriefingSubqueryAvailability]:
    return [
        ChroniclesBriefingSubqueryAvailability(subquery=row.subquery, state=row.state)
        for row in rows
    ]


async def _voice_paragraph_from_cache(
    pool: Any, target: date, tz_name: str
) -> tuple[str | None, str]:
    """Return (paragraph, source) read from the day-close Tier-2 cache.

    source is one of 'llm·cached', 'stale', or 'templated'. When the cache
    is missing entirely, or the row failed the deterministic day-close
    admission predicate (admission precedes staleness — the same containment
    rule ``GET /aggregate/day-close`` applies), paragraph is None and the
    caller must produce a templated fallback.
    """
    cache_key = day_close_cache_key(target, tz_name)
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            """
            SELECT prose, cache_built_at, start_at, end_at, date_label, invalid_reason
            FROM tier2_cache
            WHERE cache_key = $1
              AND superseded_at IS NULL
            """,
            cache_key,
        )
    if row is None:
        return None, "templated"
    expected_start_at, expected_end_at = day_window_utc(target, tz_name)
    if row.get("start_at") != expected_start_at or row.get("end_at") != expected_end_at:
        return None, "templated"
    if row.get("invalid_reason") or classify_day_close_candidate(
        row.get("prose"),
        date_label=row.get("date_label"),
        expected_date_iso=target.isoformat(),
    ):
        return None, "templated"
    prose = row["prose"]
    cache_built_at = row["cache_built_at"]
    start_at = row["start_at"]
    end_at = row["end_at"]
    # Light staleness check: any episode tombstoned or updated within the
    # cached window after cache_built_at means stale. This is a
    # subset of the full check in get_day_close_cache; for the briefing we
    # do not need the corrected_start_at expansion paths.
    async with pool.acquire() as conn:
        any_invalidator = await conn.fetchval(
            """
            SELECT 1 FROM episodes
            WHERE (updated_at > $3 OR tombstone_at > $3)
              AND start_at < $2
              AND (end_at IS NULL OR end_at > $1)
            LIMIT 1
            """,
            start_at,
            end_at,
            cache_built_at,
        )
    source = "stale" if any_invalidator else "llm·cached"
    return prose, source


@router.get("/briefing", response_model=ChroniclesBriefing)
async def get_briefing(
    date_param: str | None = Query(
        None, alias="date", description="YYYY-MM-DD; defaults to yesterday in UTC"
    ),
    tz: str | None = Query(
        None,
        description="IANA timezone name. Defaults to Chronicler's stable fallback.",
    ),
    *,
    db: Db,
) -> ChroniclesBriefing:
    """Editorial briefing for a single day window.

    NEVER initiates a new LLM call. For a covered, available day,
    ``voice_paragraph`` is sourced from the existing day-close Tier-2 cache
    when fresh, marked stale when the cache has been invalidated by
    post-cache changes, or computed from a deterministic templated fallback
    when no cache row exists. For ``no_data``/``unavailable``/``degraded``
    days, the day-close cache is never consulted (fresh or stale); the
    response uses deterministic state-specific copy instead
    (clarify-chronicles-narrative-truth design.md decision 3).
    """
    from butlers.chronicler.editorial import (
        compose_briefing_payload,
        templated_voice_paragraph,
        templated_voice_paragraph_for_state,
    )

    target = _parse_date_param(date_param)
    tz_name = tz or _resolve_owner_tz_default()

    pool = _pool(db)
    payload = await compose_briefing_payload(pool, target, tz_name)
    if not payload.covered_and_available:
        voice_paragraph = templated_voice_paragraph_for_state(payload.state_class)
        voice_source = "templated"
    else:
        cache_paragraph, voice_source = await _voice_paragraph_from_cache(pool, target, tz_name)
        if cache_paragraph is None:
            voice_paragraph = templated_voice_paragraph(payload)
        else:
            voice_paragraph = cache_paragraph

    return ChroniclesBriefing(
        date=target.isoformat(),
        state_class=payload.state_class,
        headline=payload.headline,
        voice_paragraph=voice_paragraph,
        voice_source=voice_source,
        kpi=_kpi_to_pydantic(payload.kpi),
        attention_items=_attention_to_pydantic(payload.attention_items),
        recent_days=_recent_days_to_pydantic(payload.recent_days),
        subquery_availability=_subquery_availability_to_pydantic(payload.subquery_availability),
        earliest_date=payload.earliest_date,
    )


@router.get(
    "/attention",
    response_model=ApiResponse[list[ChroniclesAttentionItem]],
)
async def get_attention(
    date_param: str | None = Query(
        None, alias="date", description="YYYY-MM-DD; defaults to yesterday in UTC"
    ),
    tz: str | None = Query(None),
    *,
    db: Db,
) -> ApiResponse[list[ChroniclesAttentionItem]]:
    """Attention list for a single day window.

    Same data the briefing embeds, exposed standalone for cheaper polling.
    """
    from butlers.chronicler.editorial import compose_briefing_payload

    target = _parse_date_param(date_param)
    tz_name = tz or _resolve_owner_tz_default()
    pool = _pool(db)
    payload = await compose_briefing_payload(pool, target, tz_name)
    return ApiResponse(data=_attention_to_pydantic(payload.attention_items))


@router.get("/kpi", response_model=ApiResponse[ChroniclesKpi])
async def get_kpi(
    date_param: str | None = Query(
        None, alias="date", description="YYYY-MM-DD; defaults to yesterday in UTC"
    ),
    tz: str | None = Query(None),
    *,
    db: Db,
) -> ApiResponse[ChroniclesKpi]:
    """KPI snapshot for a single day window.

    Same data the briefing embeds, exposed standalone for cheaper polling.
    """
    from butlers.chronicler.editorial import compose_briefing_payload

    target = _parse_date_param(date_param)
    tz_name = tz or _resolve_owner_tz_default()
    pool = _pool(db)
    payload = await compose_briefing_payload(pool, target, tz_name)
    return ApiResponse(data=_kpi_to_pydantic(payload.kpi))


# ── Evidence chain + low-confidence correction prompts (IEA, tasks.md S9a) ──


def _coerce_ref_list(value: Any) -> list[str]:
    """Coerce a jsonb ``evidence_refs`` column into a list of strings.

    Mirrors ``storage._coerce_ref_list``: the jsonb codec usually decodes to a
    Python list already, but this guards NULL, a raw JSON string, and non-list
    payloads defensively.
    """
    if value is None:
        return []
    if isinstance(value, str):
        try:
            loaded = json.loads(value)
        except json.JSONDecodeError:
            return [value]
        value = loaded
    if isinstance(value, list):
        return [str(v) for v in value]
    return [str(value)]


# ── GET /api/chronicler/episodes/{id}/evidence-chain ──────────────────────


@router.get(
    "/episodes/{episode_id}/evidence-chain",
    response_model=ActivityEvidenceChain,
)
async def get_evidence_chain(
    episode_id: UUID,
    *,
    db: Db,
) -> ActivityEvidenceChain:
    """Return the evidence chain backing an activity — "why is this counted?".

    Resolves the canonical ``episode_event_links`` chain to the underlying
    point-events (via ``v_point_events_corrected`` so corrections are honoured)
    and returns each with its source name, relation, and a human-readable
    descriptor, alongside the activity's layer, confidence, and the denormalized
    ``evidence_refs`` convenience list.

    Returns 404 if the episode does not exist.
    """
    pool = _pool(db)

    ep_row = await pool.fetchrow(
        """
        SELECT id, layer, confidence, evidence_refs
        FROM v_episodes_corrected
        WHERE id = $1 AND tombstone_at IS NULL
        """,
        episode_id,
    )
    if ep_row is None:
        raise HTTPException(status_code=404, detail="Episode not found")

    link_rows = await pool.fetch(
        """
        SELECT v.id, v.source_name, v.event_type, v.occurred_at, v.title,
               v.privacy, l.relation
        FROM episode_event_links l
        JOIN v_point_events_corrected v ON v.id = l.event_id
        WHERE l.episode_id = $1
        ORDER BY v.occurred_at ASC, v.id ASC
        """,
        episode_id,
    )

    links = [
        EvidenceChainLink(
            event_id=str(r["id"]),
            source_name=r["source_name"],
            event_type=r["event_type"],
            occurred_at=r["occurred_at"],
            relation=r["relation"],
            descriptor=r["title"] or f"{r['source_name']} {r['event_type']}",
            privacy=r["privacy"],
        )
        for r in link_rows
    ]

    return ActivityEvidenceChain(
        episode_id=str(episode_id),
        layer=ep_row["layer"],
        confidence=ep_row["confidence"],
        evidence_refs=_coerce_ref_list(ep_row["evidence_refs"]),
        links=links,
    )


# ── GET /api/chronicler/correction-prompts ────────────────────────────────


@router.get("/correction-prompts", response_model=ApiResponse[CorrectionPrompts])
async def list_correction_prompts(
    start_at: datetime | None = Query(None, description="Inclusive window start (UTC or tz-aware)"),
    end_at: datetime | None = Query(None, description="Exclusive window end (UTC or tz-aware)"),
    tz: str = Query("UTC", description="IANA timezone for display purposes"),
    limit: int = Query(100, ge=1, le=500),
    *,
    db: Db,
) -> ApiResponse[CorrectionPrompts]:
    """Surface the window's low-confidence activities as correction prompts.

    Returns ``activity``-layer episodes with ``confidence='low'`` that overlap
    the window and have NOT yet been addressed via the corrections overlay
    (``corrected_at IS NULL``). Each prompt carries the activity's best-guess
    lane and its evidence so the owner can confirm or relabel it.

    The write path reuses the EXISTING corrections overlay — submit a correction
    via ``POST /api/chronicler/episodes/{id}/corrections``; the resulting
    ``overrides`` row sets ``corrected_at`` and the prompt drops off this list.
    No new corrections mechanism is introduced.

    Restricted episodes are excluded; tombstoned episodes are excluded.
    """
    if start_at is None or end_at is None:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="missing_parameter",
                    message="start_at and end_at are required",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    if end_at <= start_at:
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="invalid_time_range",
                    message="end_at must be strictly after start_at",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    try:
        zoneinfo.ZoneInfo(tz)
    except (zoneinfo.ZoneInfoNotFoundError, KeyError):
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                error=ErrorDetail(
                    code="invalid_timezone",
                    message=f"Unrecognized IANA timezone: {tz!r}",
                    butler="chronicler",
                )
            ).model_dump(exclude_none=True),
        )

    pool = _pool(db)

    rows = await pool.fetch(
        """
        SELECT
            id, source_name, episode_type, title, start_at, end_at,
            confidence, evidence_refs,
            payload->>'trigger_source' AS trigger_source
        FROM v_episodes_corrected
        WHERE layer = 'activity'
          AND confidence = 'low'
          AND corrected_at IS NULL
          AND tombstone_at IS NULL
          AND privacy IN ('normal', 'sensitive')
          AND start_at < $2
          AND (end_at IS NULL OR end_at > $1)
        ORDER BY start_at ASC, id ASC
        LIMIT $3
        """,
        start_at,
        end_at,
        limit,
    )

    prompts: list[CorrectionPrompt] = []
    for r in rows:
        refs = _coerce_ref_list(r["evidence_refs"])
        prompts.append(
            CorrectionPrompt(
                episode_id=str(r["id"]),
                source_name=r["source_name"],
                episode_type=r["episode_type"],
                title=r["title"],
                start_at=r["start_at"],
                end_at=r["end_at"],
                best_guess_lane=lane_for_activity(
                    "activity",
                    r["source_name"],
                    r["episode_type"],
                    trigger_source=r["trigger_source"],
                ),
                confidence=r["confidence"],
                evidence_refs=refs,
                evidence_count=len(refs),
            )
        )

    return ApiResponse[CorrectionPrompts](
        data=CorrectionPrompts(
            start_at=start_at,
            end_at=end_at,
            tz=tz,
            prompts=prompts,
        )
    )


# ── /api/chronicler/routines CRUD ─────────────────────────────────────────
#
# Owner-reviewable weekly routines (bu-whhll.9): rows mined by the
# deterministic weekly job (chronicler_routines_mine) plus any owner-declared
# rows (origin='declared', bu-whhll.11).
#
# - GET    /routines           list all rows for dashboard review
# - POST   /routines           declare a schedule (origin='declared')
# - PATCH  /routines/{id}       enable/disable + rename (any row); edit the
#                               window/days/timezone (declared rows only)
# - DELETE /routines/{id}       remove a declared row (mined rows are disabled,
#                               not deleted — the miner would recreate them)


def _is_declared(routine: Any) -> bool:
    origin = routine.origin.value if hasattr(routine.origin, "value") else str(routine.origin)
    return origin == RoutineOrigin.DECLARED.value


def _validate_routine_window(window_start: dt_time, window_end: dt_time) -> None:
    """Reject a non-same-day window (matches the table's CHECK constraint).

    Surfacing this as a 400 keeps a bad payload from bubbling up as an opaque
    500 from the Postgres CHECK on ``window_end_local > window_start_local``.
    """
    if window_end <= window_start:
        raise HTTPException(
            status_code=400,
            detail="window_end_local must be strictly after window_start_local",
        )


def _validate_routine_timezone(tz: str) -> None:
    try:
        zoneinfo.ZoneInfo(tz)
    except (zoneinfo.ZoneInfoNotFoundError, KeyError, ValueError) as exc:
        # ValueError covers an empty/malformed key ("" -> "keys must be
        # normalized relative paths"); without it a blank timezone would 500.
        raise HTTPException(
            status_code=400,
            detail=f"Unrecognized IANA timezone: {tz!r}",
        ) from exc


def _routine_to_row(routine: Any) -> RoutineRow:
    origin = routine.origin.value if hasattr(routine.origin, "value") else str(routine.origin)
    missed_mine_cycles = routine.missed_mine_cycles
    return RoutineRow(
        id=str(routine.id),
        dow_mask=routine.dow_mask,
        window_start_local=routine.window_start_local,
        window_end_local=routine.window_end_local,
        timezone=routine.timezone,
        label=routine.label,
        support_count=routine.support_count,
        confidence=routine.confidence,
        evidence_summary=routine.evidence_summary,
        origin=origin,
        enabled=routine.enabled,
        last_confirmed_at=routine.last_confirmed_at,
        missed_mine_cycles=missed_mine_cycles,
        stale=origin == "mined" and missed_mine_cycles > 0,
        created_at=routine.created_at,
        updated_at=routine.updated_at,
    )


@router.get("/routines", response_model=ApiResponse[list[RoutineRow]])
async def list_chronicler_routines(
    enabled_only: bool = Query(False, description="Only return enabled routines."),
    *,
    db: Db,
) -> ApiResponse[list[RoutineRow]]:
    """List owner-reviewable weekly routines, ordered by dow_mask then window start.

    Includes both mined (``origin='mined'``) and owner-declared
    (``origin='declared'``) rows. An empty ``routines`` table returns
    ``{"data": [], "meta": {}}``.
    """
    pool = _pool(db)
    routines = await list_routines(pool, enabled_only=enabled_only)
    return ApiResponse[list[RoutineRow]](data=[_routine_to_row(r) for r in routines])


@router.post("/routines", response_model=RoutineRow, status_code=201)
async def create_chronicler_routine(
    request: Request,
    body: CreateRoutineRequest = Body(...),
    *,
    db: Db,
) -> RoutineRow:
    """Declare an owner work schedule (``origin='declared'``, bu-whhll.11).

    Writes the schedule straight into ``chronicler.routines`` so the
    occupation-inference adapter consumes it on its next run — inference works
    the moment the owner declares, without waiting weeks for the miner to
    accrue observed support. The miner later refines/decays confidence with
    real evidence but never clobbers a declared row.
    """
    _validate_routine_window(body.window_start_local, body.window_end_local)
    _validate_routine_timezone(body.timezone)

    pool = _pool(db)
    routine = await create_declared_routine(
        pool,
        dow_mask=body.dow_mask,
        window_start_local=body.window_start_local,
        window_end_local=body.window_end_local,
        label=body.label,
        timezone=body.timezone,
        enabled=body.enabled,
    )

    await emit_dashboard_audit(
        db,
        butler="chronicler",
        operation="routine_declare_create",
        method="POST",
        path="/api/chronicler/routines",
        body={"dow_mask": body.dow_mask, "label": body.label, "enabled": body.enabled},
        response_status=201,
        request=request,
    )

    return _routine_to_row(routine)


@router.patch("/routines/{routine_id}", response_model=RoutineRow)
async def patch_chronicler_routine(
    routine_id: UUID,
    request: Request,
    body: UpdateRoutineRequest = Body(...),
    *,
    db: Db,
) -> RoutineRow:
    """Owner review/edit: enable/disable, rename, or re-schedule a routine.

    ``enabled``/``label`` are editable on any routine. The schedule fields
    (``dow_mask``, ``window_start_local``, ``window_end_local``, ``timezone``)
    are editable only on owner-declared routines — attempting them on a mined
    routine is a 400, because the weekly miner owns a mined routine's window
    and (per ``storage.upsert_mined_routine``) refreshes it on its next run
    while preserving the owner's ``enabled``/``label`` edits.
    """
    pool = _pool(db)
    existing = await get_routine(pool, routine_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="Routine not found")

    editing_schedule = any(
        field is not None
        for field in (
            body.dow_mask,
            body.window_start_local,
            body.window_end_local,
            body.timezone,
        )
    )
    if editing_schedule and not _is_declared(existing):
        raise HTTPException(
            status_code=400,
            detail=(
                "Only declared routines can have their schedule edited; the weekly "
                "miner owns a mined routine's window, days, and timezone. Disable "
                "the mined routine and declare your own instead."
            ),
        )

    # Validate the effective window when either bound is being changed.
    if body.window_start_local is not None or body.window_end_local is not None:
        _validate_routine_window(
            body.window_start_local or existing.window_start_local,
            body.window_end_local or existing.window_end_local,
        )
    if body.timezone is not None:
        _validate_routine_timezone(body.timezone)

    updated = await update_routine(
        pool,
        routine_id,
        enabled=body.enabled,
        label=body.label,
        dow_mask=body.dow_mask,
        window_start_local=body.window_start_local,
        window_end_local=body.window_end_local,
        timezone=body.timezone,
    )
    if updated is None:  # pragma: no cover — defensive (row existed above)
        raise HTTPException(status_code=404, detail="Routine not found")

    await emit_dashboard_audit(
        db,
        butler="chronicler",
        operation="routine_update",
        method="PATCH",
        path=f"/api/chronicler/routines/{routine_id}",
        path_params={"routine_id": str(routine_id)},
        body={"enabled": body.enabled, "label": body.label, "schedule_edited": editing_schedule},
        response_status=200,
        request=request,
    )

    return _routine_to_row(updated)


@router.delete("/routines/{routine_id}", status_code=204)
async def delete_chronicler_routine(
    routine_id: UUID,
    request: Request,
    *,
    db: Db,
) -> Response:
    """Delete an owner-declared routine (bu-whhll.11).

    Only ``origin='declared'`` rows are deletable. A mined routine can only be
    disabled (PATCH ``enabled=false``): deleting it would be futile because the
    next weekly mine would recreate it — a 400 steers the owner to disable it.
    """
    pool = _pool(db)
    existing = await get_routine(pool, routine_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="Routine not found")
    if not _is_declared(existing):
        raise HTTPException(
            status_code=400,
            detail=(
                "Only declared routines can be deleted; disable a mined routine "
                "instead (deleting it would be undone by the next weekly mine)."
            ),
        )

    await delete_routine(pool, routine_id)

    await emit_dashboard_audit(
        db,
        butler="chronicler",
        operation="routine_delete",
        method="DELETE",
        path=f"/api/chronicler/routines/{routine_id}",
        path_params={"routine_id": str(routine_id)},
        response_status=204,
        request=request,
    )

    return Response(status_code=204)


@router.post("/gap-interview/resolve")
async def resolve_gap_interview(
    body: ResolveGapInterviewRequest = Body(...),
    *,
    db: Db,
) -> dict[str, Any]:
    """Apply a one-tap gap-interview answer (bu-whhll.12).

    The deterministic route for a telegram inline-button tap: the
    ``telegram_bot`` connector recognises a ``cgi:<interview_id>:<answer>``
    callback and POSTs here (the connector runs as the restricted
    ``connector_writer`` role and cannot write the chronicler schema itself;
    this endpoint runs with the chronicler pool that can). Delegates to the
    shared ``resolve_gap_interview_callback`` — the same resolver the
    ``chronicler_resolve_gap_interview`` MCP tool uses — so the write shape and
    idempotency are identical across both entry points.

    Always returns HTTP 200 with a ``status`` the caller can turn into a toast:
    ``applied`` / ``already_answered`` / ``error`` (unknown/expired interview or
    an unparseable answer). Never raises for those owner-facing conditions.
    """
    from datetime import UTC, datetime

    from butlers.chronicler.gap_interview import resolve_gap_interview_callback

    pool = _pool(db)
    return await resolve_gap_interview_callback(
        pool,
        interview_id=body.interview_id,
        answer=body.answer,
        now=datetime.now(UTC),
    )
