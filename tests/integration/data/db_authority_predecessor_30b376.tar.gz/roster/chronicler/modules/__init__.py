"""Chronicler butler MCP module.

Registers the Tier-1 read tools (``chronicler_list_events``,
``chronicler_list_episodes``, ``chronicler_get_episode``,
``chronicler_submit_correction``, ``chronicler_list_corrections``), the
Tier-2 bundle assembler tool (``chronicler_day_close_bundle``), and the
day-close gap-interview tools (``chronicler_gap_interview`` /
``chronicler_resolve_gap_interview``, bu-whhll.12).

The bundle assembler tool is the entry-point for scheduled Tier-2 paths
(day-close, drilldown, etc.).  It applies sensitive masking, field stripping,
per-source roll-up, and hard cardinality caps before returning structured JSON
— guaranteeing the agent never receives an unbounded context payload.
"""

from __future__ import annotations

import logging
from typing import Any

from pydantic import BaseModel

from butlers.modules.base import Module

logger = logging.getLogger(__name__)


def _serialise_dropped_intents(dropped_intents: Any) -> list[dict[str, Any]]:
    """Convert ``reconcile_day``'s ``DroppedIntent`` objects into a JSON-safe
    summary for the day-close bundle payload.

    ``dropped.intent`` is the raw reconciled episode dict, which still carries
    ``datetime`` objects for its window fields (unlike ``episodes``/``events``,
    which go through ``bundle_assembler._serialise_items``'s ISO-8601
    conversion). Convert here so the MCP tool never returns a raw ``datetime``
    that the framework's JSON serialization of the tool result would reject.
    """
    from datetime import datetime

    def _to_iso(val: Any) -> Any:
        return val.isoformat() if isinstance(val, datetime) else val

    return [
        {
            "title": dropped.intent.get("canonical_title") or dropped.intent.get("title"),
            "start_at": _to_iso(
                dropped.intent.get("canonical_start_at") or dropped.intent.get("start_at")
            ),
            "end_at": _to_iso(
                dropped.intent.get("canonical_end_at") or dropped.intent.get("end_at")
            ),
            "reason": dropped.reason,
            "overlap_fraction": round(dropped.overlap_fraction, 2),
        }
        for dropped in dropped_intents
    ]


class ChroniclerModuleConfig(BaseModel):
    """Configuration for the Chronicler read/bundle tools module."""


# Module-default deterministic job schedules (bu-whhll.9), following the
# memory module's pattern (see `MemoryModule._register_default_maintenance_schedules`
# and `ensure_module_default_schedule`): self-registered on every daemon boot
# so the job exists without a copy-pasted `[[butler.schedule]]` block in
# `roster/chronicler/butler.toml`. An operator may still add such a block
# reusing this `name` to override cadence — TOML wins on cadence, not
# existence.
_DEFAULT_SCHEDULES: tuple[dict[str, Any], ...] = (
    {
        # Weekly, Sunday 03:30 (owner's effective timezone — see
        # `ensure_module_default_schedule`): mines the prior weeks' activity
        # episodes for stable weekday desk-signal windows and upserts
        # `chronicler.routines`. No LLM.
        "name": "chronicler_routines_mine",
        "cron": "30 3 * * 0",
        "job_name": "chronicler_routines_mine",
    },
    {
        # Hourly, 15 past (bu-u30as, telemetry-distillation bead 3): rolls up
        # any local calendar day whose window has fully elapsed into
        # `chronicler.daily_rollups`, reusing the exact same
        # `aggregations.lane_for_activity`/`union_seconds` rules
        # `GET /aggregate/by-category` uses. Registered here (module
        # self-registration) rather than a `[[butler.schedule]]` TOML block
        # because it is a full-rescan summary materializer over chronicler's
        # own schema — the same job shape as `chronicler_routines_mine`
        # above — not a per-source incremental `ProjectionAdapter`, which is
        # what the TOML-block jobs are. No LLM.
        "name": "chronicler_rollup_daily",
        "cron": "15 * * * *",
        "job_name": "chronicler_rollup_daily",
    },
    {
        # Daily, 01:20 (bu-v9y18, telemetry-distillation bead 6): the one
        # optional, bounded LLM call per local day, labeling the already-
        # materialized `daily_rollups`/`daily_rollup_flags` rows for
        # yesterday (design doc §3.5/§6.6). Scheduled after
        # `chronicler_rollup_daily`'s hourly ":15" tick and
        # `chronicler_day_close`'s 01:05 prompt-mode task, so yesterday's
        # rollup + flags are already finalized by the time this runs.
        # Presentation polish only — a skip, a disabled pass
        # (CHRONICLER_NARRATION_ENABLED=false), or a failed LLM call never
        # blocks or corrupts the deterministic rollup/flags rows (see
        # `narration.py` module docstring).
        "name": "chronicler_narrate_daily",
        "cron": "20 1 * * *",
        "job_name": "chronicler_narrate_daily",
    },
)


class ChroniclerModule(Module):
    """Chronicler MCP module.

    Provides read tools and the day-close bundle assembler.
    """

    def __init__(self) -> None:
        self._db: Any = None
        self._credential_store: Any = None

    name = "chronicler"

    @property
    def config_schema(self) -> type[BaseModel]:
        return ChroniclerModuleConfig

    async def on_startup(
        self,
        config: Any,
        db: Any,
        credential_store: Any = None,
        blob_store: Any = None,
    ) -> None:
        self._db = db
        # Borrow the daemon-selected store; its pools remain owned by the daemon.
        self._credential_store = credential_store
        await self._register_default_schedules(db)

    async def _register_default_schedules(self, db: Any) -> None:
        """Self-register default Chronicler job schedules (module-default).

        Best-effort per schedule: a failure (e.g. ``scheduled_tasks`` not yet
        migrated in some harness) is logged and does not fail module startup
        or disable the module's MCP tools. See `_DEFAULT_SCHEDULES` and
        `ensure_module_default_schedule` for the exact idempotency/reclaim
        semantics.
        """
        if db is None:
            return
        from butlers.core.scheduler import ensure_module_default_schedule

        owner_butler = getattr(db, "owner_butler", None) or getattr(db, "schema", None)
        # Legacy per-butler databases use their unqualified public schema.
        owner_schema = getattr(db, "schema", None) or "public"
        for entry in _DEFAULT_SCHEDULES:
            try:
                await ensure_module_default_schedule(
                    db.pool,
                    name=entry["name"],
                    cron=entry["cron"],
                    job_name=entry["job_name"],
                    job_args=entry.get("job_args"),
                    owner_butler=owner_butler,
                    owner_schema=owner_schema,
                )
            except Exception:
                logger.warning(
                    "Failed to register default Chronicler schedule %r; "
                    "it may need to be scheduled manually via butler.toml",
                    entry["name"],
                    exc_info=True,
                )

    async def on_shutdown(self) -> None:
        self._credential_store = None
        self._db = None

    def _get_pool(self) -> Any:
        if self._db is None:
            raise RuntimeError("ChroniclerModule not initialised — no DB available")
        return self._db.pool

    async def register_tools(self, mcp: Any, config: Any, db: Any, butler_name: str) -> None:
        """Register all Chronicler MCP tools."""
        self._db = db
        _register_tools(mcp, self)


def _register_tools(mcp: Any, module: ChroniclerModule) -> None:
    """Register Chronicler read and bundle tools on *mcp*."""

    # ------------------------------------------------------------------
    # chronicler_list_events
    # ------------------------------------------------------------------

    @mcp.tool()
    async def chronicler_list_events(
        occurred_from: str | None = None,
        occurred_to: str | None = None,
        source_name: str | None = None,
        event_type: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List corrected point events within an optional time window.

        Args:
            occurred_from: ISO-8601 datetime lower bound (inclusive).
            occurred_to: ISO-8601 datetime upper bound (exclusive).
            source_name: Filter to a specific source adapter.
            event_type: Filter to a specific event type.
            limit: Maximum rows to return (max 500).
            offset: Row offset for pagination.

        Returns:
            ``{"data": [...], "count": int}`` — corrected point events.
            Sensitive events (``canonical_privacy='sensitive'``) are
            included in this read tool; masking is applied only by the
            bundle assembler path (``chronicler_day_close_bundle``).
        """
        from datetime import datetime

        from butlers.chronicler.storage import list_point_events

        limit = min(max(1, limit), 500)

        def _parse_dt(s: str | None) -> datetime | None:
            if s is None:
                return None
            return datetime.fromisoformat(s)

        pool = module._get_pool()
        rows = await list_point_events(
            pool,
            occurred_from=_parse_dt(occurred_from),
            occurred_to=_parse_dt(occurred_to),
            source_name=source_name,
            event_type=event_type,
            limit=limit,
            offset=offset,
        )
        from dataclasses import asdict

        return {"data": [asdict(r) for r in rows], "count": len(rows)}

    # ------------------------------------------------------------------
    # chronicler_list_episodes
    # ------------------------------------------------------------------

    @mcp.tool()
    async def chronicler_list_episodes(
        start_from: str | None = None,
        start_to: str | None = None,
        source_name: str | None = None,
        episode_type: str | None = None,
        participant_entity_id: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List corrected episodes within an optional time window.

        Args:
            start_from: ISO-8601 datetime lower bound on episode start.
            start_to: ISO-8601 datetime upper bound on episode start (exclusive).
            source_name: Filter to a specific source adapter.
            episode_type: Filter to a specific episode type.
            participant_entity_id: Filter to episodes where this entity UUID
                appears in any role (owner, organizer, or participant) via the
                ``episode_entities`` join table.  Use this for entity activity
                feeds that should surface meetings where the entity attended
                but did not own the calendar.
            limit: Maximum rows to return (max 500).
            offset: Row offset for pagination.

        Returns:
            ``{"data": [...], "count": int}`` — corrected episodes.
        """
        from datetime import datetime
        from uuid import UUID

        from butlers.chronicler.storage import list_episodes

        limit = min(max(1, limit), 500)

        def _parse_dt(s: str | None) -> datetime | None:
            if s is None:
                return None
            return datetime.fromisoformat(s)

        pool = module._get_pool()
        rows = await list_episodes(
            pool,
            start_from=_parse_dt(start_from),
            start_to=_parse_dt(start_to),
            source_name=source_name,
            episode_type=episode_type,
            participant_entity_id=(
                UUID(participant_entity_id) if participant_entity_id not in (None, "") else None
            ),
            limit=limit,
            offset=offset,
        )
        from dataclasses import asdict

        return {"data": [asdict(r) for r in rows], "count": len(rows)}

    # ------------------------------------------------------------------
    # chronicler_get_episode
    # ------------------------------------------------------------------

    @mcp.tool()
    async def chronicler_get_episode(
        episode_id: str,
    ) -> dict[str, Any]:
        """Fetch a single corrected episode (with override overlay).

        Args:
            episode_id: UUID of the episode to fetch.

        Returns:
            The corrected episode row, or ``{"error": "not_found"}`` when
            the episode does not exist or is tombstoned.
        """
        from uuid import UUID

        from butlers.chronicler.storage import get_episode

        pool = module._get_pool()
        ep = await get_episode(pool, UUID(episode_id))
        if ep is None:
            return {"error": "not_found"}
        from dataclasses import asdict

        return asdict(ep)

    # ------------------------------------------------------------------
    # chronicler_submit_correction
    # ------------------------------------------------------------------

    @mcp.tool()
    async def chronicler_submit_correction(
        episode_id: str,
        corrected_title: str | None = None,
        corrected_start_at: str | None = None,
        corrected_end_at: str | None = None,
        corrected_privacy: str | None = None,
        note: str | None = None,
    ) -> dict[str, Any]:
        """Submit a correction override for an episode.

        Corrections are additive: the canonical row is never mutated.
        The latest correction wins when building the corrected view.

        Args:
            episode_id: UUID of the target episode.
            corrected_title: New title for the episode.
            corrected_start_at: New start time (ISO-8601).
            corrected_end_at: New end time (ISO-8601).
            corrected_privacy: New privacy class (``normal`` / ``sensitive``).
            note: Free-form correction note (human-readable context).

        Returns:
            ``{"status": "ok", "override_id": "<uuid>"}`` on success.
        """
        from datetime import datetime
        from uuid import UUID

        from butlers.chronicler.models import Override, OverrideTarget, Privacy
        from butlers.chronicler.storage import insert_override

        def _parse_dt(s: str | None) -> datetime | None:
            if s is None:
                return None
            return datetime.fromisoformat(s)

        override = Override(
            target_kind=OverrideTarget.EPISODE,
            target_id=UUID(episode_id),
            corrected_title=corrected_title,
            corrected_start_at=_parse_dt(corrected_start_at),
            corrected_end_at=_parse_dt(corrected_end_at),
            corrected_privacy=Privacy(corrected_privacy) if corrected_privacy else None,
            note=note,
        )
        pool = module._get_pool()
        saved = await insert_override(pool, override)
        return {"status": "ok", "override_id": str(saved.id)}

    # ------------------------------------------------------------------
    # chronicler_list_corrections
    # ------------------------------------------------------------------

    @mcp.tool()
    async def chronicler_list_corrections(
        episode_id: str,
    ) -> dict[str, Any]:
        """List all correction overrides for an episode.

        Args:
            episode_id: UUID of the episode.

        Returns:
            ``{"data": [...], "count": int}`` — correction history,
            newest first.
        """
        from uuid import UUID

        from butlers.chronicler.models import OverrideTarget
        from butlers.chronicler.storage import list_overrides_for

        pool = module._get_pool()
        overrides = await list_overrides_for(
            pool,
            target_kind=OverrideTarget.EPISODE,
            target_id=UUID(episode_id),
        )
        from dataclasses import asdict

        return {"data": [asdict(o) for o in overrides], "count": len(overrides)}

    # ------------------------------------------------------------------
    # chronicler_gap_interview  — day-close gap interview ASK (bu-whhll.12)
    # ------------------------------------------------------------------

    @mcp.tool()
    async def chronicler_gap_interview(
        date_label: str,
        timezone: str = "UTC",
    ) -> dict[str, Any]:
        """Run the once-daily day-close gap interview for *date_label*.

        Deterministic ask-side of bu-whhll.12. When the closed day left more than
        two hours of waking time unaccounted, or carries a low-confidence
        ``occupation_block`` the pipeline was never sure about, the owner is
        worth **one** confirmation prompt. This tool does the whole ask:
        evaluate → max-one-per-day dedupe (KV state) → quiet-hours /
        delivery-preferences gate → deliver a Telegram inline-button message
        (✅ Work day / ✏️ Not work / 🚫 Dismiss) whose taps route back to
        :func:`chronicler_resolve_gap_interview`. The 09:00 ``chronicler_gap_interview``
        job-mode schedule calls the same service,
        :func:`butlers.chronicler.gap_interview_job.ask_gap_interview`.

        Args:
            date_label: Closed local day in ``YYYY-MM-DD``.
            timezone: IANA timezone the day is bounded/displayed in.

        Returns a status dict: ``asked`` (delivered), ``already_asked``,
        ``no_gap``, ``deferred_quiet_hours``, ``delivery_failed``, or
        ``not_configured`` (no owner telegram chat / bot token).
        """
        from butlers.chronicler.gap_interview_job import ask_gap_interview

        store_kwargs = (
            {"credential_store": module._credential_store}
            if module._credential_store is not None
            else {}
        )
        return await ask_gap_interview(
            module._get_pool(), date_label=date_label, timezone=timezone, **store_kwargs
        )

    # ------------------------------------------------------------------
    # chronicler_resolve_gap_interview  — day-close gap interview ANSWER
    # ------------------------------------------------------------------

    @mcp.tool()
    async def chronicler_resolve_gap_interview(
        interview_id: str,
        answer: str,
    ) -> dict[str, Any]:
        """Apply a one-tap gap-interview answer (bu-whhll.12).

        The deterministic answer-side: turns ``confirm`` / ``correct`` /
        ``dismiss`` into a durable ``chronicler.overrides`` row (the first real
        tenant of the corrections machinery) and a reinforce/decay nudge on the
        matching routine, idempotently. This is the seam the telegram
        inline-button callback (via the ``telegram_bot`` connector) and the
        future decision-loop transport (RFC 0021) both call.

        Args:
            interview_id: The id handed out by ``chronicler_gap_interview``.
            answer: One of ``confirm`` / ``correct`` / ``dismiss``.

        Returns the apply summary, or ``{"status": "error"|"already_answered"}``.
        """
        from datetime import UTC, datetime

        from butlers.chronicler.gap_interview import resolve_gap_interview_callback

        return await resolve_gap_interview_callback(
            module._get_pool(),
            interview_id=interview_id,
            answer=answer,
            now=datetime.now(UTC),
        )

    # ------------------------------------------------------------------
    # chronicler_day_close_bundle  — Tier-2 bounded assembler
    # ------------------------------------------------------------------

    @mcp.tool()
    async def chronicler_day_close_bundle(
        date_label: str,
        timezone: str = "UTC",
        max_episodes: int = 50,
        max_events: int = 100,
        rollup_threshold: int = 10,
        max_total_chars: int = 15_000,
    ) -> dict[str, Any]:
        """Return a token-bounded day-close bundle for the given date.

        Fetches all non-tombstoned episodes and events for *date_label*
        (``YYYY-MM-DD`` in *timezone*), then applies:

        1. **Sensitive masking** — sensitive payloads are excluded; only
           bounded time/category envelopes survive. Restricted rows are absent.
        2. **Field stripping** — low-signal payload keys are removed.
        3. **Per-source roll-up** — sources emitting > *rollup_threshold*
           items are collapsed to a count/time-range/subjects summary.
        4. **Hard cap** — episode and event counts are capped at
           *max_episodes* / *max_events*; the total bundle characters are
           capped at *max_total_chars*.

        The result is structured JSON suitable as-is for the
        ``chronicler_day_close`` interpretation prompt.

        Args:
            date_label: Date to close in ``YYYY-MM-DD`` format.
            timezone: IANA timezone used for date boundaries and display
                timestamps (default ``UTC``).
            max_episodes: Episode cap before serialization (default 50).
            max_events: Event cap before serialization (default 100).
            rollup_threshold: Per-source item count that triggers roll-up
                (default 10).
            max_total_chars: Hard limit on bundle JSON characters (default
                15 000).  Set to 0 to disable character cap.

        Returns:
            Pre-truncated bundle dict with keys ``date``, ``episodes``,
            ``events``, ``episodes_truncated``, ``events_truncated``,
            and ``citations``.
        """
        from datetime import UTC, datetime
        from zoneinfo import ZoneInfo

        from butlers.chronicler.bundle_assembler import (
            BundleConfig,
            assemble_day_close_bundle,
            partition_day_close_rows,
        )
        from butlers.chronicler.reconciliation import reconcile_day
        from butlers.chronicler.storage import list_episodes, list_point_events

        # Parse date_label to a local calendar-day window, then query UTC instants.
        day = datetime.fromisoformat(date_label).date()
        tzinfo = ZoneInfo(timezone)
        start_at = datetime(day.year, day.month, day.day, tzinfo=tzinfo).astimezone(UTC)
        from datetime import timedelta

        end_at = datetime(day.year, day.month, day.day, tzinfo=tzinfo) + timedelta(days=1)
        end_at = end_at.astimezone(UTC)

        pool = module._get_pool()

        # Fetch with a generous DB-level cap to avoid unbounded scans.
        db_limit = max(500, max_episodes * 5, max_events * 5)

        episodes = await list_episodes(
            pool,
            start_from=start_at,
            start_to=end_at,
            limit=db_limit,
        )
        events = await list_point_events(
            pool,
            occurred_from=start_at,
            occurred_to=end_at,
            limit=db_limit,
        )

        from dataclasses import asdict

        episode_dicts = [asdict(ep) for ep in episodes]
        event_dicts = [asdict(ev) for ev in events]

        # Partition before reconciliation can select titles, merge source refs,
        # or derive contradictions. Private rows cannot affect normal narration.
        normal_episodes, sensitive_episodes = partition_day_close_rows(episode_dicts)
        normal_events, sensitive_events = partition_day_close_rows(event_dicts)

        # Deterministic reconciliation core (tasks.md §7): merge duplicate
        # same-lane activity candidates and drop calendar intents contradicted
        # by activity evidence, BEFORE the LLM ever sees this bundle. Aggregate
        # correctness (what counts, what's dropped) is decided entirely here;
        # the day-close LLM only narrates over the result.
        reconciled = reconcile_day(normal_episodes)
        reconciled_episodes = [
            *reconciled.activities,
            *reconciled.kept_intents,
            *reconciled.passthrough,
        ]
        dropped_intents_payload = _serialise_dropped_intents(reconciled.dropped_intents)

        cfg = BundleConfig(
            max_episodes=max_episodes,
            max_events=max_events,
            rollup_threshold=rollup_threshold,
            max_total_chars=max_total_chars,
        )
        bundle_input = assemble_day_close_bundle(
            date_label=date_label,
            episodes=[*reconciled_episodes, *sensitive_episodes],
            events=[*normal_events, *sensitive_events],
            timezone=timezone,
            config=cfg,
            dropped_intents=dropped_intents_payload,
        )

        return {
            **bundle_input.bundle,
            "citations": bundle_input.citations,
        }
